"use strict";
(() => {
    var W = Object.defineProperty;
    var o = (D, x) => W(D, "name", {
        value: x,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [8630], {
            13002: (D, x, M) => {
                M.d(x, {
                    Z: () => d
                });
                class v extends HTMLElement {
                    constructor() {
                        super();
                        this.currentQuery = null, this.filter = null, this.debounceInputChange = y(() => u(this, !0)), this.boundFilterResults = () => {
                            u(this, !1)
                        }
                    }
                    static get observedAttributes() {
                        return ["aria-owns"]
                    }
                    attributeChangedCallback(n, t) {
                        t && n === "aria-owns" && u(this, !1)
                    }
                    connectedCallback() {
                        const n = this.input;
                        !n || (n.setAttribute("autocomplete", "off"), n.setAttribute("spellcheck", "false"), n.addEventListener("focus", this.boundFilterResults), n.addEventListener("change", this.boundFilterResults), n.addEventListener("input", this.debounceInputChange))
                    }
                    disconnectedCallback() {
                        const n = this.input;
                        !n || (n.removeEventListener("focus", this.boundFilterResults), n.removeEventListener("change", this.boundFilterResults), n.removeEventListener("input", this.debounceInputChange))
                    }
                    get input() {
                        const n = this.querySelector("input");
                        return n instanceof HTMLInputElement ? n : null
                    }
                    reset() {
                        const n = this.input;
                        n && (n.value = "", n.dispatchEvent(new Event("change", {
                            bubbles: !0
                        })))
                    }
                }
                o(v, "FilterInputElement");
                async function u(e, n = !1) {
                    const t = e.input;
                    if (!t) return;
                    const a = t.value.trim(),
                        l = e.getAttribute("aria-owns");
                    if (!l) return;
                    const r = document.getElementById(l);
                    if (!r) return;
                    const c = r.hasAttribute("data-filter-list") ? r : r.querySelector("[data-filter-list]");
                    if (!c || (e.dispatchEvent(new CustomEvent("filter-input-start", {
                            bubbles: !0
                        })), n && e.currentQuery === a)) return;
                    e.currentQuery = a;
                    const m = e.filter || S,
                        A = c.childElementCount;
                    let h = 0,
                        k = !1;
                    for (const g of Array.from(c.children)) {
                        if (!(g instanceof HTMLElement)) continue;
                        const L = w(g),
                            R = m(g, L, a);
                        R.hideNew === !0 && (k = R.hideNew), g.hidden = !R.match, R.match && h++
                    }
                    const b = r.querySelector("[data-filter-new-item]"),
                        E = !!b && a.length > 0 && !k;
                    b instanceof HTMLElement && (b.hidden = !E, E && p(b, a)), T(r, h > 0 || E), e.dispatchEvent(new CustomEvent("filter-input-updated", {
                        bubbles: !0,
                        detail: {
                            count: h,
                            total: A
                        }
                    }))
                }
                o(u, "filterResults");

                function S(e, n, t) {
                    return {
                        match: n.toLowerCase().indexOf(t.toLowerCase()) !== -1,
                        hideNew: n === t
                    }
                }
                o(S, "matchSubstring");

                function w(e) {
                    return ((e.querySelector("[data-filter-item-text]") || e).textContent || "").trim()
                }
                o(w, "getText");

                function p(e, n) {
                    const t = e.querySelector("[data-filter-new-item-text]");
                    t && (t.textContent = n);
                    const a = e.querySelector("[data-filter-new-item-value]");
                    (a instanceof HTMLInputElement || a instanceof HTMLButtonElement) && (a.value = n)
                }
                o(p, "updateNewItem");

                function T(e, n) {
                    const t = e.querySelector("[data-filter-empty-state]");
                    t instanceof HTMLElement && (t.hidden = n)
                }
                o(T, "toggleBlankslate");

                function y(e) {
                    let n;
                    return function() {
                        clearTimeout(n), n = setTimeout(() => {
                            clearTimeout(n), e()
                        }, 300)
                    }
                }
                o(y, "debounce");
                const d = v;
                window.customElements.get("filter-input") || (window.FilterInputElement = v, window.customElements.define("filter-input", v))
            },
            88309: (D, x, M) => {
                M.d(x, {
                    Z: () => y
                });
                const v = new WeakMap;
                class u extends HTMLElement {
                    constructor() {
                        super();
                        const e = w.bind(null, this, !0),
                            n = {
                                currentQuery: null,
                                oninput: T(e),
                                fetch: e,
                                controller: null
                            };
                        v.set(this, n)
                    }
                    static get observedAttributes() {
                        return ["src"]
                    }
                    attributeChangedCallback(e, n) {
                        n && e === "src" && w(this, !1)
                    }
                    connectedCallback() {
                        const e = this.input;
                        if (!e) return;
                        e.setAttribute("autocomplete", "off"), e.setAttribute("spellcheck", "false");
                        const n = v.get(this);
                        !n || (e.addEventListener("focus", n.fetch), e.addEventListener("change", n.fetch), e.addEventListener("input", n.oninput))
                    }
                    disconnectedCallback() {
                        const e = this.input;
                        if (!e) return;
                        const n = v.get(this);
                        !n || (e.removeEventListener("focus", n.fetch), e.removeEventListener("change", n.fetch), e.removeEventListener("input", n.oninput))
                    }
                    get input() {
                        const e = this.querySelector("input, textarea");
                        return e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement ? e : null
                    }
                    get src() {
                        return this.getAttribute("src") || ""
                    }
                    set src(e) {
                        this.setAttribute("src", e)
                    }
                }
                o(u, "RemoteInputElement");

                function S() {
                    return "AbortController" in window ? new AbortController : {
                        signal: null,
                        abort() {}
                    }
                }
                o(S, "makeAbortController");
                async function w(d, e) {
                    const n = d.input;
                    if (!n) return;
                    const t = v.get(d);
                    if (!t) return;
                    const a = n.value;
                    if (e && t.currentQuery === a) return;
                    t.currentQuery = a;
                    const l = d.src;
                    if (!l) return;
                    const r = document.getElementById(d.getAttribute("aria-owns") || "");
                    if (!r) return;
                    const c = new URL(l, window.location.href),
                        m = new URLSearchParams(c.search);
                    m.append(d.getAttribute("param") || "q", a), c.search = m.toString(), t.controller ? t.controller.abort() : (d.dispatchEvent(new CustomEvent("loadstart")), d.setAttribute("loading", "")), t.controller = S();
                    let A, h = "";
                    try {
                        A = await p(d, c.toString(), {
                            signal: t.controller.signal,
                            credentials: "same-origin",
                            headers: {
                                accept: "text/fragment+html"
                            }
                        }), h = await A.text(), d.removeAttribute("loading"), t.controller = null
                    } catch (k) {
                        k.name !== "AbortError" && (d.removeAttribute("loading"), t.controller = null);
                        return
                    }
                    A && A.ok ? (r.innerHTML = h, d.dispatchEvent(new CustomEvent("remote-input-success", {
                        bubbles: !0
                    }))) : d.dispatchEvent(new CustomEvent("remote-input-error", {
                        bubbles: !0
                    }))
                }
                o(w, "fetchResults");
                async function p(d, e, n) {
                    try {
                        const t = await fetch(e, n);
                        return d.dispatchEvent(new CustomEvent("load")), d.dispatchEvent(new CustomEvent("loadend")), t
                    } catch (t) {
                        throw t.name !== "AbortError" && (d.dispatchEvent(new CustomEvent("error")), d.dispatchEvent(new CustomEvent("loadend"))), t
                    }
                }
                o(p, "fetchWithNetworkEvents");

                function T(d) {
                    let e;
                    return function() {
                        clearTimeout(e), e = setTimeout(() => {
                            clearTimeout(e), d()
                        }, 300)
                    }
                }
                o(T, "debounce");
                const y = u;
                window.customElements.get("remote-input") || (window.RemoteInputElement = u, window.customElements.define("remote-input", u))
            },
            29501: (D, x, M) => {
                M.d(x, {
                    Z: () => u
                });

                function v(w) {
                    return Array.from(w.querySelectorAll('[role="tablist"] [role="tab"]')).filter(p => p instanceof HTMLElement && p.closest(w.tagName) === w)
                }
                o(v, "getTabs");
                class u extends HTMLElement {
                    constructor() {
                        super();
                        this.addEventListener("keydown", p => {
                            const T = p.target;
                            if (!(T instanceof HTMLElement) || T.closest(this.tagName) !== this || T.getAttribute("role") !== "tab" && !T.closest('[role="tablist"]')) return;
                            const y = v(this),
                                d = y.indexOf(y.find(e => e.matches('[aria-selected="true"]')));
                            if (p.code === "ArrowRight") {
                                let e = d + 1;
                                e >= y.length && (e = 0), S(this, e)
                            } else if (p.code === "ArrowLeft") {
                                let e = d - 1;
                                e < 0 && (e = y.length - 1), S(this, e)
                            } else p.code === "Home" ? (S(this, 0), p.preventDefault()) : p.code === "End" && (S(this, y.length - 1), p.preventDefault())
                        }), this.addEventListener("click", p => {
                            const T = v(this);
                            if (!(p.target instanceof Element) || p.target.closest(this.tagName) !== this) return;
                            const y = p.target.closest('[role="tab"]');
                            if (!(y instanceof HTMLElement) || !y.closest('[role="tablist"]')) return;
                            const d = T.indexOf(y);
                            S(this, d)
                        })
                    }
                    connectedCallback() {
                        for (const p of v(this)) p.hasAttribute("aria-selected") || p.setAttribute("aria-selected", "false"), p.hasAttribute("tabindex") || (p.getAttribute("aria-selected") === "true" ? p.setAttribute("tabindex", "0") : p.setAttribute("tabindex", "-1"))
                    }
                }
                o(u, "TabContainerElement");

                function S(w, p) {
                    const T = v(w),
                        y = Array.from(w.querySelectorAll('[role="tabpanel"]')).filter(t => t.closest(w.tagName) === w),
                        d = T[p],
                        e = y[p];
                    if (!!w.dispatchEvent(new CustomEvent("tab-container-change", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                relatedTarget: e
                            }
                        }))) {
                        for (const t of T) t.setAttribute("aria-selected", "false"), t.setAttribute("tabindex", "-1");
                        for (const t of y) t.hidden = !0, !t.hasAttribute("tabindex") && !t.hasAttribute("data-tab-container-no-tabstop") && t.setAttribute("tabindex", "0");
                        d.setAttribute("aria-selected", "true"), d.setAttribute("tabindex", "0"), d.focus(), e.hidden = !1, w.dispatchEvent(new CustomEvent("tab-container-changed", {
                            bubbles: !0,
                            detail: {
                                relatedTarget: e
                            }
                        }))
                    }
                }
                o(S, "selectTab"), window.customElements.get("tab-container") || (window.TabContainerElement = u, window.customElements.define("tab-container", u))
            },
            47142: (D, x, M) => {
                M.d(x, {
                    CD: () => A,
                    Gs: () => c,
                    m7: () => m
                });
                var v = -1 / 0,
                    u = 1 / 0,
                    S = -.005,
                    w = -.005,
                    p = -.01,
                    T = 1,
                    y = .9,
                    d = .8,
                    e = .7,
                    n = .6;

                function t(h) {
                    return h.toLowerCase() === h
                }
                o(t, "islower");

                function a(h) {
                    return h.toUpperCase() === h
                }
                o(a, "isupper");

                function l(h) {
                    for (var k = h.length, b = new Array(k), E = "/", g = 0; g < k; g++) {
                        var L = h[g];
                        E === "/" ? b[g] = y : E === "-" || E === "_" || E === " " ? b[g] = d : E === "." ? b[g] = n : t(E) && a(L) ? b[g] = e : b[g] = 0, E = L
                    }
                    return b
                }
                o(l, "precompute_bonus");

                function r(h, k, b, E) {
                    for (var g = h.length, L = k.length, R = h.toLowerCase(), O = k.toLowerCase(), I = l(k, I), _ = 0; _ < g; _++) {
                        b[_] = new Array(L), E[_] = new Array(L);
                        for (var q = v, P = _ === g - 1 ? w : p, H = 0; H < L; H++)
                            if (R[_] === O[H]) {
                                var i = v;
                                _ ? H && (i = Math.max(E[_ - 1][H - 1] + I[H], b[_ - 1][H - 1] + T)) : i = H * S + I[H], b[_][H] = i, E[_][H] = q = Math.max(i, q + P)
                            } else b[_][H] = v, E[_][H] = q = q + P
                    }
                }
                o(r, "compute");

                function c(h, k) {
                    var b = h.length,
                        E = k.length;
                    if (!b || !E) return v;
                    if (b === E) return u;
                    if (E > 1024) return v;
                    var g = new Array(b),
                        L = new Array(b);
                    return r(h, k, g, L), L[b - 1][E - 1]
                }
                o(c, "score");

                function m(h, k) {
                    var b = h.length,
                        E = k.length,
                        g = new Array(b);
                    if (!b || !E) return g;
                    if (b === E) {
                        for (var L = 0; L < b; L++) g[L] = L;
                        return g
                    }
                    if (E > 1024) return g;
                    var R = new Array(b),
                        O = new Array(b);
                    r(h, k, R, O);
                    for (var I = !1, L = b - 1, _ = E - 1; L >= 0; L--)
                        for (; _ >= 0; _--)
                            if (R[L][_] !== v && (I || R[L][_] === O[L][_])) {
                                I = L && _ && O[L][_] === R[L - 1][_ - 1] + T, g[L] = _--;
                                break
                            }
                    return g
                }
                o(m, "positions");

                function A(h, k) {
                    h = h.toLowerCase(), k = k.toLowerCase();
                    for (var b = h.length, E = 0, g = 0; E < b; E += 1)
                        if (g = k.indexOf(h[E], g) + 1, g === 0) return !1;
                    return !0
                }
                o(A, "hasMatch")
            },
            46481: (D, x, M) => {
                M.d(x, {
                    Z: () => a
                });
                var v = M(10160);
                class u extends CustomEvent {
                    constructor(r, c) {
                        super(r, c);
                        this.relatedTarget = c.relatedTarget
                    }
                }
                o(u, "AutocompleteEvent");

                function S(l, r = 0) {
                    let c;
                    return function(...m) {
                        clearTimeout(c), c = window.setTimeout(() => {
                            clearTimeout(c), l(...m)
                        }, r)
                    }
                }
                o(S, "debounce");
                const w = new WeakMap;

                function p(l, r) {
                    const c = new XMLHttpRequest;
                    return c.open("GET", r, !0), c.setRequestHeader("Accept", "text/fragment+html"), T(l, c)
                }
                o(p, "fragment");

                function T(l, r) {
                    const c = w.get(l);
                    c && c.abort(), w.set(l, r);
                    const m = o(() => w.delete(l), "clear"),
                        A = y(r);
                    return A.then(m, m), A
                }
                o(T, "request");

                function y(l) {
                    return new Promise((r, c) => {
                        l.onload = function() {
                            l.status >= 200 && l.status < 300 ? r(l.responseText) : c(new Error(l.responseText))
                        }, l.onerror = c, l.send()
                    })
                }
                o(y, "send");
                const d = window.testScreenReaderDelay || 100;
                class e {
                    constructor(r, c, m, A = !1) {
                        var h;
                        if (this.container = r, this.input = c, this.results = m, this.combobox = new v.Z(c, m), this.feedback = document.getElementById(`${this.results.id}-feedback`), this.autoselectEnabled = A, this.clearButton = document.getElementById(`${this.input.id||this.input.name}-clear`), this.clientOptions = m.querySelectorAll("[role=option]"), this.feedback && (this.feedback.setAttribute("aria-live", "polite"), this.feedback.setAttribute("aria-atomic", "true")), this.clearButton && !this.clearButton.getAttribute("aria-label")) {
                            const k = document.querySelector(`label[for="${this.input.name}"]`);
                            this.clearButton.setAttribute("aria-label", "clear:"), this.clearButton.setAttribute("aria-labelledby", `${this.clearButton.id} ${(k==null?void 0:k.id)||""}`)
                        }
                        this.input.getAttribute("aria-expanded") || this.input.setAttribute("aria-expanded", "false"), this.results.hidden = !0, this.results.setAttribute("aria-label", "results"), this.input.setAttribute("autocomplete", "off"), this.input.setAttribute("spellcheck", "false"), this.interactingWithList = !1, this.onInputChange = S(this.onInputChange.bind(this), 300), this.onResultsMouseDown = this.onResultsMouseDown.bind(this), this.onInputBlur = this.onInputBlur.bind(this), this.onInputFocus = this.onInputFocus.bind(this), this.onKeydown = this.onKeydown.bind(this), this.onCommit = this.onCommit.bind(this), this.handleClear = this.handleClear.bind(this), this.input.addEventListener("keydown", this.onKeydown), this.input.addEventListener("focus", this.onInputFocus), this.input.addEventListener("blur", this.onInputBlur), this.input.addEventListener("input", this.onInputChange), this.results.addEventListener("mousedown", this.onResultsMouseDown), this.results.addEventListener("combobox-commit", this.onCommit), (h = this.clearButton) === null || h === void 0 || h.addEventListener("click", this.handleClear)
                    }
                    destroy() {
                        this.input.removeEventListener("keydown", this.onKeydown), this.input.removeEventListener("focus", this.onInputFocus), this.input.removeEventListener("blur", this.onInputBlur), this.input.removeEventListener("input", this.onInputChange), this.results.removeEventListener("mousedown", this.onResultsMouseDown), this.results.removeEventListener("combobox-commit", this.onCommit)
                    }
                    handleClear(r) {
                        r.preventDefault(), this.input.getAttribute("aria-expanded") === "true" && (this.input.setAttribute("aria-expanded", "false"), this.updateFeedbackForScreenReaders("Results hidden.")), this.input.value = "", this.container.value = "", this.input.focus(), this.input.dispatchEvent(new Event("change")), this.container.open = !1
                    }
                    onKeydown(r) {
                        if (r.key === "Enter" && this.container.open && this.autoselectEnabled) {
                            const c = this.results.children[0];
                            c && (r.stopPropagation(), r.preventDefault(), this.onCommit({
                                target: c
                            }))
                        }
                        if (r.key === "Escape" && this.container.open) this.container.open = !1, r.stopPropagation(), r.preventDefault();
                        else if (r.altKey && r.key === "ArrowUp" && this.container.open) this.container.open = !1, r.stopPropagation(), r.preventDefault();
                        else if (r.altKey && r.key === "ArrowDown" && !this.container.open) {
                            if (!this.input.value.trim()) return;
                            this.container.open = !0, r.stopPropagation(), r.preventDefault()
                        }
                    }
                    onInputFocus() {
                        this.fetchResults()
                    }
                    onInputBlur() {
                        if (this.interactingWithList) {
                            this.interactingWithList = !1;
                            return
                        }
                        this.container.open = !1
                    }
                    onCommit({
                        target: r
                    }) {
                        const c = r;
                        if (!(c instanceof HTMLElement) || (this.container.open = !1, c instanceof HTMLAnchorElement)) return;
                        const m = c.getAttribute("data-autocomplete-value") || c.textContent;
                        this.updateFeedbackForScreenReaders(`${c.textContent||""} selected.`), this.container.value = m, m || this.updateFeedbackForScreenReaders("Results hidden.")
                    }
                    onResultsMouseDown() {
                        this.interactingWithList = !0
                    }
                    onInputChange() {
                        this.feedback && this.feedback.innerHTML && (this.feedback.innerHTML = ""), this.container.removeAttribute("value"), this.fetchResults()
                    }
                    identifyOptions() {
                        let r = 0;
                        for (const c of this.results.querySelectorAll('[role="option"]:not([id])')) c.id = `${this.results.id}-option-${r++}`
                    }
                    updateFeedbackForScreenReaders(r) {
                        setTimeout(() => {
                            this.feedback && (this.feedback.innerHTML = r)
                        }, d)
                    }
                    fetchResults() {
                        const r = this.input.value.trim();
                        if (!r) {
                            this.container.open = !1;
                            return
                        }
                        const c = this.container.src;
                        if (!c) return;
                        const m = new URL(c, window.location.href),
                            A = new URLSearchParams(m.search.slice(1));
                        A.append("q", r), m.search = A.toString(), this.container.dispatchEvent(new CustomEvent("loadstart")), p(this.input, m.toString()).then(h => {
                            this.results.innerHTML = h, this.identifyOptions();
                            const k = this.results.querySelectorAll('[role="option"]'),
                                b = !!k.length,
                                E = k.length,
                                [g] = k,
                                L = g == null ? void 0 : g.textContent;
                            this.autoselectEnabled && L ? this.updateFeedbackForScreenReaders(`${E} results. ${L} is the top result: Press Enter to activate.`) : this.updateFeedbackForScreenReaders(`${E||"No"} results.`), this.container.open = b, this.container.dispatchEvent(new CustomEvent("load")), this.container.dispatchEvent(new CustomEvent("loadend"))
                        }).catch(() => {
                            this.container.dispatchEvent(new CustomEvent("error")), this.container.dispatchEvent(new CustomEvent("loadend"))
                        })
                    }
                    open() {
                        !this.results.hidden || (this.combobox.start(), this.results.hidden = !1)
                    }
                    close() {
                        this.results.hidden || (this.combobox.stop(), this.results.hidden = !0)
                    }
                }
                o(e, "Autocomplete");
                const n = new WeakMap;
                class t extends HTMLElement {
                    connectedCallback() {
                        const r = this.getAttribute("for");
                        if (!r) return;
                        const c = this.querySelector("input"),
                            m = document.getElementById(r);
                        if (!(c instanceof HTMLInputElement) || !m) return;
                        const A = this.getAttribute("data-autoselect") === "true";
                        n.set(this, new e(this, c, m, A)), m.setAttribute("role", "listbox")
                    }
                    disconnectedCallback() {
                        const r = n.get(this);
                        r && (r.destroy(), n.delete(this))
                    }
                    get src() {
                        return this.getAttribute("src") || ""
                    }
                    set src(r) {
                        this.setAttribute("src", r)
                    }
                    get value() {
                        return this.getAttribute("value") || ""
                    }
                    set value(r) {
                        this.setAttribute("value", r)
                    }
                    get open() {
                        return this.hasAttribute("open")
                    }
                    set open(r) {
                        r ? this.setAttribute("open", "") : this.removeAttribute("open")
                    }
                    static get observedAttributes() {
                        return ["open", "value"]
                    }
                    attributeChangedCallback(r, c, m) {
                        if (c === m) return;
                        const A = n.get(this);
                        if (!!A) switch (r) {
                            case "open":
                                m === null ? A.close() : A.open();
                                break;
                            case "value":
                                m !== null && (A.input.value = m), this.dispatchEvent(new u("auto-complete-change", {
                                    bubbles: !0,
                                    relatedTarget: A.input
                                }));
                                break
                        }
                    }
                }
                o(t, "AutocompleteElement"), window.customElements.get("auto-complete") || (window.AutocompleteElement = t, window.customElements.define("auto-complete", t));
                const a = t
            },
            10160: (D, x, M) => {
                M.d(x, {
                    Z: () => u
                });
                const v = !!navigator.userAgent.match(/Macintosh/);
                class u {
                    constructor(a, l) {
                        this.input = a, this.list = l, this.isComposing = !1, l.id || (l.id = `combobox-${Math.random().toString().slice(2,6)}`), this.keyboardEventHandler = r => S(r, this), this.compositionEventHandler = r => d(r, this), this.inputHandler = this.clearSelection.bind(this), a.setAttribute("role", "combobox"), a.setAttribute("aria-controls", l.id), a.setAttribute("aria-expanded", "false"), a.setAttribute("aria-autocomplete", "list"), a.setAttribute("aria-haspopup", "listbox")
                    }
                    destroy() {
                        this.clearSelection(), this.stop(), this.input.removeAttribute("role"), this.input.removeAttribute("aria-controls"), this.input.removeAttribute("aria-expanded"), this.input.removeAttribute("aria-autocomplete"), this.input.removeAttribute("aria-haspopup")
                    }
                    start() {
                        this.input.setAttribute("aria-expanded", "true"), this.input.addEventListener("compositionstart", this.compositionEventHandler), this.input.addEventListener("compositionend", this.compositionEventHandler), this.input.addEventListener("input", this.inputHandler), this.input.addEventListener("keydown", this.keyboardEventHandler), this.list.addEventListener("click", w)
                    }
                    stop() {
                        this.clearSelection(), this.input.setAttribute("aria-expanded", "false"), this.input.removeEventListener("compositionstart", this.compositionEventHandler), this.input.removeEventListener("compositionend", this.compositionEventHandler), this.input.removeEventListener("input", this.inputHandler), this.input.removeEventListener("keydown", this.keyboardEventHandler), this.list.removeEventListener("click", w)
                    }
                    navigate(a = 1) {
                        const l = Array.from(this.list.querySelectorAll('[aria-selected="true"]')).filter(y)[0],
                            r = Array.from(this.list.querySelectorAll('[role="option"]')).filter(y),
                            c = r.indexOf(l);
                        if (c === r.length - 1 && a === 1 || c === 0 && a === -1) {
                            this.clearSelection(), this.input.focus();
                            return
                        }
                        let m = a === 1 ? 0 : r.length - 1;
                        if (l && c >= 0) {
                            const h = c + a;
                            h >= 0 && h < r.length && (m = h)
                        }
                        const A = r[m];
                        if (!!A)
                            for (const h of r) A === h ? (this.input.setAttribute("aria-activedescendant", A.id), A.setAttribute("aria-selected", "true"), e(this.list, A)) : h.setAttribute("aria-selected", "false")
                    }
                    clearSelection() {
                        this.input.removeAttribute("aria-activedescendant");
                        for (const a of this.list.querySelectorAll('[aria-selected="true"]')) a.setAttribute("aria-selected", "false")
                    }
                }
                o(u, "Combobox");

                function S(t, a) {
                    if (!(t.shiftKey || t.metaKey || t.altKey) && !(!v && t.ctrlKey) && !a.isComposing) switch (t.key) {
                        case "Enter":
                        case "Tab":
                            p(a.input, a.list) && t.preventDefault();
                            break;
                        case "Escape":
                            a.clearSelection();
                            break;
                        case "ArrowDown":
                            a.navigate(1), t.preventDefault();
                            break;
                        case "ArrowUp":
                            a.navigate(-1), t.preventDefault();
                            break;
                        case "n":
                            v && t.ctrlKey && (a.navigate(1), t.preventDefault());
                            break;
                        case "p":
                            v && t.ctrlKey && (a.navigate(-1), t.preventDefault());
                            break;
                        default:
                            if (t.ctrlKey) break;
                            a.clearSelection()
                    }
                }
                o(S, "keyboardBindings");

                function w(t) {
                    if (!(t.target instanceof Element)) return;
                    const a = t.target.closest('[role="option"]');
                    !a || a.getAttribute("aria-disabled") !== "true" && T(a)
                }
                o(w, "commitWithElement");

                function p(t, a) {
                    const l = a.querySelector('[aria-selected="true"]');
                    return l ? (l.getAttribute("aria-disabled") === "true" || l.click(), !0) : !1
                }
                o(p, "commit");

                function T(t) {
                    t.dispatchEvent(new CustomEvent("combobox-commit", {
                        bubbles: !0
                    }))
                }
                o(T, "fireCommitEvent");

                function y(t) {
                    return !t.hidden && !(t instanceof HTMLInputElement && t.type === "hidden") && (t.offsetWidth > 0 || t.offsetHeight > 0)
                }
                o(y, "visible");

                function d(t, a) {
                    a.isComposing = t.type === "compositionstart", !!document.getElementById(a.input.getAttribute("aria-controls") || "") && a.clearSelection()
                }
                o(d, "trackComposition");

                function e(t, a) {
                    n(t, a) || (t.scrollTop = a.offsetTop)
                }
                o(e, "scrollTo");

                function n(t, a) {
                    const l = t.scrollTop,
                        r = l + t.clientHeight,
                        c = a.offsetTop,
                        m = c + a.clientHeight;
                    return c >= l && m <= r
                }
                o(n, "inViewport")
            },
            27034: (D, x, M) => {
                M.d(x, {
                    Z: () => d
                });
                const v = new WeakMap,
                    u = new IntersectionObserver(e => {
                        for (const n of e)
                            if (n.isIntersecting) {
                                const {
                                    target: t
                                } = n;
                                if (u.unobserve(t), !(t instanceof d)) return;
                                t.loading === "lazy" && w(t)
                            }
                    }, {
                        rootMargin: "0px 0px 256px 0px",
                        threshold: .01
                    });

                function S() {
                    return new Promise(e => setTimeout(e, 0))
                }
                o(S, "task");
                async function w(e) {
                    return u.unobserve(e), p(e).then(function(n) {
                        const t = document.createElement("template");
                        t.innerHTML = n;
                        const a = document.importNode(t.content, !0);
                        !e.dispatchEvent(new CustomEvent("include-fragment-replace", {
                            cancelable: !0,
                            detail: {
                                fragment: a
                            }
                        })) || (e.replaceWith(a), e.dispatchEvent(new CustomEvent("include-fragment-replaced")))
                    }, function() {
                        e.classList.add("is-error")
                    })
                }
                o(w, "handleData");

                function p(e) {
                    const n = e.src;
                    let t = v.get(e);
                    return t && t.src === n ? t.data : (n ? t = T(e) : t = Promise.reject(new Error("missing src")), v.set(e, {
                        src: n,
                        data: t
                    }), t)
                }
                o(p, "getData");

                function T(e) {
                    return S().then(() => (e.dispatchEvent(new Event("loadstart")), e.fetch(e.request()))).then(n => {
                        if (n.status !== 200) throw new Error(`Failed to load resource: the server responded with a status of ${n.status}`);
                        const t = n.headers.get("Content-Type");
                        if (!y(e.accept) && (!t || !t.includes(e.accept ? e.accept : "text/html"))) throw new Error(`Failed to load resource: expected ${e.accept||"text/html"} but was ${t}`);
                        return n.text()
                    }).then(n => (S().then(() => {
                        e.dispatchEvent(new Event("load")), e.dispatchEvent(new Event("loadend"))
                    }), n), n => {
                        throw S().then(() => {
                            e.dispatchEvent(new Event("error")), e.dispatchEvent(new Event("loadend"))
                        }), n
                    })
                }
                o(T, "fetchDataWithEvents");

                function y(e) {
                    return e && !!e.split(",").find(n => n.match(/^\s*\*\/\*/))
                }
                o(y, "isWildcard");
                class d extends HTMLElement {
                    static get observedAttributes() {
                        return ["src", "loading"]
                    }
                    get src() {
                        const n = this.getAttribute("src");
                        if (n) {
                            const t = this.ownerDocument.createElement("a");
                            return t.href = n, t.href
                        } else return ""
                    }
                    set src(n) {
                        this.setAttribute("src", n)
                    }
                    get loading() {
                        return this.getAttribute("loading") === "lazy" ? "lazy" : "eager"
                    }
                    set loading(n) {
                        this.setAttribute("loading", n)
                    }
                    get accept() {
                        return this.getAttribute("accept") || ""
                    }
                    set accept(n) {
                        this.setAttribute("accept", n)
                    }
                    get data() {
                        return p(this)
                    }
                    attributeChangedCallback(n, t) {
                        n === "src" ? this.isConnected && this.loading === "eager" && w(this) : n === "loading" && this.isConnected && t !== "eager" && this.loading === "eager" && w(this)
                    }
                    constructor() {
                        super();
                        this.attachShadow({
                            mode: "open"
                        }).innerHTML = `
      <style> 
        :host {
          display: block;
        }
      </style>
      <slot></slot>`
                    }
                    connectedCallback() {
                        this.src && this.loading === "eager" && w(this), this.loading === "lazy" && u.observe(this)
                    }
                    request() {
                        const n = this.src;
                        if (!n) throw new Error("missing src");
                        return new Request(n, {
                            method: "GET",
                            credentials: "same-origin",
                            headers: {
                                Accept: this.accept || "text/html"
                            }
                        })
                    }
                    load() {
                        return p(this)
                    }
                    fetch(n) {
                        return fetch(n)
                    }
                }
                o(d, "IncludeFragmentElement"), window.customElements.get("include-fragment") || (window.IncludeFragmentElement = d, window.customElements.define("include-fragment", d))
            },
            40987: (D, x, M) => {
                M.d(x, {
                    Z: () => l
                });
                const v = new WeakMap;
                let u = null;

                function S() {
                    return !!u
                }
                o(S, "isDragging");

                function w(i, s, f) {
                    v.set(i, {
                        sortStarted: s,
                        sortFinished: f
                    }), i.addEventListener("dragstart", y), i.addEventListener("dragenter", d), i.addEventListener("dragend", n), i.addEventListener("drop", e), i.addEventListener("dragover", t)
                }
                o(w, "sortable");

                function p(i, s) {
                    if (i.parentNode === s.parentNode) {
                        let f = i;
                        for (; f;) {
                            if (f === s) return !0;
                            f = f.previousElementSibling
                        }
                    }
                    return !1
                }
                o(p, "isBefore");

                function T(i, s) {
                    return i.closest("task-lists") === s.closest("task-lists")
                }
                o(T, "isSameContainer");

                function y(i) {
                    if (i.currentTarget !== i.target) return;
                    const s = i.currentTarget;
                    if (!(s instanceof Element)) return;
                    const f = s.closest(".contains-task-list");
                    if (!f || (s.classList.add("is-ghost"), i.dataTransfer && i.dataTransfer.setData("text/plain", (s.textContent || "").trim()), !s.parentElement)) return;
                    const C = Array.from(s.parentElement.children),
                        F = C.indexOf(s),
                        B = v.get(s);
                    B && B.sortStarted(f), u = {
                        didDrop: !1,
                        dragging: s,
                        dropzone: s,
                        sourceList: f,
                        sourceSibling: C[F + 1] || null,
                        sourceIndex: F
                    }
                }
                o(y, "onDragStart");

                function d(i) {
                    if (!u) return;
                    const s = i.currentTarget;
                    if (s instanceof Element) {
                        if (!T(u.dragging, s)) {
                            i.stopPropagation();
                            return
                        }
                        i.preventDefault(), i.dataTransfer && (i.dataTransfer.dropEffect = "move"), u.dropzone !== s && (u.dragging.classList.add("is-dragging"), u.dropzone = s, p(u.dragging, s) ? s.before(u.dragging) : s.after(u.dragging))
                    }
                }
                o(d, "onDragEnter");

                function e(i) {
                    if (!u) return;
                    i.preventDefault(), i.stopPropagation();
                    const s = i.currentTarget;
                    if (!(s instanceof Element) || (u.didDrop = !0, !u.dragging.parentElement)) return;
                    let f = Array.from(u.dragging.parentElement.children).indexOf(u.dragging);
                    const C = s.closest(".contains-task-list");
                    if (!C || u.sourceIndex === f && u.sourceList === C) return;
                    u.sourceList === C && u.sourceIndex < f && f++;
                    const F = {
                            list: u.sourceList,
                            index: u.sourceIndex
                        },
                        B = {
                            list: C,
                            index: f
                        },
                        N = v.get(u.dragging);
                    N && N.sortFinished({
                        src: F,
                        dst: B
                    })
                }
                o(e, "onDrop");

                function n() {
                    !u || (u.dragging.classList.remove("is-dragging"), u.dragging.classList.remove("is-ghost"), u.didDrop || u.sourceList.insertBefore(u.dragging, u.sourceSibling), u = null)
                }
                o(n, "onDragEnd");

                function t(i) {
                    if (!u) return;
                    const s = i.currentTarget;
                    if (s instanceof Element) {
                        if (!T(u.dragging, s)) {
                            i.stopPropagation();
                            return
                        }
                        i.preventDefault(), i.dataTransfer && (i.dataTransfer.dropEffect = "move")
                    }
                }
                o(t, "onDragOver");
                const a = new WeakMap;
                class l extends HTMLElement {
                    connectedCallback() {
                        this.addEventListener("change", f => {
                            const C = f.target;
                            C instanceof HTMLInputElement && (!C.classList.contains("task-list-item-checkbox") || this.dispatchEvent(new CustomEvent("task-lists-check", {
                                bubbles: !0,
                                detail: {
                                    position: k(C),
                                    checked: C.checked
                                }
                            })))
                        });
                        const s = new MutationObserver(L.bind(null, this));
                        a.set(this, s), s.observe(this, {
                            childList: !0,
                            subtree: !0
                        }), L(this)
                    }
                    disconnectedCallback() {
                        const s = a.get(this);
                        s && s.disconnect()
                    }
                    get disabled() {
                        return this.hasAttribute("disabled")
                    }
                    set disabled(s) {
                        s ? this.setAttribute("disabled", "") : this.removeAttribute("disabled")
                    }
                    get sortable() {
                        return this.hasAttribute("sortable")
                    }
                    set sortable(s) {
                        s ? this.setAttribute("sortable", "") : this.removeAttribute("sortable")
                    }
                    static get observedAttributes() {
                        return ["disabled"]
                    }
                    attributeChangedCallback(s, f, C) {
                        if (f !== C) switch (s) {
                            case "disabled":
                                R(this);
                                break
                        }
                    }
                }
                o(l, "TaskListsElement");
                const r = document.createElement("template");
                r.innerHTML = `
  <span class="handle">
    <svg class="drag-handle" aria-hidden="true" width="16" height="16">
      <path d="M10 13a1 1 0 100-2 1 1 0 000 2zm-4 0a1 1 0 100-2 1 1 0 000 2zm1-5a1 1 0 11-2 0 1 1 0 012 0zm3 1a1 1 0 100-2 1 1 0 000 2zm1-5a1 1 0 11-2 0 1 1 0 012 0zM6 5a1 1 0 100-2 1 1 0 000 2z"/>
    </svg>
  </span>`;
                const c = new WeakMap;

                function m(i) {
                    if (c.get(i)) return;
                    c.set(i, !0);
                    const s = i.closest("task-lists");
                    if (!(s instanceof l) || s.querySelectorAll(".task-list-item").length <= 1) return;
                    const f = r.content.cloneNode(!0),
                        C = f.querySelector(".handle");
                    if (i.prepend(f), !C) throw new Error("handle not found");
                    C.addEventListener("mouseenter", P), C.addEventListener("mouseleave", H), w(i, _, q), i.addEventListener("mouseenter", A), i.addEventListener("mouseleave", h)
                }
                o(m, "initItem");

                function A(i) {
                    const s = i.currentTarget;
                    if (!(s instanceof Element)) return;
                    const f = s.closest("task-lists");
                    f instanceof l && f.sortable && !f.disabled && s.classList.add("hovered")
                }
                o(A, "onListItemMouseOver");

                function h(i) {
                    const s = i.currentTarget;
                    s instanceof Element && s.classList.remove("hovered")
                }
                o(h, "onListItemMouseOut");

                function k(i) {
                    const s = b(i);
                    if (!s) throw new Error(".contains-task-list not found");
                    const f = i.closest(".task-list-item"),
                        C = Array.from(s.children).filter(B => B.tagName === "LI"),
                        F = f ? C.indexOf(f) : -1;
                    return [O(s), F]
                }
                o(k, "position");

                function b(i) {
                    const s = i.parentElement;
                    return s ? s.closest(".contains-task-list") : null
                }
                o(b, "taskList");

                function E(i) {
                    return b(i) === g(i)
                }
                o(E, "isRootTaskList");

                function g(i) {
                    const s = b(i);
                    return s ? g(s) || s : null
                }
                o(g, "rootTaskList");

                function L(i) {
                    const s = i.querySelectorAll(".contains-task-list > .task-list-item");
                    for (const f of s) E(f) && m(f);
                    R(i)
                }
                o(L, "syncState");

                function R(i) {
                    for (const s of i.querySelectorAll(".task-list-item")) s.classList.toggle("enabled", !i.disabled);
                    for (const s of i.querySelectorAll(".task-list-item-checkbox")) s instanceof HTMLInputElement && (s.disabled = i.disabled)
                }
                o(R, "syncDisabled");

                function O(i) {
                    const s = i.closest("task-lists");
                    if (!s) throw new Error("parent not found");
                    return Array.from(s.querySelectorAll("ol, ul")).indexOf(i)
                }
                o(O, "listIndex");
                const I = new WeakMap;

                function _(i) {
                    const s = i.closest("task-lists");
                    if (!s) throw new Error("parent not found");
                    I.set(s, Array.from(s.querySelectorAll("ol, ul")))
                }
                o(_, "onSortStart");

                function q({
                    src: i,
                    dst: s
                }) {
                    const f = i.list.closest("task-lists");
                    if (!f) return;
                    const C = I.get(f);
                    !C || (I.delete(f), f.dispatchEvent(new CustomEvent("task-lists-move", {
                        bubbles: !0,
                        detail: {
                            src: [C.indexOf(i.list), i.index],
                            dst: [C.indexOf(s.list), s.index]
                        }
                    })))
                }
                o(q, "onSorted");

                function P(i) {
                    const s = i.currentTarget;
                    if (!(s instanceof Element)) return;
                    const f = s.closest(".task-list-item");
                    if (!f) return;
                    const C = f.closest("task-lists");
                    C instanceof l && C.sortable && !C.disabled && f.setAttribute("draggable", "true")
                }
                o(P, "onHandleMouseOver");

                function H(i) {
                    if (S()) return;
                    const s = i.currentTarget;
                    if (!(s instanceof Element)) return;
                    const f = s.closest(".task-list-item");
                    !f || f.setAttribute("draggable", "false")
                }
                o(H, "onHandleMouseOut"), window.customElements.get("task-lists") || (window.TaskListsElement = l, window.customElements.define("task-lists", l))
            }
        }
    ]);
})();

//# sourceMappingURL=8630-a0da18b7df73.js.map