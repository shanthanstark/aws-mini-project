(() => {
    var ie = Object.defineProperty;
    var c = (D, C) => ie(D, "name", {
        value: C,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [6262], {
            52769: (D, C, k) => {
                "use strict";
                k.d(C, {
                    AI: () => _,
                    AL: () => Q,
                    CR: () => s,
                    F6: () => R,
                    Hl: () => Y,
                    KB: () => S,
                    TR: () => h,
                    XR: () => i,
                    jw: () => K,
                    mK: () => ee
                });

                function v(d, b) {
                    var E, x, I;
                    const H = d.value.slice(0, (E = d.selectionStart) !== null && E !== void 0 ? E : void 0),
                        z = d.value.slice((x = d.selectionEnd) !== null && x !== void 0 ? x : void 0);
                    let W = !0;
                    d.contentEditable = "true";
                    try {
                        W = document.execCommand("insertText", !1, b)
                    } catch {
                        W = !1
                    }
                    if (d.contentEditable = "false", W && !d.value.slice(0, (I = d.selectionStart) !== null && I !== void 0 ? I : void 0).endsWith(b) && (W = !1), !W) {
                        try {
                            document.execCommand("ms-beginUndoUnit")
                        } catch {}
                        d.value = H + b + z;
                        try {
                            document.execCommand("ms-endUndoUnit")
                        } catch {}
                        d.dispatchEvent(new CustomEvent("change", {
                            bubbles: !0,
                            cancelable: !0
                        }))
                    }
                }
                c(v, "insertText");

                function _(d) {
                    d.addEventListener("paste", y)
                }
                c(_, "install$4");

                function h(d) {
                    d.removeEventListener("paste", y)
                }
                c(h, "uninstall$4");

                function y(d) {
                    const b = d.clipboardData;
                    if (!b || !n(b)) return;
                    const E = d.currentTarget;
                    if (!(E instanceof HTMLTextAreaElement)) return;
                    let x = b.getData("text/plain");
                    const I = b.getData("text/html"),
                        H = I.replace(/\u00A0/g, " ").replace(/\uC2A0/g, " ");
                    if (!I || (x = x.trim(), !x)) return;
                    const W = new DOMParser().parseFromString(H, "text/html"),
                        B = W.createTreeWalker(W.body, NodeFilter.SHOW_ELEMENT),
                        Z = e(x, B);
                    Z !== x && (d.stopPropagation(), d.preventDefault(), v(E, Z))
                }
                c(y, "onPaste$4");

                function e(d, b) {
                    var E;
                    let x = b.firstChild(),
                        I = d,
                        H = 0,
                        z = 0;
                    const W = 1e4;
                    for (; x && z < W;) {
                        z++;
                        const B = t(x) ? x.textContent || "" : ((E = x.firstChild) === null || E === void 0 ? void 0 : E.wholeText) || "";
                        if (o(B)) {
                            x = b.nextNode();
                            continue
                        }
                        const Z = I.indexOf(B, H);
                        if (Z >= 0)
                            if (t(x)) {
                                const se = r(x);
                                I = I.slice(0, Z) + se + I.slice(Z + B.length), H = Z + se.length
                            } else H = Z + B.length;
                        x = b.nextNode()
                    }
                    return z === W ? d : I
                }
                c(e, "convertToMarkdown");

                function o(d) {
                    return !d || (d == null ? void 0 : d.trim().length) === 0
                }
                c(o, "isEmptyString");

                function t(d) {
                    var b;
                    return ((b = d.tagName) === null || b === void 0 ? void 0 : b.toLowerCase()) === "a" && d.hasAttribute("href")
                }
                c(t, "isLink");

                function n(d) {
                    return d.types.includes("text/html")
                }
                c(n, "hasHTML");

                function r(d) {
                    const b = d.textContent || "",
                        E = d.href || "";
                    let x = "";
                    return a(d) ? x = b : l(d) || u(E, b) ? x = E : x = `[${b}](${E})`, x
                }
                c(r, "linkify$2");

                function l(d) {
                    return d.className.indexOf("commit-link") >= 0 || !!d.getAttribute("data-hovercard-type") && d.getAttribute("data-hovercard-type") !== "user"
                }
                c(l, "isSpecialLink");

                function u(d, b) {
                    return d = d.slice(-1) === "/" ? d.slice(0, -1) : d, b = b.slice(-1) === "/" ? b.slice(0, -1) : b, d.toLowerCase() === b.toLowerCase()
                }
                c(u, "areEqualLinks");

                function a(d) {
                    var b;
                    return ((b = d.textContent) === null || b === void 0 ? void 0 : b.slice(0, 1)) === "@" && d.getAttribute("data-hovercard-type") === "user"
                }
                c(a, "isUserMention");

                function s(d) {
                    d.addEventListener("dragover", f), d.addEventListener("drop", m), d.addEventListener("paste", p)
                }
                c(s, "install$3");

                function i(d) {
                    d.removeEventListener("dragover", f), d.removeEventListener("drop", m), d.removeEventListener("paste", p)
                }
                c(i, "uninstall$3");

                function m(d) {
                    const b = d.dataTransfer;
                    if (!b || w(b) || !M(b)) return;
                    const E = L(b);
                    if (!E.some(q)) return;
                    d.stopPropagation(), d.preventDefault();
                    const x = d.currentTarget;
                    x instanceof HTMLTextAreaElement && v(x, E.map(g).join(""))
                }
                c(m, "onDrop$1");

                function f(d) {
                    const b = d.dataTransfer;
                    b && (b.dropEffect = "link")
                }
                c(f, "onDragover$1");

                function p(d) {
                    const b = d.clipboardData;
                    if (!b || !M(b)) return;
                    const E = L(b);
                    if (!E.some(q)) return;
                    d.stopPropagation(), d.preventDefault();
                    const x = d.currentTarget;
                    x instanceof HTMLTextAreaElement && v(x, E.map(g).join(""))
                }
                c(p, "onPaste$3");

                function g(d) {
                    return q(d) ? `
![](${d})
` : d
                }
                c(g, "linkify$1");

                function w(d) {
                    return Array.from(d.types).indexOf("Files") >= 0
                }
                c(w, "hasFile$1");

                function M(d) {
                    return Array.from(d.types).indexOf("text/uri-list") >= 0
                }
                c(M, "hasLink");

                function L(d) {
                    return (d.getData("text/uri-list") || "").split(`\r
`)
                }
                c(L, "extractLinks");
                const j = /\.(gif|png|jpe?g)$/i;

                function q(d) {
                    return j.test(d)
                }
                c(q, "isImageLink");

                function K(d) {
                    d.addEventListener("paste", J)
                }
                c(K, "install$2");

                function Y(d) {
                    d.removeEventListener("paste", J)
                }
                c(Y, "uninstall$2");

                function J(d) {
                    const b = d.clipboardData;
                    if (!b || !G(b)) return;
                    const E = d.currentTarget;
                    if (!(E instanceof HTMLTextAreaElement)) return;
                    const x = b.getData("text/plain");
                    if (!x || !A(x) || P(E)) return;
                    const I = E.value.substring(E.selectionStart, E.selectionEnd);
                    !I.length || A(I.trim()) || (d.stopPropagation(), d.preventDefault(), v(E, T(I, x)))
                }
                c(J, "onPaste$2");

                function G(d) {
                    return Array.from(d.types).includes("text/plain")
                }
                c(G, "hasPlainText");

                function P(d) {
                    const b = d.selectionStart || 0;
                    return b > 1 ? d.value.substring(b - 2, b) === "](" : !1
                }
                c(P, "isWithinLink");

                function T(d, b) {
                    return `[${d}](${b})`
                }
                c(T, "linkify");

                function A(d) {
                    return /^https?:\/\//i.test(d)
                }
                c(A, "isURL");

                function R(d) {
                    d.addEventListener("dragover", O), d.addEventListener("drop", N), d.addEventListener("paste", F)
                }
                c(R, "install$1");

                function S(d) {
                    d.removeEventListener("dragover", O), d.removeEventListener("drop", N), d.removeEventListener("paste", F)
                }
                c(S, "uninstall$1");

                function N(d) {
                    const b = d.dataTransfer;
                    if (!b || U(b)) return;
                    const E = ne(b);
                    if (!E) return;
                    d.stopPropagation(), d.preventDefault();
                    const x = d.currentTarget;
                    x instanceof HTMLTextAreaElement && v(x, E)
                }
                c(N, "onDrop");

                function O(d) {
                    const b = d.dataTransfer;
                    b && (b.dropEffect = "copy")
                }
                c(O, "onDragover");

                function F(d) {
                    if (!d.clipboardData) return;
                    const b = ne(d.clipboardData);
                    if (!b) return;
                    d.stopPropagation(), d.preventDefault();
                    const E = d.currentTarget;
                    E instanceof HTMLTextAreaElement && v(E, b)
                }
                c(F, "onPaste$1");

                function U(d) {
                    return Array.from(d.types).indexOf("Files") >= 0
                }
                c(U, "hasFile");

                function $(d) {
                    const b = "\xA0";
                    return (d.textContent || "").trim().replace(/\|/g, "\\|").replace(/\n/g, " ") || b
                }
                c($, "columnText");

                function X(d) {
                    return Array.from(d.querySelectorAll("td, th")).map($)
                }
                c(X, "tableHeaders");

                function V(d) {
                    const b = Array.from(d.querySelectorAll("tr")),
                        E = b.shift();
                    if (!E) return "";
                    const x = X(E),
                        I = x.map(() => "--"),
                        H = `${x.join(" | ")}
${I.join(" | ")}
`,
                        z = b.map(W => Array.from(W.querySelectorAll("td")).map($).join(" | ")).join(`
`);
                    return `
${H}${z}

`
                }
                c(V, "tableMarkdown");

                function ne(d) {
                    if (Array.from(d.types).indexOf("text/html") === -1) return;
                    const b = d.getData("text/html");
                    if (!/<table/i.test(b)) return;
                    let I = new DOMParser().parseFromString(b, "text/html").querySelector("table");
                    if (I = !I || I.closest("[data-paste-markdown-skip]") ? null : I, !I) return;
                    const H = V(I);
                    return b.replace(/<meta.*?>/, "").replace(/<table[.\S\s]*<\/table>/, `
${H}`)
                }
                c(ne, "generateText");

                function Q(d) {
                    d.addEventListener("paste", te)
                }
                c(Q, "install");

                function ee(d) {
                    d.removeEventListener("paste", te)
                }
                c(ee, "uninstall");

                function te(d) {
                    const b = d.clipboardData;
                    if (!b || !re(b)) return;
                    const E = d.currentTarget;
                    if (!(E instanceof HTMLTextAreaElement)) return;
                    const x = b.getData("text/x-gfm");
                    !x || (d.stopPropagation(), d.preventDefault(), v(E, x))
                }
                c(te, "onPaste");

                function re(d) {
                    return Array.from(d.types).indexOf("text/x-gfm") >= 0
                }
                c(re, "hasMarkdown");

                function oe(d) {
                    return R(d), s(d), K(d), Q(d), _(d), {
                        unsubscribe: () => {
                            S(d), h(d), i(d), Y(d), ee(d)
                        }
                    }
                }
                c(oe, "subscribe")
            },
            55498: (D, C, k) => {
                "use strict";
                k.d(C, {
                    I: () => a,
                    p: () => u
                });

                function v(s) {
                    const i = s.parentNode;
                    if (i === null || !(i instanceof HTMLElement)) throw new Error;
                    let m = 0;
                    i instanceof HTMLOListElement && i.start !== 1 && (m = i.start - 1);
                    const f = i.children;
                    for (let p = 0; p < f.length; ++p)
                        if (f[p] === s) return m + p;
                    return m
                }
                c(v, "indexInList");

                function _(s) {
                    if (s instanceof HTMLAnchorElement && s.childNodes.length === 1) {
                        const i = s.childNodes[0];
                        if (i instanceof HTMLImageElement) return i.src === s.href
                    }
                    return !1
                }
                c(_, "skipNode");

                function h(s) {
                    return s.nodeName === "IMG" || s.firstChild != null
                }
                c(h, "hasContent");

                function y(s) {
                    return s.nodeName === "INPUT" && s instanceof HTMLInputElement && s.type === "checkbox"
                }
                c(y, "isCheckbox");
                let e = 0;

                function o(s) {
                    const i = s.childNodes[0],
                        m = s.childNodes[1];
                    return i && s.childNodes.length < 3 ? (i.nodeName === "OL" || i.nodeName === "UL") && (!m || m.nodeType === Node.TEXT_NODE && !(m.textContent || "").trim()) : !1
                }
                c(o, "nestedListExclusive");

                function t(s) {
                    return s.replace(/&/g, "&amp;").replace(/'/g, "&apos;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                }
                c(t, "escapeAttribute");
                const n = {
                    INPUT(s) {
                        return s instanceof HTMLInputElement && s.checked ? "[x] " : "[ ] "
                    },
                    CODE(s) {
                        const i = s.textContent || "";
                        return s.parentNode && s.parentNode.nodeName === "PRE" ? (s.textContent = `\`\`\`
${i.replace(/\n+$/,"")}
\`\`\`

`, s) : i.indexOf("`") >= 0 ? `\`\` ${i} \`\`` : `\`${i}\``
                    },
                    P(s) {
                        const i = document.createElement("p"),
                            m = s.textContent || "";
                        return i.textContent = m.replace(/<(\/?)(pre|strong|weak|em)>/g, "\\<$1$2\\>"), i
                    },
                    STRONG(s) {
                        return `**${s.textContent||""}**`
                    },
                    EM(s) {
                        return `_${s.textContent||""}_`
                    },
                    DEL(s) {
                        return `~${s.textContent||""}~`
                    },
                    BLOCKQUOTE(s) {
                        const i = (s.textContent || "").trim().replace(/^/gm, "> "),
                            m = document.createElement("pre");
                        return m.textContent = `${i}

`, m
                    },
                    A(s) {
                        const i = s.textContent || "",
                            m = s.getAttribute("href");
                        return /^https?:/.test(i) && i === m ? i : m ? `[${i}](${m})` : i
                    },
                    IMG(s) {
                        const i = s.getAttribute("alt") || "",
                            m = s.getAttribute("src");
                        if (!m) throw new Error;
                        const f = s.hasAttribute("width") ? ` width="${t(s.getAttribute("width")||"")}"` : "",
                            p = s.hasAttribute("height") ? ` height="${t(s.getAttribute("height")||"")}"` : "";
                        return f || p ? `<img alt="${t(i)}"${f}${p} src="${t(m)}">` : `![${i}](${m})`
                    },
                    LI(s) {
                        const i = s.parentNode;
                        if (!i) throw new Error;
                        let m = "";
                        o(s) || (i.nodeName === "OL" ? e > 0 && !i.previousSibling ? m = `${v(s)+e+1}\\. ` : m = `${v(s)+1}. ` : m = "* ");
                        const f = m.replace(/\S/g, " "),
                            p = (s.textContent || "").trim().replace(/^/gm, f),
                            g = document.createElement("pre");
                        return g.textContent = p.replace(f, m), g
                    },
                    OL(s) {
                        const i = document.createElement("li");
                        return i.appendChild(document.createElement("br")), s.append(i), s
                    },
                    H1(s) {
                        const i = parseInt(s.nodeName.slice(1));
                        return s.prepend(`${Array(i+1).join("#")} `), s
                    },
                    UL(s) {
                        return s
                    }
                };
                n.UL = n.OL;
                for (let s = 2; s <= 6; ++s) n[`H${s}`] = n.H1;

                function r(s) {
                    const i = document.createNodeIterator(s, NodeFilter.SHOW_ELEMENT, {
                            acceptNode(p) {
                                return p.nodeName in n && !_(p) && (h(p) || y(p)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                            }
                        }),
                        m = [];
                    let f = i.nextNode();
                    for (; f;) f instanceof HTMLElement && m.push(f), f = i.nextNode();
                    m.reverse();
                    for (const p of m) p.replaceWith(n[p.nodeName](p))
                }
                c(r, "insertMarkdownSyntax");

                function l(s, i) {
                    const m = s.startContainer;
                    if (!m || !m.parentNode || !(m.parentNode instanceof HTMLElement)) throw new Error("the range must start within an HTMLElement");
                    const f = m.parentNode;
                    let p = s.cloneContents();
                    if (i) {
                        const M = p.querySelector(i);
                        M && (p = document.createDocumentFragment(), p.appendChild(M))
                    }
                    e = 0;
                    const g = f.closest("li");
                    if (f.closest("pre")) {
                        const M = document.createElement("pre");
                        M.appendChild(p), p = document.createDocumentFragment(), p.appendChild(M)
                    } else if (g && g.parentNode && (g.parentNode.nodeName === "OL" && (e = v(g)), !p.querySelector("li"))) {
                        const M = document.createElement("li");
                        if (!g.parentNode) throw new Error;
                        const L = document.createElement(g.parentNode.nodeName);
                        M.appendChild(p), L.appendChild(M), p = document.createDocumentFragment(), p.appendChild(L)
                    }
                    return p
                }
                c(l, "extractFragment");
                class u {
                    constructor() {
                        this.selection = window.getSelection()
                    }
                    closest(i) {
                        const m = this.range.startContainer,
                            f = m instanceof Element ? m : m.parentElement;
                        return f ? f.closest(i) : null
                    }
                    get active() {
                        var i;
                        return (((i = this.selection) === null || i === void 0 ? void 0 : i.rangeCount) || 0) > 0
                    }
                    get range() {
                        var i;
                        return ((i = this.selection) === null || i === void 0 ? void 0 : i.rangeCount) ? this.selection.getRangeAt(0) : new Range
                    }
                    set range(i) {
                        var m, f;
                        (m = this.selection) === null || m === void 0 || m.removeAllRanges(), (f = this.selection) === null || f === void 0 || f.addRange(i)
                    }
                    get selectionText() {
                        var i;
                        return ((i = this.selection) === null || i === void 0 ? void 0 : i.toString().trim()) || ""
                    }
                    get quotedText() {
                        return `> ${this.selectionText.replace(/\n/g,`
> `)}

`
                    }
                    select(i) {
                        this.selection && (this.selection.removeAllRanges(), this.selection.selectAllChildren(i))
                    }
                    insert(i) {
                        i.value ? i.value = `${i.value}

${this.quotedText}` : i.value = this.quotedText, i.dispatchEvent(new CustomEvent("change", {
                            bubbles: !0,
                            cancelable: !1
                        })), i.focus(), i.selectionStart = i.value.length, i.scrollTop = i.scrollHeight
                    }
                }
                c(u, "Quote");
                class a extends u {
                    constructor(i = "", m) {
                        super();
                        this.scopeSelector = i, this.callback = m
                    }
                    get selectionText() {
                        var i, m;
                        if (!this.selection) return "";
                        const f = l(this.range, (i = this.scopeSelector) !== null && i !== void 0 ? i : "");
                        (m = this.callback) === null || m === void 0 || m.call(this, f), r(f);
                        const p = document.body;
                        if (!p) return "";
                        const g = document.createElement("div");
                        g.appendChild(f), g.style.cssText = "position:absolute;left:-9999px;", p.appendChild(g);
                        let w = "";
                        try {
                            const M = document.createRange();
                            M.selectNodeContents(g), this.selection.removeAllRanges(), this.selection.addRange(M), w = this.selection.toString(), this.selection.removeAllRanges(), M.detach()
                        } finally {
                            p.removeChild(g)
                        }
                        return w.trim()
                    }
                }
                c(a, "MarkdownQuote")
            },
            407: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Xm: () => h,
                    e6: () => y,
                    iO: () => e
                });
                let v = null;

                function _(o) {
                    return !!o.id && o.value !== o.defaultValue && o.form !== v
                }
                c(_, "shouldResumeField");

                function h(o, t) {
                    var n, r;
                    const l = (n = t == null ? void 0 : t.selector) !== null && n !== void 0 ? n : ".js-session-resumable",
                        a = `${(r=t==null?void 0:t.keyPrefix)!==null&&r!==void 0?r:"session-resume:"}${o}`,
                        s = [];
                    for (const m of document.querySelectorAll(l))(m instanceof HTMLInputElement || m instanceof HTMLTextAreaElement) && s.push(m);
                    let i = s.filter(m => _(m)).map(m => [m.id, m.value]);
                    if (i.length) try {
                        const m = sessionStorage.getItem(a);
                        if (m !== null) {
                            const p = JSON.parse(m).filter(function(g) {
                                return !i.some(w => w[0] === g[0])
                            });
                            i = i.concat(p)
                        }
                        sessionStorage.setItem(a, JSON.stringify(i))
                    } catch {}
                }
                c(h, "persistResumableFields");

                function y(o, t) {
                    var n;
                    const l = `${(n=t==null?void 0:t.keyPrefix)!==null&&n!==void 0?n:"session-resume:"}${o}`;
                    let u;
                    try {
                        u = sessionStorage.getItem(l)
                    } catch {}
                    if (!u) return;
                    const a = [],
                        s = [];
                    for (const [i, m] of JSON.parse(u)) {
                        const f = new CustomEvent("session:resume", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                targetId: i,
                                targetValue: m
                            }
                        });
                        if (document.dispatchEvent(f)) {
                            const p = document.getElementById(i);
                            p && (p instanceof HTMLInputElement || p instanceof HTMLTextAreaElement) ? p.value === p.defaultValue && (p.value = m, a.push(p)) : s.push([i, m])
                        }
                    }
                    if (s.length === 0) try {
                        sessionStorage.removeItem(l)
                    } catch {} else sessionStorage.setItem(l, JSON.stringify(s));
                    setTimeout(function() {
                        for (const i of a) i.dispatchEvent(new CustomEvent("change", {
                            bubbles: !0,
                            cancelable: !0
                        }))
                    }, 0)
                }
                c(y, "restoreResumableFields");

                function e(o) {
                    v = o.target, setTimeout(function() {
                        o.defaultPrevented && (v = null)
                    }, 0)
                }
                c(e, "setForm")
            },
            54430: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => _
                });

                function v(h) {
                    var y = null,
                        e = !1,
                        o = void 0,
                        t = void 0,
                        n = void 0;

                    function r(f) {
                        if (o !== f.clientX || t !== f.clientY) {
                            var p = h.style.height;
                            n && n !== p && (e = !0, h.style.maxHeight = "", h.removeEventListener("mousemove", r)), n = p
                        }
                        o = f.clientX, t = f.clientY
                    }
                    c(r, "onUserResize");
                    var l = h.ownerDocument,
                        u = l.documentElement;

                    function a() {
                        for (var f = 0, p = h; p !== l.body && p !== null;) f += p.offsetTop || 0, p = p.offsetParent;
                        var g = f - l.defaultView.pageYOffset,
                            w = u.clientHeight - (g + h.offsetHeight);
                        return {
                            top: g,
                            bottom: w
                        }
                    }
                    c(a, "overflowOffset");

                    function s() {
                        if (!e && h.value !== y && !(h.offsetWidth <= 0 && h.offsetHeight <= 0)) {
                            var f = a(),
                                p = f.top,
                                g = f.bottom;
                            if (!(p < 0 || g < 0)) {
                                var w = Number(getComputedStyle(h).height.replace(/px/, "")) + g;
                                h.style.maxHeight = w - 100 + "px";
                                var M = h.parentElement;
                                if (M instanceof HTMLElement) {
                                    var L = M.style.height;
                                    M.style.height = getComputedStyle(M).height, h.style.height = "auto", h.style.height = h.scrollHeight + "px", M.style.height = L, n = h.style.height
                                }
                                y = h.value
                            }
                        }
                    }
                    c(s, "sizeToFit");

                    function i() {
                        e = !1, h.style.height = "", h.style.maxHeight = ""
                    }
                    c(i, "onFormReset"), h.addEventListener("mousemove", r), h.addEventListener("input", s), h.addEventListener("change", s);
                    var m = h.form;
                    return m && m.addEventListener("reset", i), h.value && s(), {
                        unsubscribe: c(function() {
                            h.removeEventListener("mousemove", r), h.removeEventListener("input", s), h.removeEventListener("change", s), m && m.removeEventListener("reset", i)
                        }, "unsubscribe")
                    }
                }
                c(v, "autosize");
                const _ = v
            },
            48168: (D, C, k) => {
                const v = k(39092),
                    _ = {};
                for (const e of Object.keys(v)) _[v[e]] = e;
                const h = {
                    rgb: {
                        channels: 3,
                        labels: "rgb"
                    },
                    hsl: {
                        channels: 3,
                        labels: "hsl"
                    },
                    hsv: {
                        channels: 3,
                        labels: "hsv"
                    },
                    hwb: {
                        channels: 3,
                        labels: "hwb"
                    },
                    cmyk: {
                        channels: 4,
                        labels: "cmyk"
                    },
                    xyz: {
                        channels: 3,
                        labels: "xyz"
                    },
                    lab: {
                        channels: 3,
                        labels: "lab"
                    },
                    lch: {
                        channels: 3,
                        labels: "lch"
                    },
                    hex: {
                        channels: 1,
                        labels: ["hex"]
                    },
                    keyword: {
                        channels: 1,
                        labels: ["keyword"]
                    },
                    ansi16: {
                        channels: 1,
                        labels: ["ansi16"]
                    },
                    ansi256: {
                        channels: 1,
                        labels: ["ansi256"]
                    },
                    hcg: {
                        channels: 3,
                        labels: ["h", "c", "g"]
                    },
                    apple: {
                        channels: 3,
                        labels: ["r16", "g16", "b16"]
                    },
                    gray: {
                        channels: 1,
                        labels: ["gray"]
                    }
                };
                D.exports = h;
                for (const e of Object.keys(h)) {
                    if (!("channels" in h[e])) throw new Error("missing channels property: " + e);
                    if (!("labels" in h[e])) throw new Error("missing channel labels property: " + e);
                    if (h[e].labels.length !== h[e].channels) throw new Error("channel and label counts mismatch: " + e);
                    const {
                        channels: o,
                        labels: t
                    } = h[e];
                    delete h[e].channels, delete h[e].labels, Object.defineProperty(h[e], "channels", {
                        value: o
                    }), Object.defineProperty(h[e], "labels", {
                        value: t
                    })
                }
                h.rgb.hsl = function(e) {
                    const o = e[0] / 255,
                        t = e[1] / 255,
                        n = e[2] / 255,
                        r = Math.min(o, t, n),
                        l = Math.max(o, t, n),
                        u = l - r;
                    let a, s;
                    l === r ? a = 0 : o === l ? a = (t - n) / u : t === l ? a = 2 + (n - o) / u : n === l && (a = 4 + (o - t) / u), a = Math.min(a * 60, 360), a < 0 && (a += 360);
                    const i = (r + l) / 2;
                    return l === r ? s = 0 : i <= .5 ? s = u / (l + r) : s = u / (2 - l - r), [a, s * 100, i * 100]
                }, h.rgb.hsv = function(e) {
                    let o, t, n, r, l;
                    const u = e[0] / 255,
                        a = e[1] / 255,
                        s = e[2] / 255,
                        i = Math.max(u, a, s),
                        m = i - Math.min(u, a, s),
                        f = c(function(p) {
                            return (i - p) / 6 / m + 1 / 2
                        }, "diffc");
                    return m === 0 ? (r = 0, l = 0) : (l = m / i, o = f(u), t = f(a), n = f(s), u === i ? r = n - t : a === i ? r = 1 / 3 + o - n : s === i && (r = 2 / 3 + t - o), r < 0 ? r += 1 : r > 1 && (r -= 1)), [r * 360, l * 100, i * 100]
                }, h.rgb.hwb = function(e) {
                    const o = e[0],
                        t = e[1];
                    let n = e[2];
                    const r = h.rgb.hsl(e)[0],
                        l = 1 / 255 * Math.min(o, Math.min(t, n));
                    return n = 1 - 1 / 255 * Math.max(o, Math.max(t, n)), [r, l * 100, n * 100]
                }, h.rgb.cmyk = function(e) {
                    const o = e[0] / 255,
                        t = e[1] / 255,
                        n = e[2] / 255,
                        r = Math.min(1 - o, 1 - t, 1 - n),
                        l = (1 - o - r) / (1 - r) || 0,
                        u = (1 - t - r) / (1 - r) || 0,
                        a = (1 - n - r) / (1 - r) || 0;
                    return [l * 100, u * 100, a * 100, r * 100]
                };

                function y(e, o) {
                    return (e[0] - o[0]) ** 2 + (e[1] - o[1]) ** 2 + (e[2] - o[2]) ** 2
                }
                c(y, "comparativeDistance"), h.rgb.keyword = function(e) {
                    const o = _[e];
                    if (o) return o;
                    let t = 1 / 0,
                        n;
                    for (const r of Object.keys(v)) {
                        const l = v[r],
                            u = y(e, l);
                        u < t && (t = u, n = r)
                    }
                    return n
                }, h.keyword.rgb = function(e) {
                    return v[e]
                }, h.rgb.xyz = function(e) {
                    let o = e[0] / 255,
                        t = e[1] / 255,
                        n = e[2] / 255;
                    o = o > .04045 ? ((o + .055) / 1.055) ** 2.4 : o / 12.92, t = t > .04045 ? ((t + .055) / 1.055) ** 2.4 : t / 12.92, n = n > .04045 ? ((n + .055) / 1.055) ** 2.4 : n / 12.92;
                    const r = o * .4124 + t * .3576 + n * .1805,
                        l = o * .2126 + t * .7152 + n * .0722,
                        u = o * .0193 + t * .1192 + n * .9505;
                    return [r * 100, l * 100, u * 100]
                }, h.rgb.lab = function(e) {
                    const o = h.rgb.xyz(e);
                    let t = o[0],
                        n = o[1],
                        r = o[2];
                    t /= 95.047, n /= 100, r /= 108.883, t = t > .008856 ? t ** (1 / 3) : 7.787 * t + 16 / 116, n = n > .008856 ? n ** (1 / 3) : 7.787 * n + 16 / 116, r = r > .008856 ? r ** (1 / 3) : 7.787 * r + 16 / 116;
                    const l = 116 * n - 16,
                        u = 500 * (t - n),
                        a = 200 * (n - r);
                    return [l, u, a]
                }, h.hsl.rgb = function(e) {
                    const o = e[0] / 360,
                        t = e[1] / 100,
                        n = e[2] / 100;
                    let r, l, u;
                    if (t === 0) return u = n * 255, [u, u, u];
                    n < .5 ? r = n * (1 + t) : r = n + t - n * t;
                    const a = 2 * n - r,
                        s = [0, 0, 0];
                    for (let i = 0; i < 3; i++) l = o + 1 / 3 * -(i - 1), l < 0 && l++, l > 1 && l--, 6 * l < 1 ? u = a + (r - a) * 6 * l : 2 * l < 1 ? u = r : 3 * l < 2 ? u = a + (r - a) * (2 / 3 - l) * 6 : u = a, s[i] = u * 255;
                    return s
                }, h.hsl.hsv = function(e) {
                    const o = e[0];
                    let t = e[1] / 100,
                        n = e[2] / 100,
                        r = t;
                    const l = Math.max(n, .01);
                    n *= 2, t *= n <= 1 ? n : 2 - n, r *= l <= 1 ? l : 2 - l;
                    const u = (n + t) / 2,
                        a = n === 0 ? 2 * r / (l + r) : 2 * t / (n + t);
                    return [o, a * 100, u * 100]
                }, h.hsv.rgb = function(e) {
                    const o = e[0] / 60,
                        t = e[1] / 100;
                    let n = e[2] / 100;
                    const r = Math.floor(o) % 6,
                        l = o - Math.floor(o),
                        u = 255 * n * (1 - t),
                        a = 255 * n * (1 - t * l),
                        s = 255 * n * (1 - t * (1 - l));
                    switch (n *= 255, r) {
                        case 0:
                            return [n, s, u];
                        case 1:
                            return [a, n, u];
                        case 2:
                            return [u, n, s];
                        case 3:
                            return [u, a, n];
                        case 4:
                            return [s, u, n];
                        case 5:
                            return [n, u, a]
                    }
                }, h.hsv.hsl = function(e) {
                    const o = e[0],
                        t = e[1] / 100,
                        n = e[2] / 100,
                        r = Math.max(n, .01);
                    let l, u;
                    u = (2 - t) * n;
                    const a = (2 - t) * r;
                    return l = t * r, l /= a <= 1 ? a : 2 - a, l = l || 0, u /= 2, [o, l * 100, u * 100]
                }, h.hwb.rgb = function(e) {
                    const o = e[0] / 360;
                    let t = e[1] / 100,
                        n = e[2] / 100;
                    const r = t + n;
                    let l;
                    r > 1 && (t /= r, n /= r);
                    const u = Math.floor(6 * o),
                        a = 1 - n;
                    l = 6 * o - u, (u & 1) !== 0 && (l = 1 - l);
                    const s = t + l * (a - t);
                    let i, m, f;
                    switch (u) {
                        default:
                            case 6:
                            case 0:
                            i = a,
                        m = s,
                        f = t;
                        break;
                        case 1:
                                i = s,
                            m = a,
                            f = t;
                            break;
                        case 2:
                                i = t,
                            m = a,
                            f = s;
                            break;
                        case 3:
                                i = t,
                            m = s,
                            f = a;
                            break;
                        case 4:
                                i = s,
                            m = t,
                            f = a;
                            break;
                        case 5:
                                i = a,
                            m = t,
                            f = s;
                            break
                    }
                    return [i * 255, m * 255, f * 255]
                }, h.cmyk.rgb = function(e) {
                    const o = e[0] / 100,
                        t = e[1] / 100,
                        n = e[2] / 100,
                        r = e[3] / 100,
                        l = 1 - Math.min(1, o * (1 - r) + r),
                        u = 1 - Math.min(1, t * (1 - r) + r),
                        a = 1 - Math.min(1, n * (1 - r) + r);
                    return [l * 255, u * 255, a * 255]
                }, h.xyz.rgb = function(e) {
                    const o = e[0] / 100,
                        t = e[1] / 100,
                        n = e[2] / 100;
                    let r, l, u;
                    return r = o * 3.2406 + t * -1.5372 + n * -.4986, l = o * -.9689 + t * 1.8758 + n * .0415, u = o * .0557 + t * -.204 + n * 1.057, r = r > .0031308 ? 1.055 * r ** (1 / 2.4) - .055 : r * 12.92, l = l > .0031308 ? 1.055 * l ** (1 / 2.4) - .055 : l * 12.92, u = u > .0031308 ? 1.055 * u ** (1 / 2.4) - .055 : u * 12.92, r = Math.min(Math.max(0, r), 1), l = Math.min(Math.max(0, l), 1), u = Math.min(Math.max(0, u), 1), [r * 255, l * 255, u * 255]
                }, h.xyz.lab = function(e) {
                    let o = e[0],
                        t = e[1],
                        n = e[2];
                    o /= 95.047, t /= 100, n /= 108.883, o = o > .008856 ? o ** (1 / 3) : 7.787 * o + 16 / 116, t = t > .008856 ? t ** (1 / 3) : 7.787 * t + 16 / 116, n = n > .008856 ? n ** (1 / 3) : 7.787 * n + 16 / 116;
                    const r = 116 * t - 16,
                        l = 500 * (o - t),
                        u = 200 * (t - n);
                    return [r, l, u]
                }, h.lab.xyz = function(e) {
                    const o = e[0],
                        t = e[1],
                        n = e[2];
                    let r, l, u;
                    l = (o + 16) / 116, r = t / 500 + l, u = l - n / 200;
                    const a = l ** 3,
                        s = r ** 3,
                        i = u ** 3;
                    return l = a > .008856 ? a : (l - 16 / 116) / 7.787, r = s > .008856 ? s : (r - 16 / 116) / 7.787, u = i > .008856 ? i : (u - 16 / 116) / 7.787, r *= 95.047, l *= 100, u *= 108.883, [r, l, u]
                }, h.lab.lch = function(e) {
                    const o = e[0],
                        t = e[1],
                        n = e[2];
                    let r;
                    r = Math.atan2(n, t) * 360 / 2 / Math.PI, r < 0 && (r += 360);
                    const u = Math.sqrt(t * t + n * n);
                    return [o, u, r]
                }, h.lch.lab = function(e) {
                    const o = e[0],
                        t = e[1],
                        r = e[2] / 360 * 2 * Math.PI,
                        l = t * Math.cos(r),
                        u = t * Math.sin(r);
                    return [o, l, u]
                }, h.rgb.ansi16 = function(e, o = null) {
                    const [t, n, r] = e;
                    let l = o === null ? h.rgb.hsv(e)[2] : o;
                    if (l = Math.round(l / 50), l === 0) return 30;
                    let u = 30 + (Math.round(r / 255) << 2 | Math.round(n / 255) << 1 | Math.round(t / 255));
                    return l === 2 && (u += 60), u
                }, h.hsv.ansi16 = function(e) {
                    return h.rgb.ansi16(h.hsv.rgb(e), e[2])
                }, h.rgb.ansi256 = function(e) {
                    const o = e[0],
                        t = e[1],
                        n = e[2];
                    return o === t && t === n ? o < 8 ? 16 : o > 248 ? 231 : Math.round((o - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(o / 255 * 5) + 6 * Math.round(t / 255 * 5) + Math.round(n / 255 * 5)
                }, h.ansi16.rgb = function(e) {
                    let o = e % 10;
                    if (o === 0 || o === 7) return e > 50 && (o += 3.5), o = o / 10.5 * 255, [o, o, o];
                    const t = (~~(e > 50) + 1) * .5,
                        n = (o & 1) * t * 255,
                        r = (o >> 1 & 1) * t * 255,
                        l = (o >> 2 & 1) * t * 255;
                    return [n, r, l]
                }, h.ansi256.rgb = function(e) {
                    if (e >= 232) {
                        const l = (e - 232) * 10 + 8;
                        return [l, l, l]
                    }
                    e -= 16;
                    let o;
                    const t = Math.floor(e / 36) / 5 * 255,
                        n = Math.floor((o = e % 36) / 6) / 5 * 255,
                        r = o % 6 / 5 * 255;
                    return [t, n, r]
                }, h.rgb.hex = function(e) {
                    const t = (((Math.round(e[0]) & 255) << 16) + ((Math.round(e[1]) & 255) << 8) + (Math.round(e[2]) & 255)).toString(16).toUpperCase();
                    return "000000".substring(t.length) + t
                }, h.hex.rgb = function(e) {
                    const o = e.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
                    if (!o) return [0, 0, 0];
                    let t = o[0];
                    o[0].length === 3 && (t = t.split("").map(a => a + a).join(""));
                    const n = parseInt(t, 16),
                        r = n >> 16 & 255,
                        l = n >> 8 & 255,
                        u = n & 255;
                    return [r, l, u]
                }, h.rgb.hcg = function(e) {
                    const o = e[0] / 255,
                        t = e[1] / 255,
                        n = e[2] / 255,
                        r = Math.max(Math.max(o, t), n),
                        l = Math.min(Math.min(o, t), n),
                        u = r - l;
                    let a, s;
                    return u < 1 ? a = l / (1 - u) : a = 0, u <= 0 ? s = 0 : r === o ? s = (t - n) / u % 6 : r === t ? s = 2 + (n - o) / u : s = 4 + (o - t) / u, s /= 6, s %= 1, [s * 360, u * 100, a * 100]
                }, h.hsl.hcg = function(e) {
                    const o = e[1] / 100,
                        t = e[2] / 100,
                        n = t < .5 ? 2 * o * t : 2 * o * (1 - t);
                    let r = 0;
                    return n < 1 && (r = (t - .5 * n) / (1 - n)), [e[0], n * 100, r * 100]
                }, h.hsv.hcg = function(e) {
                    const o = e[1] / 100,
                        t = e[2] / 100,
                        n = o * t;
                    let r = 0;
                    return n < 1 && (r = (t - n) / (1 - n)), [e[0], n * 100, r * 100]
                }, h.hcg.rgb = function(e) {
                    const o = e[0] / 360,
                        t = e[1] / 100,
                        n = e[2] / 100;
                    if (t === 0) return [n * 255, n * 255, n * 255];
                    const r = [0, 0, 0],
                        l = o % 1 * 6,
                        u = l % 1,
                        a = 1 - u;
                    let s = 0;
                    switch (Math.floor(l)) {
                        case 0:
                            r[0] = 1, r[1] = u, r[2] = 0;
                            break;
                        case 1:
                            r[0] = a, r[1] = 1, r[2] = 0;
                            break;
                        case 2:
                            r[0] = 0, r[1] = 1, r[2] = u;
                            break;
                        case 3:
                            r[0] = 0, r[1] = a, r[2] = 1;
                            break;
                        case 4:
                            r[0] = u, r[1] = 0, r[2] = 1;
                            break;
                        default:
                            r[0] = 1, r[1] = 0, r[2] = a
                    }
                    return s = (1 - t) * n, [(t * r[0] + s) * 255, (t * r[1] + s) * 255, (t * r[2] + s) * 255]
                }, h.hcg.hsv = function(e) {
                    const o = e[1] / 100,
                        t = e[2] / 100,
                        n = o + t * (1 - o);
                    let r = 0;
                    return n > 0 && (r = o / n), [e[0], r * 100, n * 100]
                }, h.hcg.hsl = function(e) {
                    const o = e[1] / 100,
                        n = e[2] / 100 * (1 - o) + .5 * o;
                    let r = 0;
                    return n > 0 && n < .5 ? r = o / (2 * n) : n >= .5 && n < 1 && (r = o / (2 * (1 - n))), [e[0], r * 100, n * 100]
                }, h.hcg.hwb = function(e) {
                    const o = e[1] / 100,
                        t = e[2] / 100,
                        n = o + t * (1 - o);
                    return [e[0], (n - o) * 100, (1 - n) * 100]
                }, h.hwb.hcg = function(e) {
                    const o = e[1] / 100,
                        t = e[2] / 100,
                        n = 1 - t,
                        r = n - o;
                    let l = 0;
                    return r < 1 && (l = (n - r) / (1 - r)), [e[0], r * 100, l * 100]
                }, h.apple.rgb = function(e) {
                    return [e[0] / 65535 * 255, e[1] / 65535 * 255, e[2] / 65535 * 255]
                }, h.rgb.apple = function(e) {
                    return [e[0] / 255 * 65535, e[1] / 255 * 65535, e[2] / 255 * 65535]
                }, h.gray.rgb = function(e) {
                    return [e[0] / 100 * 255, e[0] / 100 * 255, e[0] / 100 * 255]
                }, h.gray.hsl = function(e) {
                    return [0, 0, e[0]]
                }, h.gray.hsv = h.gray.hsl, h.gray.hwb = function(e) {
                    return [0, 100, e[0]]
                }, h.gray.cmyk = function(e) {
                    return [0, 0, 0, e[0]]
                }, h.gray.lab = function(e) {
                    return [e[0], 0, 0]
                }, h.gray.hex = function(e) {
                    const o = Math.round(e[0] / 100 * 255) & 255,
                        n = ((o << 16) + (o << 8) + o).toString(16).toUpperCase();
                    return "000000".substring(n.length) + n
                }, h.rgb.gray = function(e) {
                    return [(e[0] + e[1] + e[2]) / 3 / 255 * 100]
                }
            },
            12085: (D, C, k) => {
                const v = k(48168),
                    _ = k(4111),
                    h = {},
                    y = Object.keys(v);

                function e(t) {
                    const n = c(function(...r) {
                        const l = r[0];
                        return l == null ? l : (l.length > 1 && (r = l), t(r))
                    }, "wrappedFn");
                    return "conversion" in t && (n.conversion = t.conversion), n
                }
                c(e, "wrapRaw");

                function o(t) {
                    const n = c(function(...r) {
                        const l = r[0];
                        if (l == null) return l;
                        l.length > 1 && (r = l);
                        const u = t(r);
                        if (typeof u == "object")
                            for (let a = u.length, s = 0; s < a; s++) u[s] = Math.round(u[s]);
                        return u
                    }, "wrappedFn");
                    return "conversion" in t && (n.conversion = t.conversion), n
                }
                c(o, "wrapRounded"), y.forEach(t => {
                    h[t] = {}, Object.defineProperty(h[t], "channels", {
                        value: v[t].channels
                    }), Object.defineProperty(h[t], "labels", {
                        value: v[t].labels
                    });
                    const n = _(t);
                    Object.keys(n).forEach(l => {
                        const u = n[l];
                        h[t][l] = o(u), h[t][l].raw = e(u)
                    })
                }), D.exports = h
            },
            39092: D => {
                "use strict";
                D.exports = {
                    aliceblue: [240, 248, 255],
                    antiquewhite: [250, 235, 215],
                    aqua: [0, 255, 255],
                    aquamarine: [127, 255, 212],
                    azure: [240, 255, 255],
                    beige: [245, 245, 220],
                    bisque: [255, 228, 196],
                    black: [0, 0, 0],
                    blanchedalmond: [255, 235, 205],
                    blue: [0, 0, 255],
                    blueviolet: [138, 43, 226],
                    brown: [165, 42, 42],
                    burlywood: [222, 184, 135],
                    cadetblue: [95, 158, 160],
                    chartreuse: [127, 255, 0],
                    chocolate: [210, 105, 30],
                    coral: [255, 127, 80],
                    cornflowerblue: [100, 149, 237],
                    cornsilk: [255, 248, 220],
                    crimson: [220, 20, 60],
                    cyan: [0, 255, 255],
                    darkblue: [0, 0, 139],
                    darkcyan: [0, 139, 139],
                    darkgoldenrod: [184, 134, 11],
                    darkgray: [169, 169, 169],
                    darkgreen: [0, 100, 0],
                    darkgrey: [169, 169, 169],
                    darkkhaki: [189, 183, 107],
                    darkmagenta: [139, 0, 139],
                    darkolivegreen: [85, 107, 47],
                    darkorange: [255, 140, 0],
                    darkorchid: [153, 50, 204],
                    darkred: [139, 0, 0],
                    darksalmon: [233, 150, 122],
                    darkseagreen: [143, 188, 143],
                    darkslateblue: [72, 61, 139],
                    darkslategray: [47, 79, 79],
                    darkslategrey: [47, 79, 79],
                    darkturquoise: [0, 206, 209],
                    darkviolet: [148, 0, 211],
                    deeppink: [255, 20, 147],
                    deepskyblue: [0, 191, 255],
                    dimgray: [105, 105, 105],
                    dimgrey: [105, 105, 105],
                    dodgerblue: [30, 144, 255],
                    firebrick: [178, 34, 34],
                    floralwhite: [255, 250, 240],
                    forestgreen: [34, 139, 34],
                    fuchsia: [255, 0, 255],
                    gainsboro: [220, 220, 220],
                    ghostwhite: [248, 248, 255],
                    gold: [255, 215, 0],
                    goldenrod: [218, 165, 32],
                    gray: [128, 128, 128],
                    green: [0, 128, 0],
                    greenyellow: [173, 255, 47],
                    grey: [128, 128, 128],
                    honeydew: [240, 255, 240],
                    hotpink: [255, 105, 180],
                    indianred: [205, 92, 92],
                    indigo: [75, 0, 130],
                    ivory: [255, 255, 240],
                    khaki: [240, 230, 140],
                    lavender: [230, 230, 250],
                    lavenderblush: [255, 240, 245],
                    lawngreen: [124, 252, 0],
                    lemonchiffon: [255, 250, 205],
                    lightblue: [173, 216, 230],
                    lightcoral: [240, 128, 128],
                    lightcyan: [224, 255, 255],
                    lightgoldenrodyellow: [250, 250, 210],
                    lightgray: [211, 211, 211],
                    lightgreen: [144, 238, 144],
                    lightgrey: [211, 211, 211],
                    lightpink: [255, 182, 193],
                    lightsalmon: [255, 160, 122],
                    lightseagreen: [32, 178, 170],
                    lightskyblue: [135, 206, 250],
                    lightslategray: [119, 136, 153],
                    lightslategrey: [119, 136, 153],
                    lightsteelblue: [176, 196, 222],
                    lightyellow: [255, 255, 224],
                    lime: [0, 255, 0],
                    limegreen: [50, 205, 50],
                    linen: [250, 240, 230],
                    magenta: [255, 0, 255],
                    maroon: [128, 0, 0],
                    mediumaquamarine: [102, 205, 170],
                    mediumblue: [0, 0, 205],
                    mediumorchid: [186, 85, 211],
                    mediumpurple: [147, 112, 219],
                    mediumseagreen: [60, 179, 113],
                    mediumslateblue: [123, 104, 238],
                    mediumspringgreen: [0, 250, 154],
                    mediumturquoise: [72, 209, 204],
                    mediumvioletred: [199, 21, 133],
                    midnightblue: [25, 25, 112],
                    mintcream: [245, 255, 250],
                    mistyrose: [255, 228, 225],
                    moccasin: [255, 228, 181],
                    navajowhite: [255, 222, 173],
                    navy: [0, 0, 128],
                    oldlace: [253, 245, 230],
                    olive: [128, 128, 0],
                    olivedrab: [107, 142, 35],
                    orange: [255, 165, 0],
                    orangered: [255, 69, 0],
                    orchid: [218, 112, 214],
                    palegoldenrod: [238, 232, 170],
                    palegreen: [152, 251, 152],
                    paleturquoise: [175, 238, 238],
                    palevioletred: [219, 112, 147],
                    papayawhip: [255, 239, 213],
                    peachpuff: [255, 218, 185],
                    peru: [205, 133, 63],
                    pink: [255, 192, 203],
                    plum: [221, 160, 221],
                    powderblue: [176, 224, 230],
                    purple: [128, 0, 128],
                    rebeccapurple: [102, 51, 153],
                    red: [255, 0, 0],
                    rosybrown: [188, 143, 143],
                    royalblue: [65, 105, 225],
                    saddlebrown: [139, 69, 19],
                    salmon: [250, 128, 114],
                    sandybrown: [244, 164, 96],
                    seagreen: [46, 139, 87],
                    seashell: [255, 245, 238],
                    sienna: [160, 82, 45],
                    silver: [192, 192, 192],
                    skyblue: [135, 206, 235],
                    slateblue: [106, 90, 205],
                    slategray: [112, 128, 144],
                    slategrey: [112, 128, 144],
                    snow: [255, 250, 250],
                    springgreen: [0, 255, 127],
                    steelblue: [70, 130, 180],
                    tan: [210, 180, 140],
                    teal: [0, 128, 128],
                    thistle: [216, 191, 216],
                    tomato: [255, 99, 71],
                    turquoise: [64, 224, 208],
                    violet: [238, 130, 238],
                    wheat: [245, 222, 179],
                    white: [255, 255, 255],
                    whitesmoke: [245, 245, 245],
                    yellow: [255, 255, 0],
                    yellowgreen: [154, 205, 50]
                }
            },
            4111: (D, C, k) => {
                const v = k(48168);

                function _() {
                    const o = {},
                        t = Object.keys(v);
                    for (let n = t.length, r = 0; r < n; r++) o[t[r]] = {
                        distance: -1,
                        parent: null
                    };
                    return o
                }
                c(_, "buildGraph");

                function h(o) {
                    const t = _(),
                        n = [o];
                    for (t[o].distance = 0; n.length;) {
                        const r = n.pop(),
                            l = Object.keys(v[r]);
                        for (let u = l.length, a = 0; a < u; a++) {
                            const s = l[a],
                                i = t[s];
                            i.distance === -1 && (i.distance = t[r].distance + 1, i.parent = r, n.unshift(s))
                        }
                    }
                    return t
                }
                c(h, "deriveBFS");

                function y(o, t) {
                    return function(n) {
                        return t(o(n))
                    }
                }
                c(y, "link");

                function e(o, t) {
                    const n = [t[o].parent, o];
                    let r = v[t[o].parent][o],
                        l = t[o].parent;
                    for (; t[l].parent;) n.unshift(t[l].parent), r = y(v[t[l].parent][l], r), l = t[l].parent;
                    return r.conversion = n, r
                }
                c(e, "wrapConversion"), D.exports = function(o) {
                    const t = h(o),
                        n = {},
                        r = Object.keys(t);
                    for (let l = r.length, u = 0; u < l; u++) {
                        const a = r[u];
                        t[a].parent !== null && (n[a] = e(a, t))
                    }
                    return n
                }
            },
            96776: (D, C, k) => {
                "use strict";
                k.d(C, {
                    _8: () => v,
                    uQ: () => _
                });

                function v(e, o) {
                    return _(h(e), o)
                }
                c(v, "preserveAnchorNodePosition");

                function _(e, o) {
                    var t = e;
                    if (!t) return Promise.resolve(o());
                    var n = t.ownerDocument.documentElement;

                    function r(a) {
                        for (var s = []; a;) {
                            var i = a.getBoundingClientRect(),
                                m = i.top,
                                f = i.left;
                            s.push({
                                element: a,
                                top: m,
                                left: f
                            }), a = a.parentElement
                        }
                        return s
                    }
                    c(r, "computeAncestorBoundingRects");

                    function l(a) {
                        for (var s = 0; s < a.length; s++) {
                            var i = a[s];
                            if (n.contains(i.element)) return i
                        }
                    }
                    c(l, "firstAttachedBoundingRect");
                    var u = r(t);
                    return Promise.resolve(o()).then(function(a) {
                        var s = l(u);
                        if (s) {
                            t = s.element;
                            var i = s.top,
                                m = s.left,
                                f = t.getBoundingClientRect(),
                                p = f.top,
                                g = f.left;
                            y(t, g - m, p - i)
                        }
                        return a
                    })
                }
                c(_, "preservePosition");

                function h(e) {
                    if (e.activeElement !== e.body) return e.activeElement;
                    var o = e.querySelectorAll(":hover"),
                        t = o.length;
                    if (t) return o[t - 1]
                }
                c(h, "findAnchorNode");

                function y(e, o, t) {
                    var n = e.ownerDocument,
                        r = n.defaultView;

                    function l(p) {
                        return p.offsetParent ? {
                            top: p.scrollTop,
                            left: p.scrollLeft
                        } : {
                            top: r.pageYOffset,
                            left: r.pageXOffset
                        }
                    }
                    c(l, "scrollOffsets");

                    function u(p, g, w) {
                        if (g === 0 && w === 0) return [0, 0];
                        var M = l(p),
                            L = M.top + w,
                            j = M.left + g;
                        p === n || p === r || p === n.documentElement || p === n.body ? n.defaultView.scrollTo(j, L) : (p.scrollTop = L, p.scrollLeft = j);
                        var q = l(p);
                        return [q.left - M.left, q.top - M.top]
                    }
                    c(u, "scrollBy");

                    function a(p) {
                        var g = p;
                        if (!(!g.offsetParent || g === n.body)) {
                            for (; g !== n.body;) {
                                if (g.parentElement) g = g.parentElement;
                                else return;
                                var w = r.getComputedStyle(g),
                                    M = w.position,
                                    L = w.overflowY,
                                    j = w.overflowX;
                                if (M === "fixed" || L === "auto" || j === "auto" || L === "scroll" || j === "scroll") break
                            }
                            return g
                        }
                    }
                    c(a, "overflowParent");
                    for (var s = a(e), i = 0, m = 0; s;) {
                        var f = u(s, o - i, t - m);
                        if (i += f[0], m += f[1], i === o && m === t) break;
                        s = a(s)
                    }
                }
                c(y, "cumulativeScrollBy")
            },
            28382: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Q: () => _
                });
                var v = "<unknown>";

                function _(m) {
                    var f = m.split(`
`);
                    return f.reduce(function(p, g) {
                        var w = e(g) || t(g) || l(g) || i(g) || a(g);
                        return w && p.push(w), p
                    }, [])
                }
                c(_, "parse");
                var h = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
                    y = /\((\S*)(?::(\d+))(?::(\d+))\)/;

                function e(m) {
                    var f = h.exec(m);
                    if (!f) return null;
                    var p = f[2] && f[2].indexOf("native") === 0,
                        g = f[2] && f[2].indexOf("eval") === 0,
                        w = y.exec(f[2]);
                    return g && w != null && (f[2] = w[1], f[3] = w[2], f[4] = w[3]), {
                        file: p ? null : f[2],
                        methodName: f[1] || v,
                        arguments: p ? [f[2]] : [],
                        lineNumber: f[3] ? +f[3] : null,
                        column: f[4] ? +f[4] : null
                    }
                }
                c(e, "parseChrome");
                var o = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;

                function t(m) {
                    var f = o.exec(m);
                    return f ? {
                        file: f[2],
                        methodName: f[1] || v,
                        arguments: [],
                        lineNumber: +f[3],
                        column: f[4] ? +f[4] : null
                    } : null
                }
                c(t, "parseWinjs");
                var n = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i,
                    r = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;

                function l(m) {
                    var f = n.exec(m);
                    if (!f) return null;
                    var p = f[3] && f[3].indexOf(" > eval") > -1,
                        g = r.exec(f[3]);
                    return p && g != null && (f[3] = g[1], f[4] = g[2], f[5] = null), {
                        file: f[3],
                        methodName: f[1] || v,
                        arguments: f[2] ? f[2].split(",") : [],
                        lineNumber: f[4] ? +f[4] : null,
                        column: f[5] ? +f[5] : null
                    }
                }
                c(l, "parseGecko");
                var u = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i;

                function a(m) {
                    var f = u.exec(m);
                    return f ? {
                        file: f[3],
                        methodName: f[1] || v,
                        arguments: [],
                        lineNumber: +f[4],
                        column: f[5] ? +f[5] : null
                    } : null
                }
                c(a, "parseJSC");
                var s = /^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i;

                function i(m) {
                    var f = s.exec(m);
                    return f ? {
                        file: f[2],
                        methodName: f[1] || v,
                        arguments: [],
                        lineNumber: +f[3],
                        column: f[4] ? +f[4] : null
                    } : null
                }
                c(i, "parseNode")
            },
            82131: (D, C, k) => {
                "use strict";
                k.d(C, {
                    CA: () => G,
                    Tb: () => J,
                    Tx: () => Y,
                    Y: () => m,
                    kz: () => g
                });
                var v, _, h, y, e = c(function(P, T) {
                        return {
                            name: P,
                            value: T === void 0 ? -1 : T,
                            delta: 0,
                            entries: [],
                            id: "v2-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12)
                        }
                    }, "a"),
                    o = c(function(P, T) {
                        try {
                            if (PerformanceObserver.supportedEntryTypes.includes(P)) {
                                if (P === "first-input" && !("PerformanceEventTiming" in self)) return;
                                var A = new PerformanceObserver(function(R) {
                                    return R.getEntries().map(T)
                                });
                                return A.observe({
                                    type: P,
                                    buffered: !0
                                }), A
                            }
                        } catch {}
                    }, "r"),
                    t = c(function(P, T) {
                        var A = c(function R(S) {
                            S.type !== "pagehide" && document.visibilityState !== "hidden" || (P(S), T && (removeEventListener("visibilitychange", R, !0), removeEventListener("pagehide", R, !0)))
                        }, "n");
                        addEventListener("visibilitychange", A, !0), addEventListener("pagehide", A, !0)
                    }, "o"),
                    n = c(function(P) {
                        addEventListener("pageshow", function(T) {
                            T.persisted && P(T)
                        }, !0)
                    }, "u"),
                    r = typeof WeakSet == "function" ? new WeakSet : new Set,
                    l = c(function(P, T, A) {
                        var R;
                        return function() {
                            T.value >= 0 && (A || r.has(T) || document.visibilityState === "hidden") && (T.delta = T.value - (R || 0), (T.delta || R === void 0) && (R = T.value, P(T)))
                        }
                    }, "f"),
                    u = -1,
                    a = c(function() {
                        return document.visibilityState === "hidden" ? 0 : 1 / 0
                    }, "m"),
                    s = c(function() {
                        t(function(P) {
                            var T = P.timeStamp;
                            u = T
                        }, !0)
                    }, "d"),
                    i = c(function() {
                        return u < 0 && (u = a(), s(), n(function() {
                            setTimeout(function() {
                                u = a(), s()
                            }, 0)
                        })), {
                            get firstHiddenTime() {
                                return u
                            }
                        }
                    }, "v"),
                    m = c(function(P, T) {
                        var A, R = i(),
                            S = e("FCP"),
                            N = c(function(U) {
                                U.name === "first-contentful-paint" && (F && F.disconnect(), U.startTime < R.firstHiddenTime && (S.value = U.startTime, S.entries.push(U), r.add(S), A()))
                            }, "s"),
                            O = performance.getEntriesByName && performance.getEntriesByName("first-contentful-paint")[0],
                            F = O ? null : o("paint", N);
                        (O || F) && (A = l(P, S, T), O && N(O), n(function(U) {
                            S = e("FCP"), A = l(P, S, T), requestAnimationFrame(function() {
                                requestAnimationFrame(function() {
                                    S.value = performance.now() - U.timeStamp, r.add(S), A()
                                })
                            })
                        }))
                    }, "p"),
                    f = !1,
                    p = -1,
                    g = c(function(P, T) {
                        f || (m(function($) {
                            p = $.value
                        }), f = !0);
                        var A, R = c(function($) {
                                p > -1 && P($)
                            }, "i"),
                            S = e("CLS", 0),
                            N = 0,
                            O = [],
                            F = c(function($) {
                                if (!$.hadRecentInput) {
                                    var X = O[0],
                                        V = O[O.length - 1];
                                    N && $.startTime - V.startTime < 1e3 && $.startTime - X.startTime < 5e3 ? (N += $.value, O.push($)) : (N = $.value, O = [$]), N > S.value && (S.value = N, S.entries = O, A())
                                }
                            }, "d"),
                            U = o("layout-shift", F);
                        U && (A = l(R, S, T), t(function() {
                            U.takeRecords().map(F), A()
                        }), n(function() {
                            N = 0, p = -1, S = e("CLS", 0), A = l(R, S, T)
                        }))
                    }, "y"),
                    w = {
                        passive: !0,
                        capture: !0
                    },
                    M = new Date,
                    L = c(function(P, T) {
                        v || (v = T, _ = P, h = new Date, K(removeEventListener), j())
                    }, "E"),
                    j = c(function() {
                        if (_ >= 0 && _ < h - M) {
                            var P = {
                                entryType: "first-input",
                                name: v.type,
                                target: v.target,
                                cancelable: v.cancelable,
                                startTime: v.timeStamp,
                                processingStart: v.timeStamp + _
                            };
                            y.forEach(function(T) {
                                T(P)
                            }), y = []
                        }
                    }, "S"),
                    q = c(function(P) {
                        if (P.cancelable) {
                            var T = (P.timeStamp > 1e12 ? new Date : performance.now()) - P.timeStamp;
                            P.type == "pointerdown" ? function(A, R) {
                                var S = c(function() {
                                        L(A, R), O()
                                    }, "n"),
                                    N = c(function() {
                                        O()
                                    }, "i"),
                                    O = c(function() {
                                        removeEventListener("pointerup", S, w), removeEventListener("pointercancel", N, w)
                                    }, "a");
                                addEventListener("pointerup", S, w), addEventListener("pointercancel", N, w)
                            }(T, P) : L(T, P)
                        }
                    }, "w"),
                    K = c(function(P) {
                        ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(function(T) {
                            return P(T, q, w)
                        })
                    }, "L"),
                    Y = c(function(P, T) {
                        var A, R = i(),
                            S = e("FID"),
                            N = c(function(F) {
                                F.startTime < R.firstHiddenTime && (S.value = F.processingStart - F.startTime, S.entries.push(F), r.add(S), A())
                            }, "l"),
                            O = o("first-input", N);
                        A = l(P, S, T), O && t(function() {
                            O.takeRecords().map(N), O.disconnect()
                        }, !0), O && n(function() {
                            var F;
                            S = e("FID"), A = l(P, S, T), y = [], _ = -1, v = null, K(addEventListener), F = N, y.push(F), j()
                        })
                    }, "b"),
                    J = c(function(P, T) {
                        var A, R = i(),
                            S = e("LCP"),
                            N = c(function(U) {
                                var $ = U.startTime;
                                $ < R.firstHiddenTime && (S.value = $, S.entries.push(U)), A()
                            }, "m"),
                            O = o("largest-contentful-paint", N);
                        if (O) {
                            A = l(P, S, T);
                            var F = c(function() {
                                r.has(S) || (O.takeRecords().map(N), O.disconnect(), r.add(S), A())
                            }, "p");
                            ["keydown", "click"].forEach(function(U) {
                                addEventListener(U, F, {
                                    once: !0,
                                    capture: !0
                                })
                            }), t(F, !0), n(function(U) {
                                S = e("LCP"), A = l(P, S, T), requestAnimationFrame(function() {
                                    requestAnimationFrame(function() {
                                        S.value = performance.now() - U.timeStamp, r.add(S), A()
                                    })
                                })
                            })
                        }
                    }, "F"),
                    G = c(function(P) {
                        var T, A = e("TTFB");
                        T = c(function() {
                            try {
                                var R = performance.getEntriesByType("navigation")[0] || function() {
                                    var S = performance.timing,
                                        N = {
                                            entryType: "navigation",
                                            startTime: 0
                                        };
                                    for (var O in S) O !== "navigationStart" && O !== "toJSON" && (N[O] = Math.max(S[O] - S.navigationStart, 0));
                                    return N
                                }();
                                if (A.value = A.delta = R.responseStart, A.value < 0) return;
                                A.entries = [R], P(A)
                            } catch {}
                        }, "t"), document.readyState === "complete" ? setTimeout(T, 0) : addEventListener("pageshow", T)
                    }, "k")
            },
            27907: (D, C, k) => {
                "use strict";
                k.d(C, {
                    a: () => l
                });
                var v = k(81855),
                    _ = k(60835),
                    h = k(16544),
                    y = k(75658),
                    e = k(80955),
                    o = k(29871),
                    t;
                (function(u) {
                    u.Deploy = "Alive Redeploy", u.Reconnect = "Alive Reconnect"
                })(t || (t = {}));

                function n() {
                    return `${Math.round(Math.random()*(Math.pow(2,31)-1))}_${Math.round(Date.now()/1e3)}`
                }
                c(n, "generatePresenceId");

                function r(u) {
                    const a = u.match(/\/u\/(\d+)\/ws/);
                    return a ? +a[1] : 0
                }
                c(r, "getUserIdFromSocketUrl");
                class l {
                    constructor(a, s, i, m) {
                        this.url = a, this.getUrl = s, this.inSharedWorker = i, this.notify = m, this.subscriptions = new y.v, this.state = "online", this.retrying = null, this.connectionCount = 0, this.presence = new v.k2, this.presenceMetadata = new _.a, this.intentionallyDisconnected = !1, this.lastCameOnline = 0, this.userId = r(a), this.presenceId = n(), this.presenceKey = (0, v.Hw)(this.userId, this.presenceId), this.socket = this.connect()
                    }
                    subscribe(a) {
                        const s = this.subscriptions.add(...a);
                        this.sendSubscribe(s);
                        for (const i of a) {
                            const m = i.topic.name;
                            !(0, v.A)(m) || this.notifyCachedPresence(i.subscriber, m)
                        }
                    }
                    unsubscribe(a) {
                        const s = this.subscriptions.delete(...a);
                        this.sendUnsubscribe(s)
                    }
                    unsubscribeAll(...a) {
                        const s = this.subscriptions.drain(...a);
                        this.sendUnsubscribe(s);
                        const i = this.presenceMetadata.removeSubscribers(a);
                        this.sendPresenceMetadataUpdate(i)
                    }
                    requestPresence(a, s) {
                        for (const i of s) this.notifyCachedPresence(a, i)
                    }
                    notifyCachedPresence(a, s) {
                        const i = this.presence.getChannelItems(s);
                        i.length !== 0 && this.notifyPresenceChannel(s, i)
                    }
                    updatePresenceMetadata(a) {
                        const s = new Set;
                        for (const i of a) this.presenceMetadata.setMetadata(i), s.add(i.channelName);
                        this.sendPresenceMetadataUpdate(s)
                    }
                    sendPresenceMetadataUpdate(a) {
                        if (!a.size) return;
                        const s = [];
                        for (const i of a) {
                            const m = this.subscriptions.topic(i);
                            m && s.push(m)
                        }
                        this.sendSubscribe(s)
                    }
                    online() {
                        var a;
                        this.lastCameOnline = Date.now(), this.state = "online", (a = this.retrying) === null || a === void 0 || a.abort(), this.socket.open()
                    }
                    offline() {
                        var a;
                        this.state = "offline", (a = this.retrying) === null || a === void 0 || a.abort(), this.socket.close()
                    }
                    shutdown() {
                        this.inSharedWorker && self.close()
                    }
                    get reconnectWindow() {
                        const a = Date.now() - this.lastCameOnline < 6e4;
                        return this.connectionCount === 0 || this.intentionallyDisconnected || a ? 0 : 10 * 1e3
                    }
                    socketDidOpen() {
                        this.intentionallyDisconnected = !1, this.connectionCount++, this.socket.url = this.getUrlWithPresenceId(), this.sendSubscribe(this.subscriptions.topics())
                    }
                    socketDidClose(a, s, i) {
                        if (this.redeployEarlyReconnectTimeout !== void 0 && clearTimeout(this.redeployEarlyReconnectTimeout), i === "Alive Reconnect") this.intentionallyDisconnected = !0;
                        else if (i === "Alive Redeploy") {
                            this.intentionallyDisconnected = !0;
                            const f = (3 + Math.random() * 22) * 60 * 1e3;
                            this.redeployEarlyReconnectTimeout = setTimeout(() => {
                                this.intentionallyDisconnected = !0, this.socket.close(1e3, "Alive Redeploy Early Client Reconnect")
                            }, f)
                        }
                    }
                    socketDidFinish() {
                        this.state !== "offline" && this.reconnect()
                    }
                    socketDidReceiveMessage(a, s) {
                        const i = JSON.parse(s);
                        switch (i.e) {
                            case "ack":
                                {
                                    this.handleAck(i);
                                    break
                                }
                            case "msg":
                                {
                                    this.handleMessage(i);
                                    break
                                }
                        }
                    }
                    handleAck(a) {
                        for (const s of this.subscriptions.topics()) s.offset = a.off
                    }
                    handleMessage(a) {
                        const s = a.ch,
                            i = this.subscriptions.topic(s);
                        if (!!i) {
                            if (i.offset = a.off, "e" in a.data) {
                                const m = this.presence.handleMessage(s, a.data);
                                this.notifyPresenceChannel(s, m);
                                return
                            }
                            a.data.wait || (a.data.wait = 0), this.notify(this.subscriptions.subscribers(s), {
                                channel: s,
                                type: "message",
                                data: a.data
                            })
                        }
                    }
                    notifyPresenceChannel(a, s) {
                        var i, m;
                        const f = new Map;
                        for (const p of s) {
                            const {
                                userId: g,
                                metadata: w,
                                presenceKey: M
                            } = p, L = f.get(g) || {
                                userId: g,
                                isOwnUser: g === this.userId,
                                metadata: []
                            };
                            if (M !== this.presenceKey) {
                                for (const j of w) {
                                    if (_.Z in j) {
                                        L.isIdle !== !1 && (L.isIdle = Boolean(j[_.Z]));
                                        continue
                                    }
                                    L.metadata.push(j)
                                }
                                f.set(g, L)
                            }
                        }
                        for (const p of this.subscriptions.subscribers(a)) {
                            const g = this.userId,
                                w = Array.from(f.values()).filter(j => j.userId !== g),
                                M = (m = (i = f.get(this.userId)) === null || i === void 0 ? void 0 : i.metadata) !== null && m !== void 0 ? m : [],
                                L = this.presenceMetadata.getChannelMetadata(a, {
                                    subscriber: p,
                                    markAllAsLocal: !this.inSharedWorker
                                });
                            this.notify([p], {
                                channel: a,
                                type: "presence",
                                data: [{
                                    userId: g,
                                    isOwnUser: !0,
                                    metadata: [...M, ...L]
                                }, ...w]
                            })
                        }
                    }
                    async reconnect() {
                        if (!this.retrying) try {
                            this.retrying = new AbortController;
                            const a = await (0, o.X)(this.getUrl, 1 / 0, 6e4, this.retrying.signal);
                            a ? (this.url = a, this.socket = this.connect()) : this.shutdown()
                        } catch (a) {
                            if (a.name !== "AbortError") throw a
                        } finally {
                            this.retrying = null
                        }
                    }
                    getUrlWithPresenceId() {
                        const a = new URL(this.url, self.location.origin);
                        return a.searchParams.set("shared", this.inSharedWorker.toString()), a.searchParams.set("p", `${this.presenceId}.${this.connectionCount}`), a.toString()
                    }
                    connect() {
                        const a = new h.Oo(this.getUrlWithPresenceId(), this, {
                            timeout: 4e3,
                            attempts: 7
                        });
                        return a.open(), a
                    }
                    sendSubscribe(a) {
                        const s = Array.from(a);
                        for (const i of (0, e.o)(s, 25)) {
                            const m = {};
                            for (const f of i)(0, v.A)(f.name) ? m[f.signed] = JSON.stringify(this.presenceMetadata.getChannelMetadata(f.name)) : m[f.signed] = f.offset;
                            this.socket.send(JSON.stringify({
                                subscribe: m
                            }))
                        }
                    }
                    sendUnsubscribe(a) {
                        const s = Array.from(a, i => i.signed);
                        for (const i of (0, e.o)(s, 25)) this.socket.send(JSON.stringify({
                            unsubscribe: i
                        }));
                        for (const i of a)(0, v.A)(i.name) && this.presence.clearChannel(i.name)
                    }
                }
                c(l, "AliveSession")
            },
            29871: (D, C, k) => {
                "use strict";
                k.d(C, {
                    X: () => y
                });

                function v(e) {
                    return new Promise((o, t) => {
                        const n = new Error("aborted");
                        n.name = "AbortError", e.aborted ? t(n) : e.addEventListener("abort", () => t(n))
                    })
                }
                c(v, "whenAborted");
                async function _(e, o) {
                    let t;
                    const n = new Promise(r => {
                        t = self.setTimeout(r, e)
                    });
                    if (!o) return n;
                    try {
                        await Promise.race([n, v(o)])
                    } catch (r) {
                        throw self.clearTimeout(t), r
                    }
                }
                c(_, "wait");

                function h(e) {
                    return Math.floor(Math.random() * Math.floor(e))
                }
                c(h, "rand");
                async function y(e, o, t = 1 / 0, n) {
                    const r = n ? v(n) : null;
                    for (let l = 0; l < o; l++) try {
                        return await (r ? Promise.race([e(), r]) : e())
                    } catch (u) {
                        if (u.name === "AbortError" || l === o - 1) throw u;
                        const a = Math.pow(2, l) * 1e3,
                            s = h(a * .1);
                        await _(Math.min(t, a + s), n)
                    }
                    throw new Error("retry failed")
                }
                c(y, "retry")
            },
            21461: (D, C, k) => {
                "use strict";
                k.d(C, {
                    A: () => h.A,
                    ZE: () => _.Z,
                    Zf: () => e.Z,
                    a2: () => v.a,
                    ah: () => _.a,
                    vk: () => y.v
                });
                var v = k(27907),
                    _ = k(60835),
                    h = k(81855),
                    y = k(75658),
                    e = k(72993)
            },
            80955: (D, C, k) => {
                "use strict";
                k.d(C, {
                    o: () => v
                });

                function* v(_, h) {
                    for (let y = 0; y < _.length; y += h) yield _.slice(y, y + h)
                }
                c(v, "eachSlice")
            },
            60835: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => v,
                    a: () => y
                });
                const v = "_i";

                function _(e) {
                    return Object.assign(Object.assign({}, e), {
                        isLocal: !0
                    })
                }
                c(_, "markMetadataAsLocal");
                class h {
                    constructor() {
                        this.subscriberMetadata = new Map
                    }
                    setMetadata(o, t) {
                        this.subscriberMetadata.set(o, t)
                    }
                    removeSubscribers(o) {
                        let t = !1;
                        for (const n of o) t = this.subscriberMetadata.delete(n) || t;
                        return t
                    }
                    getMetadata(o) {
                        if (!o) {
                            const l = [];
                            let u;
                            for (const a of this.subscriberMetadata.values())
                                for (const s of a)
                                    if (v in s) {
                                        const i = Boolean(s[v]);
                                        u = u === void 0 ? i : i && u
                                    } else l.push(s);
                            return u !== void 0 && l.push({
                                [v]: u ? 1 : 0
                            }), l
                        }
                        const t = [],
                            {
                                subscriber: n,
                                markAllAsLocal: r
                            } = o;
                        for (const [l, u] of this.subscriberMetadata) {
                            const s = r || l === n ? u.map(_) : u;
                            t.push(...s)
                        }
                        return t
                    }
                    hasSubscribers() {
                        return this.subscriberMetadata.size > 0
                    }
                }
                c(h, "PresenceMetadataForChannel");
                class y {
                    constructor() {
                        this.metadataByChannel = new Map
                    }
                    setMetadata({
                        subscriber: o,
                        channelName: t,
                        metadata: n
                    }) {
                        let r = this.metadataByChannel.get(t);
                        r || (r = new h, this.metadataByChannel.set(t, r)), r.setMetadata(o, n)
                    }
                    removeSubscribers(o) {
                        const t = new Set;
                        for (const [n, r] of this.metadataByChannel) r.removeSubscribers(o) && t.add(n), r.hasSubscribers() || this.metadataByChannel.delete(n);
                        return t
                    }
                    getChannelMetadata(o, t) {
                        const n = this.metadataByChannel.get(o);
                        return (n == null ? void 0 : n.getMetadata(t)) || []
                    }
                }
                c(y, "PresenceMetadataSet")
            },
            81855: (D, C, k) => {
                "use strict";
                k.d(C, {
                    A: () => y,
                    Hw: () => v,
                    k2: () => o
                });

                function v(t, n) {
                    return `${t}:${n}`
                }
                c(v, "getPresenceKey");

                function _(t) {
                    const [n, r] = t.p.split(".");
                    return {
                        userId: t.u,
                        presenceKey: v(t.u, n),
                        connectionCount: Number(r),
                        metadata: t.m || []
                    }
                }
                c(_, "decompressItem");
                const h = "presence-";

                function y(t) {
                    return t.startsWith(h)
                }
                c(y, "isPresenceChannel");
                class e {
                    constructor() {
                        this.presenceItems = new Map
                    }
                    shouldUsePresenceItem(n) {
                        const r = this.presenceItems.get(n.presenceKey);
                        return !r || r.connectionCount <= n.connectionCount
                    }
                    addPresenceItem(n) {
                        !this.shouldUsePresenceItem(n) || this.presenceItems.set(n.presenceKey, n)
                    }
                    removePresenceItem(n) {
                        !this.shouldUsePresenceItem(n) || this.presenceItems.delete(n.presenceKey)
                    }
                    replacePresenceItems(n) {
                        this.presenceItems.clear();
                        for (const r of n) this.addPresenceItem(r)
                    }
                    getPresenceItems() {
                        return Array.from(this.presenceItems.values())
                    }
                }
                c(e, "PresenceChannel");
                class o {
                    constructor() {
                        this.presenceChannels = new Map
                    }
                    getPresenceChannel(n) {
                        const r = this.presenceChannels.get(n) || new e;
                        return this.presenceChannels.set(n, r), r
                    }
                    handleMessage(n, r) {
                        const l = this.getPresenceChannel(n);
                        switch (r.e) {
                            case "pf":
                                l.replacePresenceItems(r.d.map(_));
                                break;
                            case "pa":
                                l.addPresenceItem(_(r.d));
                                break;
                            case "pr":
                                l.removePresenceItem(_(r.d));
                                break
                        }
                        return this.getChannelItems(n)
                    }
                    getChannelItems(n) {
                        return this.getPresenceChannel(n).getPresenceItems()
                    }
                    clearChannel(n) {
                        this.presenceChannels.delete(n)
                    }
                }
                c(o, "AlivePresence")
            },
            75658: (D, C, k) => {
                "use strict";
                k.d(C, {
                    v: () => _
                });
                var v = k(61268);
                class _ {
                    constructor() {
                        this.subscriptions = new v.Z, this.signatures = new Map
                    }
                    add(...y) {
                        const e = [];
                        for (const {
                                subscriber: o,
                                topic: t
                            } of y) this.subscriptions.has(t.name) || (e.push(t), this.signatures.set(t.name, t)), this.subscriptions.set(t.name, o);
                        return e
                    }
                    delete(...y) {
                        const e = [];
                        for (const {
                                subscriber: o,
                                topic: t
                            } of y) this.subscriptions.delete(t.name, o) && !this.subscriptions.has(t.name) && (e.push(t), this.signatures.delete(t.name));
                        return e
                    }
                    drain(...y) {
                        const e = [];
                        for (const o of y)
                            for (const t of this.subscriptions.drain(o)) {
                                const n = this.signatures.get(t);
                                this.signatures.delete(t), e.push(n)
                            }
                        return e
                    }
                    topics() {
                        return this.signatures.values()
                    }
                    topic(y) {
                        return this.signatures.get(y) || null
                    }
                    subscribers(y) {
                        return this.subscriptions.get(y).values()
                    }
                }
                c(_, "SubscriptionSet")
            },
            72993: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => v
                });
                class v {
                    constructor(h, y) {
                        this.name = h, this.signed = y, this.offset = ""
                    }
                    static parse(h) {
                        const [y, e] = h.split("--");
                        if (!y || !e) return null;
                        const o = JSON.parse(atob(y));
                        return !o.c || !o.t ? null : new v(o.c, h)
                    }
                }
                c(v, "Topic")
            },
            50232: (D, C, k) => {
                "use strict";
                k.d(C, {
                    nn: () => oe,
                    Gb: () => te
                });

                function v(d) {
                    const b = new AbortController;
                    return b.abort(d), b.signal
                }
                c(v, "abortsignal_abort_abortSignalAbort");

                function _() {
                    return "abort" in AbortSignal && typeof AbortSignal.abort == "function"
                }
                c(_, "isSupported");

                function h() {
                    return AbortSignal.abort === v
                }
                c(h, "isPolyfilled");

                function y() {
                    _() || (AbortSignal.abort = v)
                }
                c(y, "apply");

                function e(d) {
                    const b = new AbortController;
                    return setTimeout(() => b.abort(new DOMException("TimeoutError")), d), b.signal
                }
                c(e, "abortsignal_timeout_abortSignalTimeout");

                function o() {
                    return "abort" in AbortSignal && typeof AbortSignal.timeout == "function"
                }
                c(o, "abortsignal_timeout_isSupported");

                function t() {
                    return AbortSignal.timeout === e
                }
                c(t, "abortsignal_timeout_isPolyfilled");

                function n() {
                    o() || (AbortSignal.timeout = e)
                }
                c(n, "abortsignal_timeout_apply");
                class r extends Error {
                    constructor(b, E, x = {}) {
                        super(E);
                        Object.defineProperty(this, "errors", {
                            value: Array.from(b),
                            configurable: !0,
                            writable: !0
                        }), x.cause && Object.defineProperty(this, "cause", {
                            value: x.cause,
                            configurable: !0,
                            writable: !0
                        })
                    }
                }
                c(r, "AggregateError");

                function l() {
                    return typeof globalThis.AggregateError == "function"
                }
                c(l, "aggregateerror_isSupported");

                function u() {
                    return globalThis.AggregateError === r
                }
                c(u, "aggregateerror_isPolyfilled");

                function a() {
                    l() || (globalThis.AggregateError = r)
                }
                c(a, "aggregateerror_apply");
                const s = Reflect.getPrototypeOf(Int8Array) || {};

                function i(d) {
                    const b = this.length;
                    return d = Math.trunc(d) || 0, d < 0 && (d += b), d < 0 || d >= b ? void 0 : this[d]
                }
                c(i, "arrayLikeAt");

                function m() {
                    return "at" in Array.prototype && typeof Array.prototype.at == "function" && "at" in String.prototype && typeof String.prototype.at == "function" && "at" in s && typeof s.at == "function"
                }
                c(m, "arraylike_at_isSupported");

                function f() {
                    return Array.prototype.at === i && String.prototype.at === i && s.at === i
                }
                c(f, "arraylike_at_isPolyfilled");

                function p() {
                    if (!m()) {
                        const d = {
                            value: i,
                            writable: !0,
                            configurable: !0
                        };
                        Object.defineProperty(Array.prototype, "at", d), Object.defineProperty(String.prototype, "at", d), Object.defineProperty(s, "at", d)
                    }
                }
                c(p, "arraylike_at_apply");

                function g() {
                    const d = new Uint32Array(4);
                    crypto.getRandomValues(d);
                    let b = -1;
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(E) {
                        b++;
                        const x = d[b >> 3] >> b % 8 * 4 & 15;
                        return (E === "x" ? x : x & 3 | 8).toString(16)
                    })
                }
                c(g, "randomUUID");

                function w() {
                    return typeof crypto == "object" && "randomUUID" in crypto && typeof crypto.randomUUID == "function"
                }
                c(w, "crypto_randomuuid_isSupported");

                function M() {
                    return w() && crypto.randomUUID === g
                }
                c(M, "crypto_randomuuid_isPolyfilled");

                function L() {
                    w() || (crypto.randomUUID = g)
                }
                c(L, "crypto_randomuuid_apply");
                const j = EventTarget.prototype.addEventListener;

                function q(d, b, E) {
                    if (typeof E == "object" && "signal" in E && E.signal instanceof AbortSignal) {
                        if (E.signal.aborted) return;
                        j.call(E.signal, "abort", () => {
                            this.removeEventListener(d, b, E)
                        })
                    }
                    return j.call(this, d, b, E)
                }
                c(q, "addEventListenerWithAbortSignal");

                function K() {
                    let d = !1;
                    const b = c(() => d = !0, "setSignalSupported");

                    function E() {}
                    c(E, "noop");
                    const x = Object.create({}, {
                        signal: {
                            get: b
                        }
                    });
                    try {
                        const I = new EventTarget;
                        return I.addEventListener("test", E, x), I.removeEventListener("test", E, x), d
                    } catch {
                        return d
                    }
                }
                c(K, "event_abortsignal_isSupported");

                function Y() {
                    return EventTarget.prototype.addEventListener === q
                }
                c(Y, "event_abortsignal_isPolyfilled");

                function J() {
                    typeof AbortSignal == "function" && !K() && (EventTarget.prototype.addEventListener = q)
                }
                c(J, "event_abortsignal_apply");
                const G = Object.prototype.hasOwnProperty;

                function P(d, b) {
                    if (d == null) throw new TypeError("Cannot convert undefined or null to object");
                    return G.call(Object(d), b)
                }
                c(P, "object_hasown_objectHasOwn");

                function T() {
                    return "hasOwn" in Object && typeof Object.hasOwn == "function"
                }
                c(T, "object_hasown_isSupported");

                function A() {
                    return Object.hasOwn === P
                }
                c(A, "object_hasown_isPolyfilled");

                function R() {
                    T() || Object.defineProperty(Object, "hasOwn", {
                        value: P,
                        configurable: !0,
                        writable: !0
                    })
                }
                c(R, "object_hasown_apply");

                function S(d) {
                    return new Promise((b, E) => {
                        let x = !1;
                        const I = Array.from(d),
                            H = [];

                        function z(B) {
                            x || (x = !0, b(B))
                        }
                        c(z, "resolveOne");

                        function W(B) {
                            H.push(B), H.length === I.length && E(new globalThis.AggregateError(H, "All Promises rejected"))
                        }
                        c(W, "rejectIfDone");
                        for (const B of I) Promise.resolve(B).then(z, W)
                    })
                }
                c(S, "promise_any_promiseAny");

                function N() {
                    return "any" in Promise && typeof Promise.any == "function"
                }
                c(N, "promise_any_isSupported");

                function O() {
                    return Promise.all === S
                }
                c(O, "promise_any_isPolyfilled");

                function F() {
                    N() || (Promise.any = S)
                }
                c(F, "promise_any_apply");
                const U = 50;

                function $(d, b = {}) {
                    const E = Date.now(),
                        x = b.timeout || 0,
                        I = Object.defineProperty({
                            didTimeout: !1,
                            timeRemaining() {
                                return Math.max(0, U - (Date.now() - E))
                            }
                        }, "didTimeout", {
                            get() {
                                return Date.now() - E > x
                            }
                        });
                    return window.setTimeout(() => {
                        d(I)
                    })
                }
                c($, "requestidlecallback_requestIdleCallback");

                function X(d) {
                    clearTimeout(d)
                }
                c(X, "cancelIdleCallback");

                function V() {
                    return typeof globalThis.requestIdleCallback == "function"
                }
                c(V, "requestidlecallback_isSupported");

                function ne() {
                    return globalThis.requestIdleCallback === $ && globalThis.cancelIdleCallback === X
                }
                c(ne, "requestidlecallback_isPolyfilled");

                function Q() {
                    V() || (globalThis.requestIdleCallback = $, globalThis.cancelIdleCallback = X)
                }
                c(Q, "requestidlecallback_apply");
                const ee = typeof Blob == "function" && typeof PerformanceObserver == "function" && typeof Intl == "object" && typeof MutationObserver == "function" && typeof URLSearchParams == "function" && typeof WebSocket == "function" && typeof IntersectionObserver == "function" && typeof queueMicrotask == "function" && typeof TextEncoder == "function" && typeof TextDecoder == "function" && typeof customElements == "object" && typeof HTMLDetailsElement == "function" && typeof AbortController == "function" && typeof AbortSignal == "function" && "entries" in FormData.prototype && "toggleAttribute" in Element.prototype && "replaceChildren" in Element.prototype && "fromEntries" in Object && "flatMap" in Array.prototype && "trimEnd" in String.prototype && "allSettled" in Promise && "matchAll" in String.prototype && "replaceAll" in String.prototype && !0;

                function te() {
                    return ee && _() && o() && l() && m() && w() && K() && T() && N() && V()
                }
                c(te, "lib_isSupported");

                function re() {
                    return abortSignalAbort.isPolyfilled() && abortSignalTimeout.isPolyfilled() && aggregateError.isPolyfilled() && arrayAt.isPolyfilled() && cryptoRandomUUID.isPolyfilled() && eventAbortSignal.isPolyfilled() && objectHasOwn.isPolyfilled() && promiseAny.isPolyfilled() && requestIdleCallback.isPolyfilled()
                }
                c(re, "lib_isPolyfilled");

                function oe() {
                    y(), n(), a(), p(), L(), J(), R(), F(), Q()
                }
                c(oe, "lib_apply")
            },
            58797: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => v
                });

                function v(_) {
                    let h = !1,
                        y = null;
                    _.addEventListener("mousedown", n), _.addEventListener("change", o);

                    function e(u, a, s, i = !1) {
                        a instanceof HTMLInputElement && (a.indeterminate = i, a.checked !== s && (a.checked = s, setTimeout(() => {
                            const m = new CustomEvent("change", {
                                bubbles: !0,
                                cancelable: !1,
                                detail: {
                                    relatedTarget: u
                                }
                            });
                            a.dispatchEvent(m)
                        })))
                    }
                    c(e, "setChecked");

                    function o(u) {
                        const a = u.target;
                        a instanceof Element && (a.hasAttribute("data-check-all") ? t(u) : a.hasAttribute("data-check-all-item") && r(u))
                    }
                    c(o, "onChange");

                    function t(u) {
                        if (u instanceof CustomEvent && u.detail) {
                            const {
                                relatedTarget: s
                            } = u.detail;
                            if (s && s.hasAttribute("data-check-all-item")) return
                        }
                        const a = u.target;
                        if (a instanceof HTMLInputElement) {
                            y = null;
                            for (const s of _.querySelectorAll("[data-check-all-item]")) e(a, s, a.checked);
                            a.indeterminate = !1, l()
                        }
                    }
                    c(t, "onCheckAll");

                    function n(u) {
                        if (!(u.target instanceof Element)) return;
                        (u.target instanceof HTMLLabelElement && u.target.control || u.target).hasAttribute("data-check-all-item") && (h = u.shiftKey)
                    }
                    c(n, "onMouseDown");

                    function r(u) {
                        if (u instanceof CustomEvent && u.detail) {
                            const {
                                relatedTarget: m
                            } = u.detail;
                            if (m && (m.hasAttribute("data-check-all") || m.hasAttribute("data-check-all-item"))) return
                        }
                        const a = u.target;
                        if (!(a instanceof HTMLInputElement)) return;
                        const s = Array.from(_.querySelectorAll("[data-check-all-item]"));
                        if (h && y) {
                            const [m, f] = [s.indexOf(y), s.indexOf(a)].sort();
                            for (const p of s.slice(m, +f + 1 || 9e9)) e(a, p, a.checked)
                        }
                        h = !1, y = a;
                        const i = _.querySelector("[data-check-all]");
                        if (i) {
                            const m = s.length,
                                f = s.filter(w => w instanceof HTMLInputElement && w.checked).length,
                                p = f === m,
                                g = m > f && f > 0;
                            e(a, i, p, g)
                        }
                        l()
                    }
                    c(r, "onCheckAllItem");

                    function l() {
                        const u = _.querySelector("[data-check-all-count]");
                        if (u) {
                            const a = _.querySelectorAll("[data-check-all-item]:checked").length;
                            u.textContent = a.toString()
                        }
                    }
                    return c(l, "updateCount"), {
                        unsubscribe: () => {
                            _.removeEventListener("mousedown", n), _.removeEventListener("change", o)
                        }
                    }
                }
                c(v, "subscribe")
            },
            15205: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => _
                });

                function v(...h) {
                    return JSON.stringify(h, (y, e) => typeof e == "object" ? e : String(e))
                }
                c(v, "defaultHash");

                function _(h, y = {}) {
                    const {
                        hash: e = v,
                        cache: o = new Map
                    } = y;
                    return function(...t) {
                        const n = e.apply(this, t);
                        if (o.has(n)) return o.get(n);
                        let r = h.apply(this, t);
                        return r instanceof Promise && (r = r.catch(l => {
                            throw o.delete(n), l
                        })), o.set(n, r), r
                    }
                }
                c(_, "memoize")
            },
            61268: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => v
                });
                class v {
                    constructor(h) {
                        if (this.map = new Map, h)
                            for (const [y, e] of h) this.set(y, e)
                    }
                    get(h) {
                        const y = this.map.get(h);
                        return y || new Set
                    }
                    set(h, y) {
                        let e = this.map.get(h);
                        return e || (e = new Set, this.map.set(h, e)), e.add(y), this
                    }
                    has(h) {
                        return this.map.has(h)
                    }
                    delete(h, y) {
                        const e = this.map.get(h);
                        if (!e) return !1;
                        if (!y) return this.map.delete(h);
                        const o = e.delete(y);
                        return e.size || this.map.delete(h), o
                    }
                    drain(h) {
                        const y = [];
                        for (const e of this.keys()) this.delete(e, h) && !this.has(e) && y.push(e);
                        return y
                    }
                    keys() {
                        return this.map.keys()
                    }
                    values() {
                        return this.map.values()
                    }
                    entries() {
                        return this.map.entries()
                    }[Symbol.iterator]() {
                        return this.entries()
                    }
                    clear() {
                        this.map.clear()
                    }
                    get size() {
                        return this.map.size
                    }
                }
                c(v, "MultiMap")
            },
            16544: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Oo: () => l
                });
                async function v(f, p) {
                    let g;
                    const w = new Promise((M, L) => {
                        g = self.setTimeout(() => L(new Error("timeout")), f)
                    });
                    if (!p) return w;
                    try {
                        await Promise.race([w, y(p)])
                    } catch (M) {
                        throw self.clearTimeout(g), M
                    }
                }
                c(v, "timeout");
                async function _(f, p) {
                    let g;
                    const w = new Promise(M => {
                        g = self.setTimeout(M, f)
                    });
                    if (!p) return w;
                    try {
                        await Promise.race([w, y(p)])
                    } catch (M) {
                        throw self.clearTimeout(g), M
                    }
                }
                c(_, "wait");
                async function h(f, p, g = 1 / 0, w) {
                    const M = w ? y(w) : null;
                    for (let L = 0; L < p; L++) try {
                        return await (M ? Promise.race([f(), M]) : f())
                    } catch (j) {
                        if (j.name === "AbortError" || L === p - 1) throw j;
                        const q = Math.pow(2, L) * 1e3,
                            K = e(q * .1);
                        await _(Math.min(g, q + K), w)
                    }
                    throw new Error("retry failed")
                }
                c(h, "retry");

                function y(f) {
                    return new Promise((p, g) => {
                        const w = new Error("aborted");
                        w.name = "AbortError", f.aborted ? g(w) : f.addEventListener("abort", () => g(w))
                    })
                }
                c(y, "whenAborted");

                function e(f) {
                    return Math.floor(Math.random() * Math.floor(f))
                }
                c(e, "rand");
                async function o(f, p, g) {
                    const w = new WebSocket(f),
                        M = r(w);
                    try {
                        return await Promise.race([M, v(p, g)]), w
                    } catch (L) {
                        throw t(M), L
                    }
                }
                c(o, "connect");
                async function t(f) {
                    try {
                        (await f).close()
                    } catch {}
                }
                c(t, "shutdown");

                function n(f, p) {
                    return h(c(() => o(f, p.timeout, p.signal), "fn"), p.attempts, p.maxDelay, p.signal)
                }
                c(n, "connectWithRetry");

                function r(f) {
                    return new Promise((p, g) => {
                        f.readyState === WebSocket.OPEN ? p(f) : (f.onerror = () => {
                            f.onerror = null, f.onopen = null, g(new Error("connect failed"))
                        }, f.onopen = () => {
                            f.onerror = null, f.onopen = null, p(f)
                        })
                    })
                }
                c(r, "whenOpen");
                class l {
                    constructor(p, g, w) {
                        this.socket = null, this.opening = null, this.url = p, this.delegate = g, this.policy = w
                    }
                    async open() {
                        if (this.opening || this.socket) return;
                        this.opening = new AbortController;
                        const p = Object.assign(Object.assign({}, this.policy), {
                            signal: this.opening.signal
                        });
                        try {
                            this.socket = await n(this.url, p)
                        } catch {
                            this.delegate.socketDidFinish(this);
                            return
                        } finally {
                            this.opening = null
                        }
                        this.socket.onclose = g => {
                            this.socket = null, this.delegate.socketDidClose(this, g.code, g.reason), (this.delegate.socketShouldRetry ? !this.delegate.socketShouldRetry(this, g.code) : a(g.code)) ? this.delegate.socketDidFinish(this) : setTimeout(() => this.open(), u(100, 100 + (this.delegate.reconnectWindow || 50)))
                        }, this.socket.onmessage = g => {
                            this.delegate.socketDidReceiveMessage(this, g.data)
                        }, this.delegate.socketDidOpen(this)
                    }
                    close(p, g) {
                        this.opening ? (this.opening.abort(), this.opening = null) : this.socket && (this.socket.onclose = null, this.socket.close(p, g), this.socket = null, this.delegate.socketDidClose(this, p, g), this.delegate.socketDidFinish(this))
                    }
                    send(p) {
                        this.socket && this.socket.send(p)
                    }
                    isOpen() {
                        return !!this.socket
                    }
                }
                c(l, "StableSocket");

                function u(f, p) {
                    return Math.random() * (p - f) + f
                }
                c(u, "rand$1");

                function a(f) {
                    return f === s || f === i
                }
                c(a, "isFatal");
                const s = 1008,
                    i = 1011;
                class m {
                    constructor(p) {
                        this.buf = [], this.socket = p, this.delegate = p.delegate, p.delegate = this
                    }
                    open() {
                        return this.socket.open()
                    }
                    close(p, g) {
                        this.socket.close(p, g)
                    }
                    send(p) {
                        this.socket.isOpen() ? (this.flush(), this.socket.send(p)) : this.buf.push(p)
                    }
                    isOpen() {
                        return this.socket.isOpen()
                    }
                    flush() {
                        for (const p of this.buf) this.socket.send(p);
                        this.buf.length = 0
                    }
                    socketDidOpen(p) {
                        this.flush(), this.delegate.socketDidOpen(p)
                    }
                    socketDidClose(p, g, w) {
                        this.delegate.socketDidClose(p, g, w)
                    }
                    socketDidFinish(p) {
                        this.delegate.socketDidFinish(p)
                    }
                    socketDidReceiveMessage(p, g) {
                        this.delegate.socketDidReceiveMessage(p, g)
                    }
                    socketShouldRetry(p, g) {
                        return this.delegate.socketShouldRetry ? this.delegate.socketShouldRetry(p, g) : !a(g)
                    }
                }
                c(m, "BufferedSocket")
            },
            89900: (D, C, k) => {
                "use strict";
                k.d(C, {
                    Z: () => y
                });
                const v = ["direction", "boxSizing", "width", "height", "overflowX", "overflowY", "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth", "borderStyle", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "fontStyle", "fontVariant", "fontWeight", "fontStretch", "fontSize", "fontSizeAdjust", "lineHeight", "fontFamily", "textAlign", "textTransform", "textIndent", "textDecoration", "letterSpacing", "wordSpacing", "tabSize", "MozTabSize"],
                    h = typeof window != "undefined" && window.mozInnerScreenX != null;

                function y(e, o, t) {
                    const n = t && t.debug || !1;
                    if (n) {
                        const m = document.querySelector("#input-textarea-caret-position-mirror-div");
                        m && m.parentNode.removeChild(m)
                    }
                    const r = document.createElement("div");
                    r.id = "input-textarea-caret-position-mirror-div", document.body.appendChild(r);
                    const l = r.style,
                        u = window.getComputedStyle ? window.getComputedStyle(e) : e.currentStyle,
                        a = e.nodeName === "INPUT";
                    l.whiteSpace = "pre-wrap", a || (l.wordWrap = "break-word"), l.position = "absolute", n || (l.visibility = "hidden");
                    for (const m of v)
                        if (a && m === "lineHeight")
                            if (u.boxSizing === "border-box") {
                                const f = parseInt(u.height),
                                    p = parseInt(u.paddingTop) + parseInt(u.paddingBottom) + parseInt(u.borderTopWidth) + parseInt(u.borderBottomWidth),
                                    g = p + parseInt(u.lineHeight);
                                f > g ? l.lineHeight = `${f-p}px` : f === g ? l.lineHeight = u.lineHeight : l.lineHeight = 0
                            } else l.lineHeight = u.height;
                    else if (!a && m === "width" && u.boxSizing === "border-box") {
                        let f = parseFloat(u.borderLeftWidth) + parseFloat(u.borderRightWidth),
                            p = h ? parseFloat(u[m]) - f : e.clientWidth + f;
                        l[m] = `${p}px`
                    } else l[m] = u[m];
                    h ? e.scrollHeight > parseInt(u.height) && (l.overflowY = "scroll") : l.overflow = "hidden", r.textContent = e.value.substring(0, o), a && (r.textContent = r.textContent.replace(/\s/g, "\xA0"));
                    const s = document.createElement("span");
                    s.textContent = e.value.substring(o) || ".", r.appendChild(s);
                    const i = {
                        top: s.offsetTop + parseInt(u.borderTopWidth),
                        left: s.offsetLeft + parseInt(u.borderLeftWidth),
                        height: parseInt(u.lineHeight)
                    };
                    return n ? s.style.backgroundColor = "#aaa" : document.body.removeChild(r), i
                }
                c(y, "getCaretCoordinates")
            }
        }
    ]);
})();

//# sourceMappingURL=6262-8e86f23b8c54.js.map