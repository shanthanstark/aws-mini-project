"use strict";
(() => {
    var me = Object.defineProperty;
    var t = (R, S) => me(R, "name", {
        value: S,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [3682], {
            43682: (R, S, d) => {
                d.d(S, {
                    ZP: () => M,
                    y0: () => le
                });
                var m = d(40728),
                    u = d(7143),
                    s = d(14037),
                    f = d(31756),
                    p = d(10900),
                    g = d(83476);
                const l = 20;
                let a, h = null;

                function i(r, o, e) {
                    return r.dispatchEvent(new CustomEvent(o, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: e
                    }))
                }
                t(i, "dispatch");
                async function M(r) {
                    var o, e, n, _;
                    const c = {
                        push: !0,
                        replace: !1,
                        type: "GET",
                        dataType: "html",
                        scrollTo: 0,
                        ...r
                    };
                    c.requestUrl = c.url;
                    const y = q(c.url).hash,
                        E = c.container,
                        j = z(E);
                    a || (a = {
                        id: C(),
                        url: window.location.href,
                        title: document.title,
                        container: j,
                        fragment: c.fragment
                    }, (0, m.lO)(a, a.title, a.url)), h == null || h.abort();
                    const {
                        signal: x
                    } = h = new AbortController;
                    c.push === !0 && c.replace !== !0 && (ae(a.id, Z(E)), (0, m.qA)(null, "", c.requestUrl)), i(E, "pjax:start", {
                        url: c.url
                    }), i(E, "pjax:send");
                    let w;
                    const b = se();
                    try {
                        w = await fetch(c.url, {
                            signal: x,
                            method: c.type,
                            body: c.data,
                            headers: {
                                Accept: "text/html",
                                "X-PJAX": "true",
                                "X-PJAX-Container": j,
                                "X-Requested-With": "XMLHttpRequest",
                                "X-PJAX-VERSION": (o = b.pjax) != null ? o : "",
                                "X-PJAX-CSP-VERSION": (e = b.csp) != null ? e : "",
                                "X-PJAX-CSS-VERSION": (n = b.css) != null ? n : "",
                                "X-PJAX-JS-VERSION": (_ = b.js) != null ? _ : ""
                            }
                        })
                    } catch {
                        w = void 0
                    }
                    if (!w || !w.ok) {
                        const X = i(E, "pjax:error");
                        if (c.type === "GET" && X) {
                            const $ = w && w.headers.get("X-PJAX-URL"),
                                fe = $ ? q($).href : c.requestUrl;
                            (0, g.b)({
                                pjaxFailureReason: "response_error",
                                requestUrl: c.requestUrl
                            }), L(fe)
                        }
                        i(E, "pjax:complete"), i(E, "pjax:end");
                        return
                    }
                    const H = a,
                        Q = ie(),
                        Y = w.headers.get("X-PJAX-Version"),
                        ue = await w.text(),
                        A = ne(ue, w, c),
                        {
                            contents: V
                        } = A,
                        ee = q(A.url);
                    if (y && (ee.hash = y, A.url = ee.href), Q && Y && Q !== Y) {
                        i(E, "pjax:hardLoad", {
                            reason: "version_mismatch"
                        }), (0, g.b)({
                            pjaxFailureReason: "version_mismatch",
                            requestUrl: c.requestUrl
                        }), L(A.url);
                        return
                    }
                    if (!V) {
                        i(E, "pjax:hardLoad", {
                            reason: "missing_response_body"
                        }), (0, g.b)({
                            pjaxFailureReason: "missing_response_body",
                            requestUrl: c.requestUrl
                        }), L(A.url);
                        return
                    }
                    a = {
                        id: c.id != null ? c.id : C(),
                        url: A.url,
                        title: A.title,
                        container: j,
                        fragment: c.fragment
                    }, (c.push === !0 || c.replace === !0) && (0, m.lO)(a, A.title, A.url);
                    const F = document.activeElement,
                        de = c.container != null && c.container.contains(F);
                    if (F instanceof HTMLElement && de) try {
                        F.blur()
                    } catch {}
                    A.title && (document.title = A.title), i(E, "pjax:beforeReplace", {
                        contents: V,
                        state: a,
                        previousState: H
                    }), G(E, V), (0, u.b)(), (0, u.o)();
                    const W = E.querySelector("input[autofocus], textarea[autofocus]");
                    W && document.activeElement !== W && W.focus(), A.scripts && oe(A.scripts), A.stylesheets && re(A.stylesheets);
                    let K = c.scrollTo;
                    if (y) {
                        const X = (0, s.Kt)(document, y);
                        X && (K = X.getBoundingClientRect().top + window.pageYOffset)
                    }
                    typeof K == "number" && window.scrollTo(window.pageXOffset, K), i(E, "pjax:success"), i(E, "pjax:complete"), i(E, "pjax:end")
                }
                t(M, "pjaxRequest");

                function L(r) {
                    a && (0, m.lO)(null, "", a.url), window.location.replace(r)
                }
                t(L, "locationReplace");
                let U = !0;
                const v = window.location.href,
                    P = window.history.state;
                P && P.container && (a = P), "state" in window.history && (U = !1);

                function T(r) {
                    if ((0, f.c)("PJAX_DISABLED") || (0, f.c)("TURBO")) return;
                    U || h == null || h.abort();
                    const o = a,
                        e = r.state;
                    let n = null;
                    if (e && e.container) {
                        if (U && v === e.url) return;
                        if (o) {
                            if (o.id === e.id) return;
                            n = o.id < e.id ? "forward" : "back"
                        }
                        const [_, c, O] = D[e.id] || [], y = document.querySelector(_ || e.container);
                        if (y instanceof HTMLElement) {
                            o && ce(n, o.id, Z(y)), i(y, "pjax:popstate", {
                                state: e,
                                direction: n,
                                cachedAt: O
                            });
                            const E = {
                                id: e.id,
                                url: e.url,
                                container: y,
                                push: !1,
                                fragment: e.fragment || "",
                                scrollTo: !1
                            };
                            c ? (i(y, "pjax:start"), a = e, e.title && (document.title = e.title), i(y, "pjax:beforeReplace", {
                                contents: c,
                                state: e,
                                previousState: o
                            }), G(y, c), (0, u.b)(), (0, u.o)(), i(y, "pjax:end")) : M(E), y.offsetHeight
                        } else(0, g.b)({
                            pjaxFailureReason: "no_container",
                            requestUrl: o == null ? void 0 : o.url
                        }), L(location.href)
                    }
                    U = !1
                }
                t(T, "onPjaxPopstate");

                function C() {
                    return new Date().getTime()
                }
                t(C, "uniqueId");

                function Z(r) {
                    const o = r.cloneNode(!0);
                    return [z(r), Array.from(o.childNodes), Date.now()]
                }
                t(Z, "cloneContents");

                function q(r) {
                    const o = document.createElement("a");
                    return o.href = r, o
                }
                t(q, "parseURL");

                function z(r) {
                    if (r.id) return `#${r.id}`;
                    throw new Error("pjax container has no id")
                }
                t(z, "getContainerSelector");

                function I(r, o, e) {
                    let n = [];
                    for (const _ of r) _ instanceof Element && (_ instanceof e && _.matches(o) && n.push(_), n = n.concat(Array.from(_.querySelectorAll(o))));
                    return n
                }
                t(I, "findAll");

                function G(r, o) {
                    r.innerHTML = "";
                    for (const e of o) e != null && r.appendChild(e)
                }
                t(G, "replaceWithNodes");

                function te(r, o) {
                    const e = r.headers.get("X-PJAX-URL");
                    return e ? q(e).href : o
                }
                t(te, "resolveUrl");

                function ne(r, o, e) {
                    const n = {
                            url: te(o, e.requestUrl),
                            title: ""
                        },
                        _ = /<html/i.test(r);
                    if ((o.headers.get("Content-Type") || "").split(";", 1)[0].trim() !== "text/html") return n;
                    let O, y;
                    if (_) {
                        const x = r.match(/<head[^>]*>([\s\S.]*)<\/head>/i),
                            w = r.match(/<body[^>]*>([\s\S.]*)<\/body>/i);
                        O = x ? Array.from((0, p.r)(document, x[0]).childNodes) : [], y = w ? Array.from((0, p.r)(document, w[0]).childNodes) : []
                    } else O = y = Array.from((0, p.r)(document, r).childNodes);
                    if (y.length === 0) return n;
                    const E = I(O, "title", HTMLTitleElement);
                    n.title = E.length > 0 && E[E.length - 1].textContent || "";
                    let j;
                    if (e.fragment) {
                        if (e.fragment === "body") j = y;
                        else {
                            const x = I(y, e.fragment, Element);
                            j = x.length > 0 ? [x[0]] : []
                        }
                        if (j.length && (e.fragment === "body" ? n.contents = j : n.contents = j.flatMap(x => Array.from(x.childNodes)), !n.title)) {
                            const x = j[0];
                            x instanceof Element && (n.title = x.getAttribute("title") || x.getAttribute("data-title") || "")
                        }
                    } else _ || (n.contents = y);
                    if (n.contents) {
                        n.contents = n.contents.filter(function(b) {
                            return b instanceof Element ? !b.matches("title") : !0
                        });
                        for (const b of n.contents)
                            if (b instanceof Element)
                                for (const H of b.querySelectorAll("title")) H.remove();
                        const x = I(n.contents, "script[src]", HTMLScriptElement);
                        for (const b of x) b.remove();
                        n.scripts = x, n.contents = n.contents.filter(b => x.indexOf(b) === -1);
                        const w = I(n.contents, "link[rel=stylesheet]", HTMLLinkElement);
                        for (const b of w) b.remove();
                        n.stylesheets = w, n.contents = n.contents.filter(b => !w.includes(b))
                    }
                    return n.title && (n.title = n.title.trim()), n
                }
                t(ne, "extractContainer");

                function oe(r) {
                    const o = document.querySelectorAll("script[src]");
                    for (const e of r) {
                        const {
                            src: n
                        } = e;
                        if (Array.from(o).some(y => y.src === n)) continue;
                        const _ = document.createElement("script"),
                            c = e.getAttribute("type");
                        c && (_.type = c);
                        const O = e.getAttribute("integrity");
                        O && (_.integrity = O, _.crossOrigin = "anonymous"), _.src = n, document.head && document.head.appendChild(_)
                    }
                }
                t(oe, "executeScriptTags");

                function re(r) {
                    const o = document.querySelectorAll("link[rel=stylesheet]");
                    for (const e of r) Array.from(o).some(n => n.href === e.href) || document.head && document.head.appendChild(e)
                }
                t(re, "injectStyleTags");
                const D = {},
                    J = [],
                    N = [];

                function ae(r, o) {
                    D[r] = o, N.push(r), k(J, 0), k(N, l)
                }
                t(ae, "cachePush");

                function ce(r, o, e) {
                    let n, _;
                    D[o] = e, r === "forward" ? (n = N, _ = J) : (n = J, _ = N), n.push(o);
                    const c = _.pop();
                    c && delete D[c], k(n, l)
                }
                t(ce, "cachePop");

                function k(r, o) {
                    for (; r.length > o;) {
                        const e = r.shift();
                        if (e == null) return;
                        delete D[e]
                    }
                }
                t(k, "trimCacheStack");

                function ie() {
                    for (const r of document.getElementsByTagName("meta")) {
                        const o = r.getAttribute("http-equiv");
                        if (o && o.toUpperCase() === "X-PJAX-VERSION") return r.content
                    }
                    return null
                }
                t(ie, "findVersion");

                function B(r) {
                    var o;
                    const e = document.querySelector(`meta[http-equiv="${r}"]`);
                    return (o = e == null ? void 0 : e.content) != null ? o : null
                }
                t(B, "pjaxMeta");

                function se() {
                    return {
                        pjax: B("X-PJAX-VERSION"),
                        csp: B("X-PJAX-CSP-VERSION"),
                        css: B("X-PJAX-CSS-VERSION"),
                        js: B("X-PJAX-JS-VERSION")
                    }
                }
                t(se, "findAllVersions");

                function le() {
                    return a
                }
                t(le, "getState"), window.addEventListener("popstate", T)
            },
            7143: (R, S, d) => {
                d.d(S, {
                    b: () => f,
                    o: () => p
                });
                var m = d(34782);
                const u = {},
                    s = {};
                (async () => (await m.x, u[document.location.pathname] = Array.from(document.querySelectorAll("head [data-pjax-transient]")), s[document.location.pathname] = Array.from(document.querySelectorAll("[data-pjax-replace]"))))(), document.addEventListener("pjax:beforeReplace", function(g) {
                    const l = g.detail.contents || [],
                        a = g.target;
                    for (let h = 0; h < l.length; h++) {
                        const i = l[h];
                        i instanceof Element && (i.id === "pjax-head" ? (u[document.location.pathname] = Array.from(i.children), l[h] = null) : i.hasAttribute("data-pjax-replace") && (s[document.location.pathname] || (s[document.location.pathname] = []), s[document.location.pathname].push(i), a.querySelector(`#${i.id}`) || (l[h] = null)))
                    }
                });

                function f() {
                    const g = s[document.location.pathname];
                    if (!!g)
                        for (const l of g) {
                            const a = document.querySelector(`#${l.id}`);
                            a && a.replaceWith(l)
                        }
                }
                t(f, "replaceCachedElements");

                function p() {
                    const g = u[document.location.pathname];
                    if (!g) return;
                    const l = document.head;
                    for (const a of document.querySelectorAll("head [data-pjax-transient]")) a.remove();
                    for (const a of g) a.matches("title, script, link[rel=stylesheet]") ? a.matches("link[rel=stylesheet]") && l.append(a) : (a.setAttribute("data-pjax-transient", ""), l.append(a))
                }
                t(p, "replaceTransientTags")
            },
            34782: (R, S, d) => {
                d.d(S, {
                    C: () => u,
                    x: () => m
                });
                const m = function() {
                        return document.readyState === "interactive" || document.readyState === "complete" ? Promise.resolve() : new Promise(s => {
                            document.addEventListener("DOMContentLoaded", () => {
                                s()
                            })
                        })
                    }(),
                    u = function() {
                        return document.readyState === "complete" ? Promise.resolve() : new Promise(s => {
                            window.addEventListener("load", s)
                        })
                    }()
            },
            31756: (R, S, d) => {
                d.d(S, {
                    $: () => g,
                    c: () => f
                });
                var m = d(15205);
                const u = (0, m.Z)(s);

                function s() {
                    var l, a;
                    return (((a = (l = document.head) == null ? void 0 : l.querySelector('meta[name="enabled-features"]')) == null ? void 0 : a.content) || "").split(",")
                }
                t(s, "enabledFeatures");
                const f = (0, m.Z)(p);

                function p(l) {
                    return u().indexOf(l) !== -1
                }
                t(p, "isEnabled");
                const g = {
                    isFeatureEnabled: f
                }
            },
            14037: (R, S, d) => {
                d.d(S, {
                    $z: () => s,
                    Kt: () => m,
                    Q: () => u
                });

                function m(f, p = location.hash) {
                    return u(f, s(p))
                }
                t(m, "findFragmentTarget");

                function u(f, p) {
                    return p === "" ? null : f.getElementById(p) || f.getElementsByName(p)[0]
                }
                t(u, "findElementByFragmentName");

                function s(f) {
                    try {
                        return decodeURIComponent(f.slice(1))
                    } catch {
                        return ""
                    }
                }
                t(s, "decodeFragmentValue")
            },
            40728: (R, S, d) => {
                d.d(S, {
                    Mw: () => U,
                    _C: () => L,
                    lO: () => M,
                    qA: () => i,
                    y0: () => f
                });
                const m = [];
                let u = 0,
                    s;

                function f() {
                    return s
                }
                t(f, "getState");

                function p() {
                    try {
                        return Math.min(Math.max(0, history.length) || 0, 9007199254740991)
                    } catch {
                        return 0
                    }
                }
                t(p, "safeGetHistory");

                function g() {
                    const v = {
                        _id: new Date().getTime(),
                        ...history.state
                    };
                    return a(v), v
                }
                t(g, "initializeState");

                function l() {
                    return p() - 1 + u
                }
                t(l, "position");

                function a(v) {
                    s = v;
                    const P = location.href;
                    m[l()] = {
                        url: P,
                        state: s
                    }, m.length = p(), window.dispatchEvent(new CustomEvent("statechange", {
                        bubbles: !1,
                        cancelable: !1
                    }))
                }
                t(a, "setState");

                function h() {
                    return new Date().getTime()
                }
                t(h, "uniqueId");

                function i(v, P, T) {
                    u = 0;
                    const C = {
                        _id: h(),
                        ...v
                    };
                    history.pushState(C, P, T), a(C)
                }
                t(i, "pushState");

                function M(v, P, T) {
                    const C = { ...f(),
                        ...v
                    };
                    history.replaceState(C, P, T), a(C)
                }
                t(M, "replaceState");

                function L() {
                    const v = m[l() - 1];
                    if (v) return v.url
                }
                t(L, "getBackURL");

                function U() {
                    const v = m[l() + 1];
                    if (v) return v.url
                }
                t(U, "getForwardURL"), s = g(), window.addEventListener("popstate", t(function(P) {
                    const T = P.state;
                    if (!T || !T._id) return;
                    T._id < (f()._id || NaN) ? u-- : u++, a(T)
                }, "onPopstate"), !0), window.addEventListener("hashchange", t(function() {
                    if (p() > m.length) {
                        const P = {
                            _id: h()
                        };
                        history.replaceState(P, "", location.href), a(P)
                    }
                }, "onHashchange"), !0)
            },
            10900: (R, S, d) => {
                d.d(S, {
                    r: () => m
                });

                function m(u, s) {
                    const f = u.createElement("template");
                    return f.innerHTML = s, u.importNode(f.content, !0)
                }
                t(m, "parseHTML")
            },
            43452: (R, S, d) => {
                d.d(S, {
                    Z: () => m
                });

                function m(u) {
                    var s, f;
                    const p = (f = (s = u.head) == null ? void 0 : s.querySelector('meta[name="expected-hostname"]')) == null ? void 0 : f.content;
                    if (!p) return !1;
                    const g = p.replace(/\.$/, "").split(".").slice(-2).join("."),
                        l = u.location.hostname.replace(/\.$/, "").split(".").slice(-2).join(".");
                    return g !== l
                }
                t(m, "detectProxySite")
            },
            83476: (R, S, d) => {
                d.d(S, {
                    b: () => f
                });
                var m = d(43452),
                    u = d(34782);
                let s = [];

                function f(h, i = !1) {
                    h.timestamp === void 0 && (h.timestamp = new Date().getTime()), h.loggedIn = a(), s.push(h), i ? l() : g()
                }
                t(f, "sendStats");
                let p = null;
                async function g() {
                    await u.C, p == null && (p = window.requestIdleCallback(l))
                }
                t(g, "scheduleSendStats");

                function l() {
                    var h, i;
                    if (p = null, !s.length || (0, m.Z)(document)) return;
                    const M = (i = (h = document.head) == null ? void 0 : h.querySelector('meta[name="browser-stats-url"]')) == null ? void 0 : i.content;
                    if (!M) return;
                    const L = JSON.stringify({
                        stats: s
                    });
                    try {
                        navigator.sendBeacon && navigator.sendBeacon(M, L)
                    } catch {}
                    s = []
                }
                t(l, "flushStats");

                function a() {
                    var h, i;
                    return !!((i = (h = document.head) == null ? void 0 : h.querySelector('meta[name="user-login"]')) == null ? void 0 : i.content)
                }
                t(a, "isLoggedIn"), document.addEventListener("pagehide", l), document.addEventListener("visibilitychange", l)
            }
        }
    ]);
})();

//# sourceMappingURL=3682-1137c22bd5e0.js.map