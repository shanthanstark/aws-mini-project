(() => {
    var H = Object.defineProperty;
    var b = (S, M) => H(S, "name", {
        value: M,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [9073, 9753], {
            59753: (S, M, l) => {
                "use strict";
                l.d(M, {
                    f: () => $,
                    on: () => g
                });

                function d() {
                    if (!(this instanceof d)) return new d;
                    this.size = 0, this.uid = 0, this.selectors = [], this.selectorObjects = {}, this.indexes = Object.create(this.indexes), this.activeIndexes = []
                }
                b(d, "SelectorSet");
                var m = window.document.documentElement,
                    I = m.matches || m.webkitMatchesSelector || m.mozMatchesSelector || m.oMatchesSelector || m.msMatchesSelector;
                d.prototype.matchesSelector = function(t, r) {
                    return I.call(t, r)
                }, d.prototype.querySelectorAll = function(t, r) {
                    return r.querySelectorAll(t)
                }, d.prototype.indexes = [];
                var x = /^#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
                d.prototype.indexes.push({
                    name: "ID",
                    selector: b(function(r) {
                        var n;
                        if (n = r.match(x)) return n[0].slice(1)
                    }, "matchIdSelector"),
                    element: b(function(r) {
                        if (r.id) return [r.id]
                    }, "getElementId")
                });
                var P = /^\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
                d.prototype.indexes.push({
                    name: "CLASS",
                    selector: b(function(r) {
                        var n;
                        if (n = r.match(P)) return n[0].slice(1)
                    }, "matchClassSelector"),
                    element: b(function(r) {
                        var n = r.className;
                        if (n) {
                            if (typeof n == "string") return n.split(/\s/);
                            if (typeof n == "object" && "baseVal" in n) return n.baseVal.split(/\s/)
                        }
                    }, "getElementClassNames")
                });
                var N = /^((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
                d.prototype.indexes.push({
                    name: "TAG",
                    selector: b(function(r) {
                        var n;
                        if (n = r.match(N)) return n[0].toUpperCase()
                    }, "matchTagSelector"),
                    element: b(function(r) {
                        return [r.nodeName.toUpperCase()]
                    }, "getElementTagName")
                }), d.prototype.indexes.default = {
                    name: "UNIVERSAL",
                    selector: function() {
                        return !0
                    },
                    element: function() {
                        return [!0]
                    }
                };
                var O;
                typeof window.Map == "function" ? O = window.Map : O = function() {
                    function t() {
                        this.map = {}
                    }
                    return b(t, "Map"), t.prototype.get = function(r) {
                        return this.map[r + " "]
                    }, t.prototype.set = function(r, n) {
                        this.map[r + " "] = n
                    }, t
                }();
                var q = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g;

                function C(t, r) {
                    t = t.slice(0).concat(t.default);
                    var n = t.length,
                        h, u, f, c, v = r,
                        w, A, T = [];
                    do
                        if (q.exec(""), (f = q.exec(v)) && (v = f[3], f[2] || !v)) {
                            for (h = 0; h < n; h++)
                                if (A = t[h], w = A.selector(f[1])) {
                                    for (u = T.length, c = !1; u--;)
                                        if (T[u].index === A && T[u].key === w) {
                                            c = !0;
                                            break
                                        }
                                    c || T.push({
                                        index: A,
                                        key: w
                                    });
                                    break
                                }
                        }
                    while (f);
                    return T
                }
                b(C, "parseSelectorIndexes");

                function R(t, r) {
                    var n, h, u;
                    for (n = 0, h = t.length; n < h; n++)
                        if (u = t[n], r.isPrototypeOf(u)) return u
                }
                b(R, "findByPrototype"), d.prototype.logDefaultIndexUsed = function() {}, d.prototype.add = function(t, r) {
                    var n, h, u, f, c, v, w, A, T = this.activeIndexes,
                        j = this.selectors,
                        F = this.selectorObjects;
                    if (typeof t == "string") {
                        for (n = {
                                id: this.uid++,
                                selector: t,
                                data: r
                            }, F[n.id] = n, w = C(this.indexes, t), h = 0; h < w.length; h++) A = w[h], f = A.key, u = A.index, c = R(T, u), c || (c = Object.create(u), c.map = new O, T.push(c)), u === this.indexes.default && this.logDefaultIndexUsed(n), v = c.map.get(f), v || (v = [], c.map.set(f, v)), v.push(n);
                        this.size++, j.push(t)
                    }
                }, d.prototype.remove = function(t, r) {
                    if (typeof t == "string") {
                        var n, h, u, f, c, v, w, A, T = this.activeIndexes,
                            j = this.selectors = [],
                            F = this.selectorObjects,
                            W = {},
                            _ = arguments.length === 1;
                        for (n = C(this.indexes, t), u = 0; u < n.length; u++)
                            for (h = n[u], f = T.length; f--;)
                                if (v = T[f], h.index.isPrototypeOf(v)) {
                                    if (w = v.map.get(h.key), w)
                                        for (c = w.length; c--;) A = w[c], A.selector === t && (_ || A.data === r) && (w.splice(c, 1), W[A.id] = !0);
                                    break
                                }
                        for (u in W) delete F[u], this.size--;
                        for (u in F) j.push(F[u].selector)
                    }
                };

                function B(t, r) {
                    return t.id - r.id
                }
                b(B, "sortById"), d.prototype.queryAll = function(t) {
                    if (!this.selectors.length) return [];
                    var r = {},
                        n = [],
                        h = this.querySelectorAll(this.selectors.join(", "), t),
                        u, f, c, v, w, A, T, j;
                    for (u = 0, c = h.length; u < c; u++)
                        for (w = h[u], A = this.matches(w), f = 0, v = A.length; f < v; f++) j = A[f], r[j.id] ? T = r[j.id] : (T = {
                            id: j.id,
                            selector: j.selector,
                            data: j.data,
                            elements: []
                        }, r[j.id] = T, n.push(T)), T.elements.push(w);
                    return n.sort(B)
                }, d.prototype.matches = function(t) {
                    if (!t) return [];
                    var r, n, h, u, f, c, v, w, A, T, j, F = this.activeIndexes,
                        W = {},
                        _ = [];
                    for (r = 0, u = F.length; r < u; r++)
                        if (v = F[r], w = v.element(t), w) {
                            for (n = 0, f = w.length; n < f; n++)
                                if (A = v.map.get(w[n]))
                                    for (h = 0, c = A.length; h < c; h++) T = A[h], j = T.id, !W[j] && this.matchesSelector(t, T.selector) && (W[j] = !0, _.push(T))
                        }
                    return _.sort(B)
                };
                var a = {},
                    p = {},
                    L = new WeakMap,
                    E = new WeakMap,
                    D = new WeakMap,
                    X = Object.getOwnPropertyDescriptor(Event.prototype, "currentTarget");

                function U(t, r, n) {
                    var h = t[r];
                    return t[r] = function() {
                        return n.apply(t, arguments), h.apply(t, arguments)
                    }, t
                }
                b(U, "before");

                function z(t, r, n) {
                    var h = [],
                        u = r;
                    do {
                        if (u.nodeType !== 1) break;
                        var f = t.matches(u);
                        if (f.length) {
                            var c = {
                                node: u,
                                observers: f
                            };
                            n ? h.unshift(c) : h.push(c)
                        }
                    } while (u = u.parentElement);
                    return h
                }
                b(z, "dist_matches");

                function G() {
                    L.set(this, !0)
                }
                b(G, "trackPropagation");

                function s() {
                    L.set(this, !0), E.set(this, !0)
                }
                b(s, "trackImmediate");

                function e() {
                    return D.get(this) || null
                }
                b(e, "getCurrentTarget");

                function i(t, r) {
                    !X || Object.defineProperty(t, "currentTarget", {
                        configurable: !0,
                        enumerable: !0,
                        get: r || X.get
                    })
                }
                b(i, "defineCurrentTarget");

                function o(t) {
                    try {
                        return t.eventPhase, !0
                    } catch {
                        return !1
                    }
                }
                b(o, "canDispatch");

                function y(t) {
                    if (!!o(t)) {
                        var r = t.eventPhase === 1 ? p : a,
                            n = r[t.type];
                        if (!!n) {
                            var h = z(n, t.target, t.eventPhase === 1);
                            if (!!h.length) {
                                U(t, "stopPropagation", G), U(t, "stopImmediatePropagation", s), i(t, e);
                                for (var u = 0, f = h.length; u < f && !L.get(t); u++) {
                                    var c = h[u];
                                    D.set(t, c.node);
                                    for (var v = 0, w = c.observers.length; v < w && !E.get(t); v++) c.observers[v].data.call(c.node, t)
                                }
                                D.delete(t), i(t)
                            }
                        }
                    }
                }
                b(y, "dispatch");

                function g(t, r, n) {
                    var h = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {},
                        u = !!h.capture,
                        f = u ? p : a,
                        c = f[t];
                    c || (c = new d, f[t] = c, document.addEventListener(t, y, u)), c.add(r, n)
                }
                b(g, "on");

                function k(t, r, n) {
                    var h = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {},
                        u = !!h.capture,
                        f = u ? p : a,
                        c = f[t];
                    !c || (c.remove(r, n), !c.size && (delete f[t], document.removeEventListener(t, y, u)))
                }
                b(k, "off");

                function $(t, r, n) {
                    return t.dispatchEvent(new CustomEvent(r, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: n
                    }))
                }
                b($, "fire")
            },
            78603: (S, M, l) => {
                "use strict";
                var d = l(64463);
                (0, d.N7)(".js-override-utm-params", s => {
                    let e = s.getAttribute("href");
                    const i = document.location.search,
                        o = ["utm_campaign", "utm_medium", "utm_source"];
                    if (!(!e || !i))
                        for (const y of o) {
                            const g = new RegExp(`${y}=([^=&]*)`),
                                k = g.exec(i);
                            g.lastIndex = 0, !!k && (e = e.replace(g, `${y}=${k[1]}`), s.setAttribute("href", e))
                        }
                });
                var m = l(27749),
                    I = l(59753);
                const x = 20,
                    P = 200,
                    N = 75,
                    O = "row-is-visible";
                (0, d.N7)(".js-type-in, .js-type-in-item", s => {
                    (0, m.Gx)(s) || B(s)
                });
                const q = new IntersectionObserver(C, {
                    rootMargin: `-${m.Al}% 0% -${m.B2}% 0%`,
                    threshold: m.t6
                });
                (0, d.N7)(".js-type-in, .js-type-in-trigger", s => {
                    if ((0, m.Gx)(s)) {
                        (0, m.L)(s);
                        return
                    }
                    const e = (0, m.jG)(s);
                    if (e.isDefault) return q.observe(s);
                    new IntersectionObserver(C, {
                        rootMargin: `-${e.marginTop}% 0% -${e.marginBottom}% 0%`,
                        threshold: e.threshold
                    }).observe(s)
                });

                function C(s) {
                    for (const e of s)
                        if (e.isIntersecting ? a(e.target) : B(e.target), !!e.target.classList.contains("js-type-in-trigger"))
                            for (const i of e.target.querySelectorAll(".js-type-in-item, .js-build-number")) e.isIntersecting ? a(i) : B(i)
                }
                b(C, "setAnimationState");

                function R(s) {
                    const e = s.childNodes;
                    for (const o of e)
                        if (o.nodeName === "#text") {
                            const y = document.createElement("span");
                            y.textContent = o.textContent, o.replaceWith(y)
                        }
                    const i = s.querySelectorAll("*");
                    for (const o of i) o.classList.add("js-type-letters"), o.style.visibility = "hidden";
                    s.classList.remove("js-type-letters")
                }
                b(R, "targetChildNodes");

                function B(s) {
                    const e = s.querySelectorAll(".js-type-row, .js-type-letters");
                    for (const i of e) i.classList.contains("js-type-letters") && i.children.length > 0 ? R(i) : (i.style.visibility = "hidden", i.classList.remove(O));
                    s.classList.remove(m.$M)
                }
                b(B, "resetText");

                function a(s) {
                    if (s.classList.contains(m.$M)) return;
                    s.classList.add(m.$M);
                    const e = s.querySelectorAll(".js-type-row, .js-type-letters"),
                        i = Number(s.getAttribute("data-type-delay") || x),
                        o = Number(s.getAttribute("data-type-row-delay") || P);
                    s.classList.contains("js-build-number") ? setTimeout(() => E(s, 0, Number(s.textContent)), i) : setTimeout(() => L(s, e, 0, "", o), i)
                }
                b(a, "startTextAnimation");

                function p(s) {
                    B(s), a(s)
                }
                b(p, "restartTextAnimation");

                function L(s, e, i, o, y) {
                    if (i >= e.length) return;
                    const g = e[i];
                    if (!s.classList.contains(m.$M)) {
                        o !== "" && (g.textContent = o);
                        return
                    }
                    if (g.classList.contains("js-type-row")) {
                        const k = Number(g.getAttribute("data-type-row-delay") || y);
                        g.style.visibility = "visible", g.classList.add(O), i++, setTimeout(() => L(s, e, i, "", k), k);
                        return
                    } else g.style.visibility === "hidden" && g.textContent != null && (o = g.textContent, g.textContent = "", g.style.visibility = "visible", g.classList.add("animation-is-typing"));
                    g.textContent != null && o.length > g.textContent.length ? g.textContent = o.substr(0, g.textContent.length + 1) : (i++, i < e.length && g.classList.remove("animation-is-typing")), setTimeout(() => L(s, e, i, o, y), x)
                }
                b(L, "animateText");

                function E(s, e, i) {
                    if (i % 1 !== 0 ? (e += Math.max(.1, i / 20), e = Number(e.toFixed(1))) : (e += Math.max(1, Number(i / 35)), e = Number(e.toFixed(0))), e > i && (e = i), s.textContent = e.toString(), e >= i) return;
                    const o = Number(s.getAttribute("data-increment-speed") || N);
                    setTimeout(() => E(s, e, i), o)
                }
                b(E, "animateNumber"), (0, I.on)("click", ".js-type-restart", s => {
                    const e = s.currentTarget.closest(".js-type-in");
                    p(e)
                });
                const D = new IntersectionObserver(function(s) {
                    for (const e of s)
                        if (e.isIntersecting)
                            for (const i of document.querySelectorAll(".js-scrollnav-item")) i.classList.toggle("selected", i.getAttribute("href") === `#${e.target.id}`)
                }, {
                    root: null,
                    rootMargin: "0px",
                    threshold: .1
                });
                (0, d.N7)(".js-section", s => D.observe(s));
                var X = l(87891);
                class U extends HTMLElement {
                    constructor() {
                        super();
                        const e = this.getAttribute("data-slide-show-autoplay"),
                            i = this.getAttribute("data-threshold") || "0.2";
                        if (this.intervalTime = 6e3, this.bullets = this.querySelectorAll(".js-slide-show-bullet[aria-controls]"), this.gotos = this.querySelectorAll(".js-slide-show-goto[aria-controls]"), this.slideIds = [], this.interval = null, this.current = 0, this.currentSlideId = null, this.swipeArea = this.querySelector(".js-slide-show-swipe-area"), this.touchStartX = 0, this.touchEndX = 0, this.swipeLengthMod = 20, e && !(0, m.Gx)(this)) {
                            const o = parseInt(e, 10);
                            isNaN(o) || (this.intervalTime = o), new IntersectionObserver(g => {
                                for (const k of g) {
                                    const $ = k.target;
                                    k.isIntersecting ? $.play() : $.pause()
                                }
                            }, {
                                threshold: Number(i)
                            }).observe(this)
                        }
                        for (let o = 0; o < this.bullets.length; o++) {
                            const y = this.bullets[o],
                                g = y.getAttribute("aria-controls"),
                                k = y.getAttribute("aria-selected");
                            g && this.slideIds.push(g), k && (this.current = o, this.currentSlideId = g), y.addEventListener("click", this.bulletOnClick.bind(this))
                        }
                        for (let o = 0; o < this.gotos.length; o++) {
                            const y = this.gotos[o],
                                g = y.getAttribute("aria-controls");
                            this.currentSlideId === g && y.setAttribute("aria-selected", "true"), y.addEventListener("click", this.bulletOnClick.bind(this))
                        }
                        this.swipeArea && (this.swipeArea.addEventListener("touchstart", this.onTouchStart.bind(this), {
                            passive: !0
                        }), this.swipeArea.addEventListener("touchend", this.onTouchEnd.bind(this)))
                    }
                    onTouchStart(e) {
                        this.touchStartX = e.changedTouches[0].screenX
                    }
                    onTouchEnd(e) {
                        this.touchEndX = e.changedTouches[0].screenX, this.touchEndX < this.touchStartX - this.swipeLengthMod && (this.pause(), this.nextSlide()), this.touchEndX > this.touchStartX + this.swipeLengthMod && (this.pause(), this.prevSlide())
                    }
                    pause() {
                        this.interval && window.clearInterval(this.interval)
                    }
                    play() {
                        this.pause(), this.interval = window.setInterval(this.nextSlide.bind(this), this.intervalTime)
                    }
                    nextSlide() {
                        this.current++, this.current > this.slideIds.length - 1 && (this.current = 0), this.goToSlide(this.slideIds[this.current])
                    }
                    prevSlide() {
                        this.current--, this.current < 0 && (this.current = this.slideIds.length - 1), this.goToSlide(this.slideIds[this.current])
                    }
                    bulletOnClick(e) {
                        e.preventDefault();
                        const i = e.target,
                            o = i == null ? void 0 : i.getAttribute("aria-controls");
                        o && this.goToSlide(o), this.pause()
                    }
                    goToSlide(e) {
                        const i = this.querySelector(`.js-slide-show-slide[id="${e}"]`),
                            o = this.querySelector(`.js-slide-show-bullet[aria-controls="${e}"]`),
                            y = this.querySelectorAll(`.js-slide-show-goto[aria-controls="${e}"]`),
                            g = this.querySelector('.js-slide-show-slide:not([aria-hidden="true"])'),
                            k = this.querySelector('.js-slide-show-bullet[aria-selected="true"]'),
                            $ = this.querySelectorAll('.js-slide-show-goto[aria-selected="true"]');
                        g == null || g.setAttribute("aria-hidden", "true"), k == null || k.setAttribute("aria-selected", "false");
                        for (let t = 0; t < $.length; t++) $[t].setAttribute("aria-selected", "false");
                        i == null || i.removeAttribute("aria-hidden"), o == null || o.setAttribute("aria-selected", "true");
                        for (let t = 0; t < y.length; t++) y[t].setAttribute("aria-selected", "true")
                    }
                }
                b(U, "SlideShow"), window && "customElements" in window && !window.customElements.get("slide-show") && window.customElements.define("slide-show", U);
                var z = l(11080);
                (0, I.on)("click", ".sub-nav-mktg.on", s => {
                    const e = s.currentTarget;
                    e.querySelector(".sub-nav-mktg-wrapper").contains(s.target) || e.classList.remove("on")
                }), (0, I.on)("click", ".sub-nav-mktg.scrollnav.on .sub-nav-mktg-link", s => {
                    s.currentTarget.closest(".sub-nav-mktg").classList.remove("on")
                }), (0, I.on)("click", ".sub-nav-mktg:not(.on) .sub-nav-mktg-link", s => {
                    window.innerWidth >= 1280 || (s.preventDefault(), s.currentTarget.closest(".sub-nav-mktg").classList.add("on"))
                });

                function G(s, e = 0) {
                    const i = s.getBoundingClientRect(),
                        o = i.top - e,
                        y = i.bottom - window.innerHeight + e;
                    o < 0 ? window.scrollBy(0, o) : y > 0 && window.scrollBy(0, y)
                }
                b(G, "adjustViewport"), (0, I.on)("click", ".js-video-play, .js-video-close", function(s) {
                    const i = s.currentTarget.closest(".js-video-container"),
                        o = i.querySelector(".js-video-iframe");
                    i.tagName.toLowerCase() === "details" && i.addEventListener("details-dialog-close", function() {
                        o.removeAttribute("src"), window.setTimeout(function() {
                            i.classList.remove("is-expanded")
                        }, 10)
                    }), i.classList.contains("is-expanded") ? (o.removeAttribute("src"), i.classList.remove("is-expanded")) : (o.src = o.getAttribute("data-src") || "", i.classList.add("is-expanded")), G(o, 20)
                })
            },
            27749: (S, M, l) => {
                "use strict";
                l.d(M, {
                    $M: () => m,
                    Al: () => P,
                    B2: () => x,
                    Gx: () => C,
                    L: () => R,
                    jG: () => B,
                    t6: () => N
                });
                var d = l(64463);
                const m = "build-in-animate",
                    I = "build-in-reduced",
                    x = 30,
                    P = 0,
                    N = 0;
                (0, d.N7)(".js-build-in-trigger[data-build-in-stagger], .js-build-in-group[data-build-in-stagger]", a => {
                    const p = parseInt(a.getAttribute("data-build-in-stagger")),
                        L = a.querySelectorAll(".js-build-in-item");
                    for (let E = 0; E < L.length; E++) L[E].style.transitionDelay = `${E*p}ms`
                });
                const O = new IntersectionObserver(q, {
                    rootMargin: `-${P}% 0% -${x}% 0%`,
                    threshold: N
                });
                (0, d.N7)(".js-build-in-item[data-build-delay]", a => {
                    const p = Number(a.getAttribute("data-build-delay") || 0);
                    a instanceof HTMLElement && (a.style.transitionDelay = `${p}ms`)
                }), (0, d.N7)(".js-build-in, .js-build-in-trigger", a => {
                    if (C(a)) {
                        R(a);
                        return
                    }
                    const p = B(a);
                    if (p.isDefault) return O.observe(a);
                    new IntersectionObserver(q, {
                        rootMargin: `-${p.marginTop}% 0% -${p.marginBottom}% 0%`,
                        threshold: p.threshold
                    }).observe(a)
                });

                function q(a) {
                    for (const p of a)
                        if (p.target.classList.toggle(m, p.isIntersecting), !!p.target.classList.contains("js-build-in-trigger"))
                            for (const L of p.target.querySelectorAll(".js-build-in-item")) L.classList.toggle(m, p.isIntersecting)
                }
                b(q, "toggleAnimationClasses");

                function C(a) {
                    const p = window.matchMedia("(prefers-reduced-motion: reduce)"),
                        L = a.getAttribute("data-build-non-decorative") || "false";
                    return p.matches && L === "false"
                }
                b(C, "shouldReduceMotion");

                function R(a) {
                    a.classList.add(I), a.classList.add(m);
                    for (const p of a.querySelectorAll(".js-build-in-item, .js-type-in-item")) p.classList.add(I), p.classList.add(m)
                }
                b(R, "cancelAnimationsForElement");

                function B(a) {
                    const p = Number(a.getAttribute("data-build-margin-bottom") || x),
                        L = Number(a.getAttribute("data-build-margin-top") || P),
                        E = Number(a.getAttribute("data-build-threshold") || N);
                    return {
                        marginBottom: p,
                        marginTop: L,
                        threshold: E,
                        isDefault: p === x && L === P && E === N
                    }
                }
                b(B, "animationOptions"), (0, d.N7)(".js-viewport-aware-video", {
                    constructor: HTMLMediaElement,
                    add(a) {
                        if (a.addEventListener("click", () => {
                                a.classList.toggle("looping-paused-mktg", !a.paused), a.paused ? a.play() : a.pause()
                            }), C(a)) {
                            a.pause(), a.classList.add("looping-paused-mktg");
                            return
                        }
                        const p = a.getAttribute("data-threshold") || "0.2";
                        new IntersectionObserver(E => {
                            for (const D of E) D.isIntersecting ? a.play() : a.pause()
                        }, {
                            threshold: Number(p)
                        }).observe(a)
                    }
                })
            },
            87891: () => {
                class S extends HTMLElement {
                    constructor() {
                        super();
                        const l = this.getAttribute("src");
                        if (!l) return this;
                        this.defaultSkipStep = 10, this.playToggleButton = this.querySelector(".js-github-audio-play-toggle"), this.playToggleButtonLabel = this.querySelector("#play-toggle-label"), this.currentTimeLabel = this.querySelector(".js-github-audio-current-time"), this.totalTimeLabel = this.querySelector(".js-github-audio-total-time"), this.scrubber = this.querySelector(".js-github-audio-scrubber"), this.scrubberProgress = this.querySelector(".js-github-audio-scrubber-progress"), this.skipBackwardButton = this.querySelector(".js-github-audio-skip-backward"), this.skipForwardButton = this.querySelector(".js-github-audio-skip-forward"), this.requestedAnimationFrame = 0, this.ready = !1, this.audio = this.createAudioElement(l, this.onLoadedMetaData, null, this.onEnded)
                    }
                    createAudioElement(l, d, m, I) {
                        const x = new Audio;
                        return x.preload = "metadata", d && x.addEventListener("loadedmetadata", () => {
                            d.bind(this)()
                        }), I && x.addEventListener("ended", () => {
                            I.bind(this)()
                        }), m && x.addEventListener("canplay", () => {
                            m.bind(this)()
                        }), x.src = l, x
                    }
                    static zeroFormat(l) {
                        return l < 10 ? `0${l}` : `${l}`
                    }
                    static formatTime(l) {
                        const d = Math.floor(l / 60),
                            m = Math.floor(l % 60);
                        return `${this.zeroFormat(d)}:${this.zeroFormat(m)}`
                    }
                    setTotalTimeLabel(l) {
                        !this.totalTimeLabel || (this.totalTimeLabel.textContent = S.formatTime(l))
                    }
                    setCurrentTimeLabel(l) {
                        !this.currentTimeLabel || (this.currentTimeLabel.textContent = S.formatTime(l))
                    }
                    getTotalTimeLabel() {
                        return this.totalTimeLabel ? this.totalTimeLabel.textContent : ""
                    }
                    getCurrentTimeLabel() {
                        return this.currentTimeLabel ? this.currentTimeLabel.textContent : ""
                    }
                    updateScrubberAria() {
                        !this.scrubber || this.scrubber.setAttribute("aria-valuenow", this.scrubber.value)
                    }
                    calculatePercentagePostion(l, d) {
                        return l * 100 / d
                    }
                    setScrubberPosition(l) {
                        if (!this.scrubber || !this.scrubberProgress) return;
                        this.scrubber.value = `${Math.floor(l)}`;
                        const d = parseInt(this.scrubber.max);
                        this.scrubberProgress.style.width = `${this.calculatePercentagePostion(l,d)}%`, this.updateScrubberAria()
                    }
                    updateStateWhilePlaying() {
                        this.setCurrentTimeLabel(this.audio.currentTime), this.setScrubberPosition(this.audio.currentTime), this.requestedAnimationFrame = requestAnimationFrame(this.updateStateWhilePlaying.bind(this))
                    }
                    initScrubber() {
                        !this.scrubber || (this.scrubber.min = "0", this.scrubber.max = `${Math.floor(this.audio.duration)}`, this.scrubber.setAttribute("aria-valuemin", this.scrubber.min), this.scrubber.setAttribute("aria-valuemax", this.scrubber.max), this.scrubber.addEventListener("change", () => {
                            !this.scrubber || (this.audio.currentTime = parseInt(this.scrubber.value, 10), this.audio.paused || requestAnimationFrame(this.updateStateWhilePlaying.bind(this)))
                        }), this.scrubber.addEventListener("input", () => {
                            if (!this.scrubber || !this.scrubberProgress) return;
                            const l = parseInt(this.scrubber.value, 10),
                                d = parseInt(this.scrubber.max, 10);
                            this.setCurrentTimeLabel(l), this.scrubberProgress.style.width = `${this.calculatePercentagePostion(l,d)}%`, this.updateScrubberAria(), this.audio.paused || cancelAnimationFrame(this.requestedAnimationFrame)
                        }), this.scrubber.addEventListener("keyup", l => {
                            l.code === "Space" && this.togglePlay()
                        }))
                    }
                    play() {
                        this.audio.play(), this.playToggleButtonLabel && (this.playToggleButtonLabel.textContent = this.playToggleButtonLabel.getAttribute("data-label-pause")), this.playToggleButton && this.playToggleButton.setAttribute("data-play-state", "playing"), requestAnimationFrame(this.updateStateWhilePlaying.bind(this))
                    }
                    pause() {
                        this.audio.pause(), this.playToggleButtonLabel && (this.playToggleButtonLabel.textContent = this.playToggleButtonLabel.getAttribute("data-label-play")), this.playToggleButton && this.playToggleButton.setAttribute("data-play-state", "paused"), cancelAnimationFrame(this.requestedAnimationFrame)
                    }
                    stop() {
                        this.pause(), this.audio.currentTime = 0, this.setScrubberPosition(0)
                    }
                    togglePlay() {
                        if (this.audio.paused) {
                            this.play();
                            return
                        }
                        this.pause()
                    }
                    skipForward(l) {
                        l = l || this.defaultSkipStep, this.audio.currentTime = this.audio.currentTime + l, this.audio.paused && (this.setCurrentTimeLabel(this.audio.currentTime), this.setScrubberPosition(this.audio.currentTime))
                    }
                    skipBackward(l) {
                        l = l || this.defaultSkipStep, this.audio.currentTime = this.audio.currentTime - l, this.audio.paused && (this.setCurrentTimeLabel(this.audio.currentTime), this.setScrubberPosition(this.audio.currentTime))
                    }
                    onLoadedMetaData() {
                        this.setTotalTimeLabel(this.audio.duration), this.initScrubber(), this.onCanPlay()
                    }
                    onEnded() {
                        this.pause()
                    }
                    onCanPlay() {
                        this.ready || (this.playToggleButton && (this.playToggleButton.addEventListener("click", this.togglePlay.bind(this)), this.playToggleButton.removeAttribute("disabled")), this.skipForwardButton && (this.skipForwardButton.addEventListener("click", () => {
                            this.skipForward()
                        }), this.skipForwardButton.removeAttribute("disabled")), this.skipBackwardButton && (this.skipBackwardButton.addEventListener("click", () => {
                            this.skipBackward()
                        }), this.skipBackwardButton.removeAttribute("disabled")), this.scrubber && this.scrubber.removeAttribute("disabled"), this.ready = !0)
                    }
                }
                b(S, "GitHubAudio"), window && "customElements" in window && !window.customElements.get("github-audio") && window.customElements.define("github-audio", S)
            },
            11080: () => {
                if (window.location.hash) {
                    const S = document.querySelector(`.faq-mktg-item${window.location.hash} details`);
                    S && (S.open = !0)
                }
            }
        },
        S => {
            var M = b(d => S(S.s = d), "__webpack_exec__");
            S.O(0, [5724], () => M(78603));
            var l = S.O()
        }
    ]);
})();

//# sourceMappingURL=marketing-b403d7950514.js.map