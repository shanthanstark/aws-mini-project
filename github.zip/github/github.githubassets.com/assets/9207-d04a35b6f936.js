"use strict";
(() => {
    var dt = Object.defineProperty;
    var c = (j, P) => dt(j, "name", {
        value: P,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [9207], {
            76745: (j, P, I) => {
                I.d(P, {
                    Z: () => v
                });

                function x(d) {
                    const t = document.createElement("pre");
                    return t.style.width = "1px", t.style.height = "1px", t.style.position = "fixed", t.style.top = "5px", t.textContent = d, t
                }
                c(x, "createNode");

                function _(d) {
                    if ("clipboard" in navigator) return navigator.clipboard.writeText(d.textContent);
                    const t = getSelection();
                    if (t == null) return Promise.reject(new Error);
                    t.removeAllRanges();
                    const n = document.createRange();
                    return n.selectNodeContents(d), t.addRange(n), document.execCommand("copy"), t.removeAllRanges(), Promise.resolve()
                }
                c(_, "copyNode");

                function W(d) {
                    if ("clipboard" in navigator) return navigator.clipboard.writeText(d);
                    const t = document.body;
                    if (!t) return Promise.reject(new Error);
                    const n = x(d);
                    return t.appendChild(n), _(n), t.removeChild(n), Promise.resolve()
                }
                c(W, "copyText");

                function S(d) {
                    const t = d.getAttribute("for"),
                        n = d.getAttribute("value");

                    function a() {
                        d.dispatchEvent(new CustomEvent("clipboard-copy", {
                            bubbles: !0
                        }))
                    }
                    if (c(a, "trigger"), n) W(n).then(a);
                    else if (t) {
                        const h = "getRootNode" in Element.prototype ? d.getRootNode() : d.ownerDocument;
                        if (!(h instanceof Document || "ShadowRoot" in window && h instanceof ShadowRoot)) return;
                        const g = h.getElementById(t);
                        g && B(g).then(a)
                    }
                }
                c(S, "copy");

                function B(d) {
                    return d instanceof HTMLInputElement || d instanceof HTMLTextAreaElement ? W(d.value) : d instanceof HTMLAnchorElement && d.hasAttribute("href") ? W(d.href) : _(d)
                }
                c(B, "copyTarget");

                function H(d) {
                    const t = d.currentTarget;
                    t instanceof HTMLElement && S(t)
                }
                c(H, "clicked");

                function M(d) {
                    if (d.key === " " || d.key === "Enter") {
                        const t = d.currentTarget;
                        t instanceof HTMLElement && (d.preventDefault(), S(t))
                    }
                }
                c(M, "keydown");

                function R(d) {
                    d.currentTarget.addEventListener("keydown", M)
                }
                c(R, "focused");

                function k(d) {
                    d.currentTarget.removeEventListener("keydown", M)
                }
                c(k, "blurred");
                class m extends HTMLElement {
                    constructor() {
                        super();
                        this.addEventListener("click", H), this.addEventListener("focus", R), this.addEventListener("blur", k)
                    }
                    connectedCallback() {
                        this.hasAttribute("tabindex") || this.setAttribute("tabindex", "0"), this.hasAttribute("role") || this.setAttribute("role", "button")
                    }
                    get value() {
                        return this.getAttribute("value") || ""
                    }
                    set value(t) {
                        this.setAttribute("value", t)
                    }
                }
                c(m, "ClipboardCopyElement"), window.customElements.get("clipboard-copy") || (window.ClipboardCopyElement = m, window.customElements.define("clipboard-copy", m));
                const v = m
            },
            57260: (j, P, I) => {
                I.d(P, {
                    P: () => x
                });
                class x {
                    constructor(i, f) {
                        this.file = i, this.directory = f, this.state = "pending", this.id = null, this.href = null, this.name = null, this.percent = 0
                    }
                    static traverse(i, f) {
                        return _(i, f)
                    }
                    static from(i) {
                        const f = [];
                        for (const E of i)
                            if (E instanceof File) f.push(new x(E));
                            else if (E instanceof x) f.push(E);
                        else throw new Error("Unexpected type");
                        return f
                    }
                    get fullPath() {
                        return this.directory ? `${this.directory}/${this.file.name}` : this.file.name
                    }
                    isImage() {
                        return ["image/gif", "image/png", "image/jpg", "image/jpeg", "image/svg+xml"].indexOf(this.file.type) > -1
                    }
                    isVideo() {
                        return ["video/mp4", "video/quicktime"].indexOf(this.file.type) > -1
                    }
                    saving(i) {
                        if (this.state !== "pending" && this.state !== "saving") throw new Error(`Unexpected transition from ${this.state} to saving`);
                        this.state = "saving", this.percent = i
                    }
                    saved(i) {
                        var f, E, L;
                        if (this.state !== "pending" && this.state !== "saving") throw new Error(`Unexpected transition from ${this.state} to saved`);
                        this.state = "saved", this.id = (f = i == null ? void 0 : i.id) !== null && f !== void 0 ? f : null, this.href = (E = i == null ? void 0 : i.href) !== null && E !== void 0 ? E : null, this.name = (L = i == null ? void 0 : i.name) !== null && L !== void 0 ? L : null
                    }
                    isPending() {
                        return this.state === "pending"
                    }
                    isSaving() {
                        return this.state === "saving"
                    }
                    isSaved() {
                        return this.state === "saved"
                    }
                }
                c(x, "Attachment");

                function _(s, i) {
                    return i && R(s) ? M("", k(s)) : Promise.resolve(S(Array.from(s.files || [])).map(f => new x(f)))
                }
                c(_, "transferredFiles");

                function W(s) {
                    return s.name.startsWith(".")
                }
                c(W, "hidden");

                function S(s) {
                    return Array.from(s).filter(i => !W(i))
                }
                c(S, "visible");

                function B(s) {
                    return new Promise(function(i, f) {
                        s.file(i, f)
                    })
                }
                c(B, "getFile");

                function H(s) {
                    return new Promise(function(i, f) {
                        const E = [],
                            L = s.createReader(),
                            O = c(() => {
                                L.readEntries(U => {
                                    U.length > 0 ? (E.push(...U), O()) : i(E)
                                }, f)
                            }, "read");
                        O()
                    })
                }
                c(H, "getEntries");
                async function M(s, i) {
                    const f = [];
                    for (const E of S(i))
                        if (E.isDirectory) f.push(...await M(E.fullPath, await H(E)));
                        else {
                            const L = await B(E);
                            f.push(new x(L, s))
                        }
                    return f
                }
                c(M, "traverse");

                function R(s) {
                    return s.items && Array.from(s.items).some(i => {
                        const f = i.webkitGetAsEntry && i.webkitGetAsEntry();
                        return f && f.isDirectory
                    })
                }
                c(R, "isDirectory");

                function k(s) {
                    return Array.from(s.items).map(i => i.webkitGetAsEntry()).filter(i => i != null)
                }
                c(k, "roots");
                class m extends HTMLElement {
                    connectedCallback() {
                        this.addEventListener("dragenter", t), this.addEventListener("dragover", t), this.addEventListener("dragleave", n), this.addEventListener("drop", a), this.addEventListener("paste", y), this.addEventListener("change", T)
                    }
                    disconnectedCallback() {
                        this.removeEventListener("dragenter", t), this.removeEventListener("dragover", t), this.removeEventListener("dragleave", n), this.removeEventListener("drop", a), this.removeEventListener("paste", y), this.removeEventListener("change", T)
                    }
                    get directory() {
                        return this.hasAttribute("directory")
                    }
                    set directory(i) {
                        i ? this.setAttribute("directory", "") : this.removeAttribute("directory")
                    }
                    async attach(i) {
                        const f = i instanceof DataTransfer ? await x.traverse(i, this.directory) : x.from(i);
                        this.dispatchEvent(new CustomEvent("file-attachment-accept", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                attachments: f
                            }
                        })) && f.length && this.dispatchEvent(new CustomEvent("file-attachment-accepted", {
                            bubbles: !0,
                            detail: {
                                attachments: f
                            }
                        }))
                    }
                }
                c(m, "FileAttachmentElement");

                function v(s) {
                    return Array.from(s.types).indexOf("Files") >= 0
                }
                c(v, "hasFile");
                let d = null;

                function t(s) {
                    const i = s.currentTarget;
                    d && clearTimeout(d), d = window.setTimeout(() => i.removeAttribute("hover"), 200);
                    const f = s.dataTransfer;
                    !f || !v(f) || (f.dropEffect = "copy", i.setAttribute("hover", ""), s.preventDefault())
                }
                c(t, "onDragenter");

                function n(s) {
                    s.dataTransfer && (s.dataTransfer.dropEffect = "none"), s.currentTarget.removeAttribute("hover"), s.stopPropagation(), s.preventDefault()
                }
                c(n, "onDragleave");

                function a(s) {
                    const i = s.currentTarget;
                    if (!(i instanceof m)) return;
                    i.removeAttribute("hover");
                    const f = s.dataTransfer;
                    !f || !v(f) || (i.attach(f), s.stopPropagation(), s.preventDefault())
                }
                c(a, "onDrop");
                const h = /^image\/(gif|png|jpeg)$/;

                function g(s) {
                    for (const i of s)
                        if (i.kind === "file" && h.test(i.type)) return i.getAsFile();
                    return null
                }
                c(g, "pastedFile");

                function y(s) {
                    if (!s.clipboardData || !s.clipboardData.items) return;
                    const i = s.currentTarget;
                    if (!(i instanceof m)) return;
                    const f = g(s.clipboardData.items);
                    if (!f) return;
                    const E = [f];
                    i.attach(E), s.preventDefault()
                }
                c(y, "onPaste");

                function T(s) {
                    const i = s.currentTarget;
                    if (!(i instanceof m)) return;
                    const f = s.target;
                    if (!(f instanceof HTMLInputElement)) return;
                    const E = i.getAttribute("input");
                    if (E && f.id !== E) return;
                    const L = f.files;
                    !L || L.length === 0 || (i.attach(L), f.value = "")
                }
                c(T, "onChange"), window.customElements.get("file-attachment") || (window.FileAttachmentElement = m, window.customElements.define("file-attachment", m));
                var u = null
            },
            48030: (j, P, I) => {
                I.d(P, {
                    N: () => W
                });
                const x = {
                        "outside-top": ["outside-bottom", "outside-right", "outside-left", "outside-bottom"],
                        "outside-bottom": ["outside-top", "outside-right", "outside-left", "outside-bottom"],
                        "outside-left": ["outside-right", "outside-bottom", "outside-top", "outside-bottom"],
                        "outside-right": ["outside-left", "outside-bottom", "outside-top", "outside-bottom"]
                    },
                    _ = {
                        start: ["end", "center"],
                        end: ["start", "center"],
                        center: ["end", "start"]
                    };

                function W(d, t, n = {}) {
                    const a = S(d),
                        h = B(a),
                        g = getComputedStyle(a),
                        y = a.getBoundingClientRect(),
                        [T, u] = [g.borderTopWidth, g.borderLeftWidth].map(i => parseInt(i, 10) || 0),
                        s = {
                            top: y.top + T,
                            left: y.left + u
                        };
                    return R(h, s, d.getBoundingClientRect(), t instanceof Element ? t.getBoundingClientRect() : t, M(n))
                }
                c(W, "getAnchoredPosition");

                function S(d) {
                    let t = d.parentNode;
                    for (; t !== null;) {
                        if (t instanceof HTMLElement && getComputedStyle(t).position !== "static") return t;
                        t = t.parentNode
                    }
                    return document.body
                }
                c(S, "getPositionedParent");

                function B(d) {
                    let t = d;
                    for (; t !== null && !(t === document.body || getComputedStyle(t).overflow !== "visible");) t = t.parentNode;
                    const n = t === document.body || !(t instanceof HTMLElement) ? document.body : t,
                        a = n.getBoundingClientRect(),
                        h = getComputedStyle(n),
                        [g, y, T, u] = [h.borderTopWidth, h.borderLeftWidth, h.borderRightWidth, h.borderBottomWidth].map(s => parseInt(s, 10) || 0);
                    return {
                        top: a.top + g,
                        left: a.left + y,
                        width: a.width - T - y,
                        height: Math.max(a.height - g - u, n === document.body ? window.innerHeight : -1 / 0)
                    }
                }
                c(B, "getClippingRect");
                const H = {
                    side: "outside-bottom",
                    align: "start",
                    anchorOffset: 4,
                    alignmentOffset: 4,
                    allowOutOfBounds: !1
                };

                function M(d = {}) {
                    var t, n, a, h, g;
                    const y = (t = d.side) !== null && t !== void 0 ? t : H.side,
                        T = (n = d.align) !== null && n !== void 0 ? n : H.align;
                    return {
                        side: y,
                        align: T,
                        anchorOffset: (a = d.anchorOffset) !== null && a !== void 0 ? a : y === "inside-center" ? 0 : H.anchorOffset,
                        alignmentOffset: (h = d.alignmentOffset) !== null && h !== void 0 ? h : T !== "center" && y.startsWith("inside") ? H.alignmentOffset : 0,
                        allowOutOfBounds: (g = d.allowOutOfBounds) !== null && g !== void 0 ? g : H.allowOutOfBounds
                    }
                }
                c(M, "getDefaultSettings");

                function R(d, t, n, a, {
                    side: h,
                    align: g,
                    allowOutOfBounds: y,
                    anchorOffset: T,
                    alignmentOffset: u
                }) {
                    const s = {
                        top: d.top - t.top,
                        left: d.left - t.left,
                        width: d.width,
                        height: d.height
                    };
                    let i = k(n, a, h, g, T, u),
                        f = h,
                        E = g;
                    if (i.top -= t.top, i.left -= t.left, !y) {
                        const L = x[h];
                        let O = 0;
                        if (L) {
                            let K = h;
                            for (; O < L.length && m(K, i, s, n);) {
                                const D = L[O++];
                                K = D, i = k(n, a, D, g, T, u), i.top -= t.top, i.left -= t.left, f = D
                            }
                        }
                        const U = _[g];
                        let G = 0;
                        if (U) {
                            let K = g;
                            for (; G < U.length && v(K, i, s, n);) {
                                const D = U[G++];
                                K = D, i = k(n, a, f, D, T, u), i.top -= t.top, i.left -= t.left, E = D
                            }
                        }
                        i.top < s.top && (i.top = s.top), i.left < s.left && (i.left = s.left), i.left + n.width > d.width + s.left && (i.left = d.width + s.left - n.width), L && O < L.length && i.top + n.height > d.height + s.top && (i.top = d.height + s.top - n.height)
                    }
                    return Object.assign(Object.assign({}, i), {
                        anchorSide: f,
                        anchorAlign: E
                    })
                }
                c(R, "pureCalculateAnchoredPosition");

                function k(d, t, n, a, h, g) {
                    const y = t.left + t.width,
                        T = t.top + t.height;
                    let u = -1,
                        s = -1;
                    return n === "outside-top" ? u = t.top - h - d.height : n === "outside-bottom" ? u = T + h : n === "outside-left" ? s = t.left - h - d.width : n === "outside-right" && (s = y + h), (n === "outside-top" || n === "outside-bottom") && (a === "start" ? s = t.left + g : a === "center" ? s = t.left - (d.width - t.width) / 2 + g : s = y - d.width - g), (n === "outside-left" || n === "outside-right") && (a === "start" ? u = t.top + g : a === "center" ? u = t.top - (d.height - t.height) / 2 + g : u = T - d.height - g), n === "inside-top" ? u = t.top + h : n === "inside-bottom" ? u = T - h - d.height : n === "inside-left" ? s = t.left + h : n === "inside-right" ? s = y - h - d.width : n === "inside-center" && (s = (y + t.left) / 2 - d.width / 2 + h), n === "inside-top" || n === "inside-bottom" ? a === "start" ? s = t.left + g : a === "center" ? s = t.left - (d.width - t.width) / 2 + g : s = y - d.width - g : (n === "inside-left" || n === "inside-right" || n === "inside-center") && (a === "start" ? u = t.top + g : a === "center" ? u = t.top - (d.height - t.height) / 2 + g : u = T - d.height - g), {
                        top: u,
                        left: s
                    }
                }
                c(k, "calculatePosition");

                function m(d, t, n, a) {
                    return d === "outside-top" || d === "outside-bottom" ? t.top < n.top || t.top + a.height > n.height + n.top : t.left < n.left || t.left + a.width > n.width + n.left
                }
                c(m, "shouldRecalculatePosition");

                function v(d, t, n, a) {
                    if (d === "end") return t.left < n.left;
                    if (d === "start" || d === "center") return t.left + a.width > n.left + n.width || t.left < n.left
                }
                c(v, "shouldRecalculateAlignment")
            },
            71544: (j, P, I) => {
                var x = I(46481),
                    _ = I(76745);
                const W = 2e3;

                function S(o) {
                    o.style.display = "inline-block"
                }
                c(S, "showSVG");

                function B(o) {
                    o.style.display = "none"
                }
                c(B, "hideSVG");

                function H(o) {
                    const [e, r] = o.querySelectorAll(".octicon");
                    !e || !r || (S(e), B(r))
                }
                c(H, "showCopy");

                function M(o) {
                    const [e, r] = o.querySelectorAll(".octicon");
                    !e || !r || (B(e), S(r))
                }
                c(M, "showCheck");
                const R = new WeakMap;
                document.addEventListener("clipboard-copy", function({
                    target: o
                }) {
                    if (!(o instanceof HTMLElement) || !o.hasAttribute("data-view-component")) return;
                    const e = R.get(o);
                    e ? (clearTimeout(e), R.delete(o)) : M(o), R.set(o, setTimeout(() => {
                        H(o), R.delete(o)
                    }, W))
                });
                var k = I(29501),
                    m = I(75329);
                const v = new WeakMap,
                    d = new WeakMap,
                    t = new WeakMap;

                function n(o) {
                    const e = o.currentTarget;
                    if (!(e instanceof i)) return;
                    const {
                        box: r,
                        image: p
                    } = t.get(e) || {};
                    if (!r || !p) return;
                    let b = 0,
                        w = 0;
                    if (o instanceof KeyboardEvent) o.key === "ArrowUp" ? w = -1 : o.key === "ArrowDown" ? w = 1 : o.key === "ArrowLeft" ? b = -1 : o.key === "ArrowRight" && (b = 1);
                    else if (d.has(e) && o instanceof MouseEvent) {
                        const A = d.get(e);
                        b = o.pageX - A.dragStartX, w = o.pageY - A.dragStartY
                    } else if (d.has(e) && o instanceof TouchEvent) {
                        const {
                            pageX: A,
                            pageY: C
                        } = o.changedTouches[0], {
                            dragStartX: $,
                            dragStartY: N
                        } = d.get(e);
                        b = A - $, w = C - N
                    }
                    if (b !== 0 || w !== 0) {
                        const A = Math.min(Math.max(0, r.offsetLeft + b), p.width - r.offsetWidth),
                            C = Math.min(Math.max(0, r.offsetTop + w), p.height - r.offsetHeight);
                        r.style.left = `${A}px`, r.style.top = `${C}px`, s(e, {
                            x: A,
                            y: C,
                            width: r.offsetWidth,
                            height: r.offsetHeight
                        })
                    }
                    if (o instanceof MouseEvent) d.set(e, {
                        dragStartX: o.pageX,
                        dragStartY: o.pageY
                    });
                    else if (o instanceof TouchEvent) {
                        const {
                            pageX: A,
                            pageY: C
                        } = o.changedTouches[0];
                        d.set(e, {
                            dragStartX: A,
                            dragStartY: C
                        })
                    }
                }
                c(n, "moveCropArea");

                function a(o) {
                    const e = o.target;
                    if (!(e instanceof HTMLElement)) return;
                    const r = h(e);
                    if (!(r instanceof i)) return;
                    const {
                        box: p
                    } = t.get(r) || {};
                    if (!p) return;
                    const b = r.getBoundingClientRect();
                    let w, A, C;
                    if (o instanceof KeyboardEvent) {
                        if (o.key === "Escape") return T(r);
                        if (o.key === "-" && (C = -10), o.key === "=" && (C = 10), !C) return;
                        w = p.offsetWidth + C, A = p.offsetHeight + C, v.set(r, {
                            startX: p.offsetLeft,
                            startY: p.offsetTop
                        })
                    } else if (o instanceof MouseEvent) {
                        const $ = v.get(r);
                        if (!$) return;
                        w = o.pageX - $.startX - b.left - window.pageXOffset, A = o.pageY - $.startY - b.top - window.pageYOffset
                    } else if (o instanceof TouchEvent) {
                        const $ = v.get(r);
                        if (!$) return;
                        w = o.changedTouches[0].pageX - $.startX - b.left - window.pageXOffset, A = o.changedTouches[0].pageY - $.startY - b.top - window.pageYOffset
                    }
                    w && A && y(r, w, A, !(o instanceof KeyboardEvent))
                }
                c(a, "updateCropArea");

                function h(o) {
                    const e = o.getRootNode();
                    return e instanceof ShadowRoot ? e.host : o
                }
                c(h, "getShadowHost");

                function g(o) {
                    const e = o.currentTarget;
                    if (!(e instanceof HTMLElement)) return;
                    const r = h(e);
                    if (!(r instanceof i)) return;
                    const {
                        box: p
                    } = t.get(r) || {};
                    if (!p) return;
                    const b = o.target;
                    if (b instanceof HTMLElement)
                        if (b.hasAttribute("data-direction")) {
                            const w = b.getAttribute("data-direction") || "";
                            r.addEventListener("mousemove", a), r.addEventListener("touchmove", a, {
                                passive: !0
                            }), ["nw", "se"].indexOf(w) >= 0 && r.classList.add("nwse"), ["ne", "sw"].indexOf(w) >= 0 && r.classList.add("nesw"), v.set(r, {
                                startX: p.offsetLeft + (["se", "ne"].indexOf(w) >= 0 ? 0 : p.offsetWidth),
                                startY: p.offsetTop + (["se", "sw"].indexOf(w) >= 0 ? 0 : p.offsetHeight)
                            }), a(o)
                        } else r.addEventListener("mousemove", n), r.addEventListener("touchmove", n, {
                            passive: !0
                        })
                }
                c(g, "startUpdate");

                function y(o, e, r, p = !0) {
                    let b = Math.max(Math.abs(e), Math.abs(r), 10);
                    const w = v.get(o);
                    if (!w) return;
                    const {
                        box: A,
                        image: C
                    } = t.get(o) || {};
                    if (!A || !C) return;
                    b = Math.min(b, r > 0 ? C.height - w.startY : w.startY, e > 0 ? C.width - w.startX : w.startX);
                    const $ = p ? Math.round(Math.max(0, e > 0 ? w.startX : w.startX - b)) : A.offsetLeft,
                        N = p ? Math.round(Math.max(0, r > 0 ? w.startY : w.startY - b)) : A.offsetTop;
                    A.style.left = `${$}px`, A.style.top = `${N}px`, A.style.width = `${b}px`, A.style.height = `${b}px`, s(o, {
                        x: $,
                        y: N,
                        width: b,
                        height: b
                    })
                }
                c(y, "updateDimensions");

                function T(o) {
                    const {
                        image: e
                    } = t.get(o) || {};
                    if (!e) return;
                    const r = Math.round(e.clientWidth > e.clientHeight ? e.clientHeight : e.clientWidth);
                    v.set(o, {
                        startX: (e.clientWidth - r) / 2,
                        startY: (e.clientHeight - r) / 2
                    }), y(o, r, r)
                }
                c(T, "setInitialPosition");

                function u(o) {
                    const e = o.currentTarget;
                    e instanceof i && (d.delete(e), e.classList.remove("nwse", "nesw"), e.removeEventListener("mousemove", a), e.removeEventListener("mousemove", n), e.removeEventListener("touchmove", a), e.removeEventListener("touchmove", n))
                }
                c(u, "stopUpdate");

                function s(o, e) {
                    const {
                        image: r
                    } = t.get(o) || {};
                    if (!r) return;
                    const p = r.naturalWidth / r.width;
                    for (const b in e) {
                        const w = Math.round(e[b] * p);
                        e[b] = w;
                        const A = o.querySelector(`[data-image-crop-input='${b}']`);
                        A instanceof HTMLInputElement && (A.value = w.toString())
                    }
                    o.dispatchEvent(new CustomEvent("image-crop-change", {
                        bubbles: !0,
                        detail: e
                    }))
                }
                c(s, "fireChangeEvent");
                class i extends HTMLElement {
                    connectedCallback() {
                        if (t.has(this)) return;
                        const e = this.attachShadow({
                            mode: "open"
                        });
                        e.innerHTML = `
<style>
  :host { touch-action: none; display: block; }
  :host(.nesw) { cursor: nesw-resize; }
  :host(.nwse) { cursor: nwse-resize; }
  :host(.nesw) .crop-box, :host(.nwse) .crop-box { cursor: inherit; }
  :host([loaded]) .crop-image { display: block; }
  :host([loaded]) ::slotted([data-loading-slot]), .crop-image { display: none; }

  .crop-wrapper {
    position: relative;
    font-size: 0;
  }
  .crop-container {
    user-select: none;
    -ms-user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
    position: absolute;
    overflow: hidden;
    z-index: 1;
    top: 0;
    width: 100%;
    height: 100%;
  }

  :host([rounded]) .crop-box {
    border-radius: 50%;
    box-shadow: 0 0 0 4000px rgba(0, 0, 0, 0.3);
  }
  .crop-box {
    position: absolute;
    border: 1px dashed #fff;
    box-sizing: border-box;
    cursor: move;
  }

  :host([rounded]) .crop-outline {
    outline: none;
  }
  .crop-outline {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    outline: 4000px solid rgba(0, 0, 0, .3);
  }

  .handle { position: absolute; }
  :host([rounded]) .handle::before { border-radius: 50%; }
  .handle:before {
    position: absolute;
    display: block;
    padding: 4px;
    transform: translate(-50%, -50%);
    content: ' ';
    background: #fff;
    border: 1px solid #767676;
  }
  .ne { top: 0; right: 0; cursor: nesw-resize; }
  .nw { top: 0; left: 0; cursor: nwse-resize; }
  .se { bottom: 0; right: 0; cursor: nwse-resize; }
  .sw { bottom: 0; left: 0; cursor: nesw-resize; }
</style>
<slot></slot>
<div class="crop-wrapper">
  <img width="100%" class="crop-image" alt="">
  <div class="crop-container">
    <div data-crop-box class="crop-box">
      <div class="crop-outline"></div>
      <div data-direction="nw" class="handle nw"></div>
      <div data-direction="ne" class="handle ne"></div>
      <div data-direction="sw" class="handle sw"></div>
      <div data-direction="se" class="handle se"></div>
    </div>
  </div>
</div>
`;
                        const r = e.querySelector("[data-crop-box]");
                        if (!(r instanceof HTMLElement)) return;
                        const p = e.querySelector("img");
                        p instanceof HTMLImageElement && (t.set(this, {
                            box: r,
                            image: p
                        }), p.addEventListener("load", () => {
                            this.loaded = !0, T(this)
                        }), this.addEventListener("mouseleave", u), this.addEventListener("touchend", u), this.addEventListener("mouseup", u), r.addEventListener("mousedown", g), r.addEventListener("touchstart", g, {
                            passive: !0
                        }), this.addEventListener("keydown", n), this.addEventListener("keydown", a), this.src && (p.src = this.src))
                    }
                    static get observedAttributes() {
                        return ["src"]
                    }
                    get src() {
                        return this.getAttribute("src")
                    }
                    set src(e) {
                        e ? this.setAttribute("src", e) : this.removeAttribute("src")
                    }
                    get loaded() {
                        return this.hasAttribute("loaded")
                    }
                    set loaded(e) {
                        e ? this.setAttribute("loaded", "") : this.removeAttribute("loaded")
                    }
                    attributeChangedCallback(e, r, p) {
                        const {
                            image: b
                        } = t.get(this) || {};
                        e === "src" && (this.loaded = !1, b && (b.src = p))
                    }
                }
                c(i, "ImageCropElement");
                const f = null;
                window.customElements.get("image-crop") || (window.ImageCropElement = i, window.customElements.define("image-crop", i));
                var E = I(11095),
                    L = I(48030),
                    O = function(o, e, r, p, b) {
                        if (p === "m") throw new TypeError("Private method is not writable");
                        if (p === "a" && !b) throw new TypeError("Private accessor was defined without a setter");
                        if (typeof e == "function" ? o !== e || !b : !e.has(o)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
                        return p === "a" ? b.call(o, r) : b ? b.value = r : e.set(o, r), r
                    },
                    U = function(o, e, r, p) {
                        if (r === "a" && !p) throw new TypeError("Private accessor was defined without a getter");
                        if (typeof e == "function" ? o !== e || !p : !e.has(o)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
                        return r === "m" ? p : r === "a" ? p.call(o) : p ? p.value : e.get(o)
                    },
                    G, K, D, z, et, Q, st;
                const nt = "tooltip-open",
                    it = 6,
                    lt = ["tooltip-n", "tooltip-s", "tooltip-e", "tooltip-w", "tooltip-ne", "tooltip-se", "tooltip-nw", "tooltip-sw"];
                class l extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        G.add(this), K.set(this, void 0), D.set(this, "center"), z.set(this, "outside-bottom"), et.set(this, !1)
                    }
                    styles() {
                        return `
      :host {
        position: absolute;
        z-index: 1000000;
        padding: .5em .75em;
        font: normal normal 11px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
        -webkit-font-smoothing: subpixel-antialiased;
        color: var(--color-fg-on-emphasis);
        text-align: center;
        text-decoration: none;
        text-shadow: none;
        text-transform: none;
        letter-spacing: normal;
        word-wrap: break-word;
        white-space: pre;
        background: var(--color-neutral-emphasis-plus);
        border-radius: 6px;
        opacity: 0;
        max-width: 250px;
        word-wrap: break-word;
        white-space: normal;
        width: max-content;
      }
      
      :host:before{
        position: absolute;
        z-index: 1000001;
        color: var(--color-neutral-emphasis-plus);
        content: "";
        border: 6px solid transparent;
        opacity: 0
      }
      
      @keyframes tooltip-appear {
        from {
          opacity: 0
        }
        to {
          opacity: 1
        }
      }
      
      :host:after{
        position: absolute;
        display: block;
        right: 0;
        left: 0;
        height: 12px;
        content: ""
      }
      
      :host(.${nt}),
      :host(.${nt}):before {
        animation-name: tooltip-appear;
        animation-duration: .1s;
        animation-fill-mode: forwards;
        animation-timing-function: ease-in;
        animation-delay: .4s
      }
      
      :host(.tooltip-s):before,
      :host(.tooltip-n):before {
        right: 50%;
        margin-right: -${it}px;
      }

      :host(.tooltip-s):before,
      :host(.tooltip-se):before,
      :host(.tooltip-sw):before {
        bottom: 100%;
        border-bottom-color: var(--color-neutral-emphasis-plus)
      }
      
      :host(.tooltip-s):after,
      :host(.tooltip-se):after,
      :host(.tooltip-sw):after {
        bottom: 100%
      }
      
      :host(.tooltip-n):before,
      :host(.tooltip-ne):before,
      :host(.tooltip-nw):before {
        top: 100%;
        border-top-color: var(--color-neutral-emphasis-plus)
      }
      
      :host(.tooltip-n):after,
      :host(.tooltip-ne):after,
      :host(.tooltip-nw):after {
        top: 100%
      }
      
      :host(.tooltip-se):before,
      :host(.tooltip-ne):before {
        left: 0;
        margin-left: ${it}px;
      }
      
      :host(.tooltip-sw):before,
      :host(.tooltip-nw):before {
        right: 0;
        margin-right: ${it}px;
      }
      
      :host(.tooltip-w):before {
        top: 50%;
        bottom: 50%;
        left: 100%;
        margin-top: -6px;
        border-left-color: var(--color-neutral-emphasis-plus)
      }
      
      :host(.tooltip-e):before {
        top: 50%;
        right: 100%;
        bottom: 50%;
        margin-top: -6px;
        border-right-color: var(--color-neutral-emphasis-plus)
      }
    `
                    }
                    get htmlFor() {
                        return this.getAttribute("for") || ""
                    }
                    set htmlFor(e) {
                        this.setAttribute("for", e)
                    }
                    get type() {
                        return this.getAttribute("data-type") === "label" ? "label" : "description"
                    }
                    set type(e) {
                        this.setAttribute("data-type", e)
                    }
                    get direction() {
                        return this.getAttribute("data-direction") || "s"
                    }
                    set direction(e) {
                        this.setAttribute("data-direction", e)
                    }
                    get control() {
                        return this.ownerDocument.getElementById(this.htmlFor)
                    }
                    connectedCallback() {
                        var e;
                        if (!this.shadowRoot) {
                            const p = this.attachShadow({
                                mode: "open"
                            });
                            p.innerHTML = `
        <style>
          ${this.styles()}
        </style>
        <slot></slot>
      `
                        }
                        if (this.hidden = !0, O(this, et, !0, "f"), this.id || (this.id = `tooltip-${Date.now()}-${(Math.random()*1e4).toFixed(0)}`), !this.control) return;
                        this.setAttribute("role", "tooltip"), (e = U(this, K, "f")) === null || e === void 0 || e.abort(), O(this, K, new AbortController, "f");
                        const {
                            signal: r
                        } = U(this, K, "f");
                        this.addEventListener("mouseleave", this, {
                            signal: r
                        }), this.control.addEventListener("mouseenter", this, {
                            signal: r
                        }), this.control.addEventListener("mouseleave", this, {
                            signal: r
                        }), this.control.addEventListener("focus", this, {
                            signal: r
                        }), this.control.addEventListener("blur", this, {
                            signal: r
                        }), this.ownerDocument.addEventListener("keydown", this, {
                            signal: r
                        }), U(this, G, "m", Q).call(this)
                    }
                    disconnectedCallback() {
                        var e;
                        (e = U(this, K, "f")) === null || e === void 0 || e.abort()
                    }
                    handleEvent(e) {
                        !this.control || ((e.type === "mouseenter" || e.type === "focus") && this.hidden ? this.hidden = !1 : e.type === "blur" ? this.hidden = !0 : e.type === "mouseleave" && e.relatedTarget !== this.control && e.relatedTarget !== this ? this.hidden = !0 : e.type === "keydown" && e.key === "Escape" && !this.hidden && (this.hidden = !0))
                    }
                    attributeChangedCallback(e) {
                        if (e === "id" || e === "data-type") {
                            if (!this.id || !this.control) return;
                            if (this.type === "label") this.control.setAttribute("aria-labelledby", this.id);
                            else {
                                let r = this.control.getAttribute("aria-describedby");
                                r ? r = `${r} ${this.id}` : r = this.id, this.control.setAttribute("aria-describedby", r)
                            }
                        } else if (this.isConnected && e === "hidden") U(this, G, "m", Q).call(this);
                        else if (e === "data-direction") {
                            this.classList.remove(...lt);
                            const r = this.direction;
                            r === "n" ? (O(this, D, "center", "f"), O(this, z, "outside-top", "f")) : r === "ne" ? (O(this, D, "start", "f"), O(this, z, "outside-top", "f")) : r === "e" ? (O(this, D, "center", "f"), O(this, z, "outside-right", "f")) : r === "se" ? (O(this, D, "start", "f"), O(this, z, "outside-bottom", "f")) : r === "s" ? (O(this, D, "center", "f"), O(this, z, "outside-bottom", "f")) : r === "sw" ? (O(this, D, "end", "f"), O(this, z, "outside-bottom", "f")) : r === "w" ? (O(this, D, "center", "f"), O(this, z, "outside-left", "f")) : r === "nw" && (O(this, D, "end", "f"), O(this, z, "outside-top", "f"))
                        }
                    }
                }
                c(l, "ToolTipElement"), K = new WeakMap, D = new WeakMap, z = new WeakMap, et = new WeakMap, G = new WeakSet, Q = c(function() {
                    if (this.hidden) this.classList.remove(nt, ...lt);
                    else {
                        this.classList.add(nt);
                        for (const e of this.ownerDocument.querySelectorAll(this.tagName)) e !== this && (e.hidden = !0);
                        U(this, G, "m", st).call(this)
                    }
                }, "_ToolTipElement_update"), st = c(function() {
                    if (!this.control || !U(this, et, "f") || this.hidden) return;
                    const e = 10;
                    this.style.left = "0px";
                    const r = (0, L.N)(this, this.control, {
                            side: U(this, z, "f"),
                            align: U(this, D, "f"),
                            anchorOffset: e
                        }),
                        p = r.anchorSide,
                        b = r.anchorAlign;
                    this.style.top = `${r.top}px`, this.style.left = `${r.left}px`;
                    let w = "s";
                    p === "outside-left" ? w = "w" : p === "outside-right" ? w = "e" : p === "outside-top" ? b === "center" ? w = "n" : b === "start" ? w = "ne" : w = "nw" : b === "center" ? w = "s" : b === "start" ? w = "se" : w = "sw", this.classList.add(`tooltip-${w}`)
                }, "_ToolTipElement_updatePosition"), l.observedAttributes = ["data-type", "data-direction", "id", "hidden"], window.customElements.get("tool-tip") || (window.ToolTipElement = l, window.customElements.define("tool-tip", l))
            },
            38257: () => {
                function j(k, m = 0, {
                    start: v = !0,
                    middle: d = !0,
                    once: t = !1
                } = {}) {
                    var n = 0,
                        a, h = !1,
                        g = c(function y(...T) {
                            if (!h) {
                                var u = Date.now() - n;
                                n = Date.now(), v ? (v = !1, k(...T), t && y.cancel()) : (d && u < m || !d) && (clearTimeout(a), a = setTimeout(function() {
                                    n = Date.now(), k(...T), t && y.cancel()
                                }, d ? m - u : m))
                            }
                        }, "fn");
                    return g.cancel = function() {
                        clearTimeout(a), h = !0
                    }, g
                }
                c(j, "throttle");

                function P(k, m = 0, {
                    start: v = !1,
                    middle: d = !1,
                    once: t = !1
                } = {}) {
                    return j(k, m, {
                        start: v,
                        middle: d,
                        once: t
                    })
                }
                c(P, "debounce");
                const I = new WeakMap;
                class x extends HTMLElement {
                    connectedCallback() {
                        const m = this.input;
                        if (!m) return;
                        const v = P(B.bind(null, this), 300),
                            d = {
                                check: v,
                                controller: null
                            };
                        I.set(this, d), m.addEventListener("input", _), m.addEventListener("input", v), m.autocomplete = "off", m.spellcheck = !1
                    }
                    disconnectedCallback() {
                        const m = this.input;
                        if (!m) return;
                        const v = I.get(this);
                        !v || (I.delete(this), m.removeEventListener("input", _), m.removeEventListener("input", v.check), m.setCustomValidity(""))
                    }
                    attributeChangedCallback(m) {
                        if (m === "required") {
                            const v = this.input;
                            if (!v) return;
                            v.required = this.required
                        }
                    }
                    static get observedAttributes() {
                        return ["required"]
                    }
                    get input() {
                        return this.querySelector("input")
                    }
                    get src() {
                        const m = this.getAttribute("src");
                        if (!m) return "";
                        const v = this.ownerDocument.createElement("a");
                        return v.href = m, v.href
                    }
                    set src(m) {
                        this.setAttribute("src", m)
                    }
                    get csrf() {
                        const m = this.querySelector("[data-csrf]");
                        return this.getAttribute("csrf") || m instanceof HTMLInputElement && m.value || ""
                    }
                    set csrf(m) {
                        this.setAttribute("csrf", m)
                    }
                    get required() {
                        return this.hasAttribute("required")
                    }
                    set required(m) {
                        m ? this.setAttribute("required", "") : this.removeAttribute("required")
                    }
                }
                c(x, "AutoCheckElement");

                function _(k) {
                    const m = k.currentTarget;
                    if (!(m instanceof HTMLInputElement)) return;
                    const v = m.closest("auto-check");
                    if (!(v instanceof x)) return;
                    const d = v.src,
                        t = v.csrf,
                        n = I.get(v);
                    if (!d || !t || !n) return;
                    let a = "Verifying\u2026";
                    const h = c(g => a = g, "setValidity");
                    m.dispatchEvent(new CustomEvent("auto-check-start", {
                        bubbles: !0,
                        detail: {
                            setValidity: h
                        }
                    })), v.required && m.setCustomValidity(a)
                }
                c(_, "setLoadingState");

                function W() {
                    return "AbortController" in window ? new AbortController : {
                        signal: null,
                        abort() {}
                    }
                }
                c(W, "makeAbortController");
                async function S(k, m, v) {
                    try {
                        const d = await fetch(m, v);
                        return k.dispatchEvent(new CustomEvent("load")), k.dispatchEvent(new CustomEvent("loadend")), d
                    } catch (d) {
                        throw d.name !== "AbortError" && (k.dispatchEvent(new CustomEvent("error")), k.dispatchEvent(new CustomEvent("loadend"))), d
                    }
                }
                c(S, "fetchWithNetworkEvents");
                async function B(k) {
                    const m = k.input;
                    if (!m) return;
                    const v = k.src,
                        d = k.csrf,
                        t = I.get(k);
                    if (!v || !d || !t) {
                        k.required && m.setCustomValidity("");
                        return
                    }
                    if (!m.value.trim()) {
                        k.required && m.setCustomValidity("");
                        return
                    }
                    const n = new FormData;
                    n.append("authenticity_token", d), n.append("value", m.value), m.dispatchEvent(new CustomEvent("auto-check-send", {
                        bubbles: !0,
                        detail: {
                            body: n
                        }
                    })), t.controller ? t.controller.abort() : k.dispatchEvent(new CustomEvent("loadstart")), t.controller = W();
                    try {
                        const a = await S(k, v, {
                            credentials: "same-origin",
                            signal: t.controller.signal,
                            method: "POST",
                            body: n
                        });
                        a.ok ? H(a, m, k.required) : M(a, m, k.required), t.controller = null, m.dispatchEvent(new CustomEvent("auto-check-complete", {
                            bubbles: !0
                        }))
                    } catch (a) {
                        a.name !== "AbortError" && (t.controller = null, m.dispatchEvent(new CustomEvent("auto-check-complete", {
                            bubbles: !0
                        })))
                    }
                }
                c(B, "check");

                function H(k, m, v) {
                    v && m.setCustomValidity(""), m.dispatchEvent(new CustomEvent("auto-check-success", {
                        bubbles: !0,
                        detail: {
                            response: k.clone()
                        }
                    }))
                }
                c(H, "processSuccess");

                function M(k, m, v) {
                    let d = "Validation failed";
                    const t = c(n => d = n, "setValidity");
                    m.dispatchEvent(new CustomEvent("auto-check-error", {
                        bubbles: !0,
                        detail: {
                            response: k.clone(),
                            setValidity: t
                        }
                    })), v && m.setCustomValidity(d)
                }
                c(M, "processFailure"), window.customElements.get("auto-check") || (window.AutoCheckElement = x, window.customElements.define("auto-check", x));
                var R = null
            },
            11095: () => {
                class j extends HTMLElement {
                    get preload() {
                        return this.hasAttribute("preload")
                    }
                    set preload(s) {
                        s ? this.setAttribute("preload", "") : this.removeAttribute("preload")
                    }
                    get src() {
                        return this.getAttribute("src") || ""
                    }
                    set src(s) {
                        this.setAttribute("src", s)
                    }
                    connectedCallback() {
                        this.hasAttribute("role") || this.setAttribute("role", "menu");
                        const s = this.parentElement;
                        if (!s) return;
                        const i = s.querySelector("summary");
                        i && (i.setAttribute("aria-haspopup", "menu"), i.hasAttribute("role") || i.setAttribute("role", "button"));
                        const f = [x(s, "compositionstart", E => y(this, E)), x(s, "compositionend", E => y(this, E)), x(s, "click", E => k(s, E)), x(s, "change", E => k(s, E)), x(s, "keydown", E => d(s, this, E)), x(s, "toggle", () => _(s, this), {
                            once: !0
                        }), x(s, "toggle", () => S(s)), this.preload ? x(s, "mouseover", () => _(s, this), {
                            once: !0
                        }) : I, ...W(s)];
                        P.set(this, {
                            subscriptions: f,
                            loaded: !1,
                            isComposing: !1
                        })
                    }
                    disconnectedCallback() {
                        const s = P.get(this);
                        if (!!s) {
                            P.delete(this);
                            for (const i of s.subscriptions) i.unsubscribe()
                        }
                    }
                }
                c(j, "DetailsMenuElement");
                const P = new WeakMap,
                    I = {
                        unsubscribe() {}
                    };

                function x(u, s, i, f = !1) {
                    return u.addEventListener(s, i, f), {
                        unsubscribe: () => {
                            u.removeEventListener(s, i, f)
                        }
                    }
                }
                c(x, "fromEvent");

                function _(u, s) {
                    const i = s.getAttribute("src");
                    if (!i) return;
                    const f = P.get(s);
                    if (!f || f.loaded) return;
                    f.loaded = !0;
                    const E = s.querySelector("include-fragment");
                    E && !E.hasAttribute("src") && (E.addEventListener("loadend", () => B(u)), E.setAttribute("src", i))
                }
                c(_, "loadFragment");

                function W(u) {
                    let s = !1;
                    const i = c(() => s = !0, "onmousedown"),
                        f = c(() => s = !1, "onkeydown"),
                        E = c(() => {
                            !u.hasAttribute("open") || B(u) || s || H(u)
                        }, "ontoggle");
                    return [x(u, "mousedown", i), x(u, "keydown", f), x(u, "toggle", E)]
                }
                c(W, "focusOnOpen");

                function S(u) {
                    if (!!u.hasAttribute("open"))
                        for (const s of document.querySelectorAll("details[open] > details-menu")) {
                            const i = s.closest("details");
                            i && i !== u && !i.contains(u) && i.removeAttribute("open")
                        }
                }
                c(S, "closeCurrentMenu");

                function B(u) {
                    if (!u.hasAttribute("open")) return !1;
                    const s = u.querySelector("details-menu [autofocus]");
                    return s ? (s.focus(), !0) : !1
                }
                c(B, "autofocus");

                function H(u) {
                    const s = document.activeElement;
                    if (s && t(s) && u.contains(s)) return;
                    const i = M(u, !0);
                    i && i.focus()
                }
                c(H, "focusFirstItem");

                function M(u, s) {
                    const i = Array.from(u.querySelectorAll('[role^="menuitem"]:not([hidden]):not([disabled]):not([aria-disabled="true"])')),
                        f = document.activeElement,
                        E = f instanceof HTMLElement ? i.indexOf(f) : -1,
                        L = s ? i[E + 1] : i[E - 1],
                        O = s ? i[0] : i[i.length - 1];
                    return L || O
                }
                c(M, "sibling");
                const R = navigator.userAgent.match(/Macintosh/);

                function k(u, s) {
                    const i = s.target;
                    if (i instanceof Element && i.closest("details") === u) {
                        if (s.type === "click") {
                            const f = i.closest('[role="menuitem"], [role="menuitemradio"]');
                            if (!f) return;
                            const E = f.querySelector("input");
                            if (f.tagName === "LABEL" && i === E) return;
                            f.tagName === "LABEL" && E && !E.checked || v(f, u)
                        } else if (s.type === "change") {
                            const f = i.closest('[role="menuitemradio"], [role="menuitemcheckbox"]');
                            f && v(f, u)
                        }
                    }
                }
                c(k, "shouldCommit");

                function m(u, s) {
                    for (const i of s.querySelectorAll('[role="menuitemradio"], [role="menuitemcheckbox"]')) {
                        const f = i.querySelector('input[type="radio"], input[type="checkbox"]');
                        let E = (i === u).toString();
                        f instanceof HTMLInputElement && (E = f.indeterminate ? "mixed" : f.checked.toString()), i.setAttribute("aria-checked", E)
                    }
                }
                c(m, "updateChecked");

                function v(u, s) {
                    if (u.hasAttribute("disabled") || u.getAttribute("aria-disabled") === "true") return;
                    const i = u.closest("details-menu");
                    !i || !i.dispatchEvent(new CustomEvent("details-menu-select", {
                        cancelable: !0,
                        detail: {
                            relatedTarget: u
                        }
                    })) || (a(u, s), m(u, s), u.getAttribute("role") !== "menuitemcheckbox" && n(s), i.dispatchEvent(new CustomEvent("details-menu-selected", {
                        detail: {
                            relatedTarget: u
                        }
                    })))
                }
                c(v, "commit");

                function d(u, s, i) {
                    if (!(i instanceof KeyboardEvent) || u.querySelector("details[open]")) return;
                    const f = P.get(s);
                    if (!f || f.isComposing) return;
                    const E = i.target instanceof Element && i.target.tagName === "SUMMARY";
                    switch (i.key) {
                        case "Escape":
                            u.hasAttribute("open") && (n(u), i.preventDefault(), i.stopPropagation());
                            break;
                        case "ArrowDown":
                            {
                                E && !u.hasAttribute("open") && u.setAttribute("open", "");
                                const L = M(u, !0);L && L.focus(),
                                i.preventDefault()
                            }
                            break;
                        case "ArrowUp":
                            {
                                E && !u.hasAttribute("open") && u.setAttribute("open", "");
                                const L = M(u, !1);L && L.focus(),
                                i.preventDefault()
                            }
                            break;
                        case "n":
                            if (R && i.ctrlKey) {
                                const L = M(u, !0);
                                L && L.focus(), i.preventDefault()
                            }
                            break;
                        case "p":
                            if (R && i.ctrlKey) {
                                const L = M(u, !1);
                                L && L.focus(), i.preventDefault()
                            }
                            break;
                        case " ":
                        case "Enter":
                            {
                                const L = document.activeElement;L instanceof HTMLElement && t(L) && L.closest("details") === u && (i.preventDefault(), i.stopPropagation(), L.click())
                            }
                            break
                    }
                }
                c(d, "keydown");

                function t(u) {
                    const s = u.getAttribute("role");
                    return s === "menuitem" || s === "menuitemcheckbox" || s === "menuitemradio"
                }
                c(t, "isMenuItem");

                function n(u) {
                    if (!u.hasAttribute("open")) return;
                    u.removeAttribute("open");
                    const i = u.querySelector("summary");
                    i && i.focus()
                }
                c(n, "close");

                function a(u, s) {
                    const i = s.querySelector("[data-menu-button]");
                    if (!i) return;
                    const f = h(u);
                    if (f) i.textContent = f;
                    else {
                        const E = g(u);
                        E && (i.innerHTML = E)
                    }
                }
                c(a, "updateLabel");

                function h(u) {
                    if (!u) return null;
                    const s = u.hasAttribute("data-menu-button-text") ? u : u.querySelector("[data-menu-button-text]");
                    return s ? s.getAttribute("data-menu-button-text") || s.textContent : null
                }
                c(h, "labelText");

                function g(u) {
                    if (!u) return null;
                    const s = u.hasAttribute("data-menu-button-contents") ? u : u.querySelector("[data-menu-button-contents]");
                    return s ? s.innerHTML : null
                }
                c(g, "labelHTML");

                function y(u, s) {
                    const i = P.get(u);
                    !i || (i.isComposing = s.type === "compositionstart")
                }
                c(y, "trackComposition");
                var T = null;
                window.customElements.get("details-menu") || (window.DetailsMenuElement = j, window.customElements.define("details-menu", j))
            },
            73921: () => {
                function j() {
                    const t = /\bWindows NT 6.1\b/.test(navigator.userAgent),
                        n = /\bWindows NT 6.2\b/.test(navigator.userAgent),
                        a = /\bWindows NT 6.3\b/.test(navigator.userAgent),
                        h = /\bFreeBSD\b/.test(navigator.userAgent),
                        g = /\bLinux\b/.test(navigator.userAgent) && !/\bAndroid\b/.test(navigator.userAgent);
                    return !(t || n || a || g || h)
                }
                c(j, "isEmojiSupported");
                const P = new Set(["\u{1F44B}", "\u{1F91A}", "\u{1F590}\uFE0F", "\u270B", "\u{1F596}", "\u{1F44C}", "\u{1F90F}", "\u270C\uFE0F", "\u{1F91E}", "\u{1F91F}", "\u{1F918}", "\u{1F919}", "\u{1F448}", "\u{1F449}", "\u{1F446}", "\u{1F595}", "\u{1F447}", "\u261D\uFE0F", "\u{1F44D}", "\u{1F44E}", "\u270A", "\u{1F44A}", "\u{1F91B}", "\u{1F91C}", "\u{1F44F}", "\u{1F64C}", "\u{1F450}", "\u{1F932}", "\u{1F64F}", "\u270D\uFE0F", "\u{1F485}", "\u{1F933}", "\u{1F4AA}", "\u{1F9B5}", "\u{1F9B6}", "\u{1F442}", "\u{1F9BB}", "\u{1F443}", "\u{1F476}", "\u{1F9D2}", "\u{1F466}", "\u{1F467}", "\u{1F9D1}", "\u{1F471}", "\u{1F468}", "\u{1F9D4}", "\u{1F471}\u200D\u2642\uFE0F", "\u{1F468}\u200D\u{1F9B0}", "\u{1F468}\u200D\u{1F9B1}", "\u{1F468}\u200D\u{1F9B3}", "\u{1F468}\u200D\u{1F9B2}", "\u{1F469}", "\u{1F471}\u200D\u2640\uFE0F", "\u{1F469}\u200D\u{1F9B0}", "\u{1F469}\u200D\u{1F9B1}", "\u{1F469}\u200D\u{1F9B3}", "\u{1F469}\u200D\u{1F9B2}", "\u{1F9D3}", "\u{1F474}", "\u{1F475}", "\u{1F64D}", "\u{1F64D}\u200D\u2642\uFE0F", "\u{1F64D}\u200D\u2640\uFE0F", "\u{1F64E}", "\u{1F64E}\u200D\u2642\uFE0F", "\u{1F64E}\u200D\u2640\uFE0F", "\u{1F645}", "\u{1F645}\u200D\u2642\uFE0F", "\u{1F645}\u200D\u2640\uFE0F", "\u{1F646}", "\u{1F646}\u200D\u2642\uFE0F", "\u{1F646}\u200D\u2640\uFE0F", "\u{1F481}", "\u{1F481}\u200D\u2642\uFE0F", "\u{1F481}\u200D\u2640\uFE0F", "\u{1F64B}", "\u{1F64B}\u200D\u2642\uFE0F", "\u{1F64B}\u200D\u2640\uFE0F", "\u{1F9CF}", "\u{1F9CF}\u200D\u2642\uFE0F", "\u{1F9CF}\u200D\u2640\uFE0F", "\u{1F647}", "\u{1F647}\u200D\u2642\uFE0F", "\u{1F647}\u200D\u2640\uFE0F", "\u{1F926}", "\u{1F926}\u200D\u2642\uFE0F", "\u{1F926}\u200D\u2640\uFE0F", "\u{1F937}", "\u{1F937}\u200D\u2642\uFE0F", "\u{1F937}\u200D\u2640\uFE0F", "\u{1F468}\u200D\u2695\uFE0F", "\u{1F469}\u200D\u2695\uFE0F", "\u{1F468}\u200D\u{1F393}", "\u{1F469}\u200D\u{1F393}", "\u{1F468}\u200D\u{1F3EB}", "\u{1F469}\u200D\u{1F3EB}", "\u{1F468}\u200D\u2696\uFE0F", "\u{1F469}\u200D\u2696\uFE0F", "\u{1F468}\u200D\u{1F33E}", "\u{1F469}\u200D\u{1F33E}", "\u{1F468}\u200D\u{1F373}", "\u{1F469}\u200D\u{1F373}", "\u{1F468}\u200D\u{1F527}", "\u{1F469}\u200D\u{1F527}", "\u{1F468}\u200D\u{1F3ED}", "\u{1F469}\u200D\u{1F3ED}", "\u{1F468}\u200D\u{1F4BC}", "\u{1F469}\u200D\u{1F4BC}", "\u{1F468}\u200D\u{1F52C}", "\u{1F469}\u200D\u{1F52C}", "\u{1F468}\u200D\u{1F4BB}", "\u{1F469}\u200D\u{1F4BB}", "\u{1F468}\u200D\u{1F3A4}", "\u{1F469}\u200D\u{1F3A4}", "\u{1F468}\u200D\u{1F3A8}", "\u{1F469}\u200D\u{1F3A8}", "\u{1F468}\u200D\u2708\uFE0F", "\u{1F469}\u200D\u2708\uFE0F", "\u{1F468}\u200D\u{1F680}", "\u{1F469}\u200D\u{1F680}", "\u{1F468}\u200D\u{1F692}", "\u{1F469}\u200D\u{1F692}", "\u{1F46E}", "\u{1F46E}\u200D\u2642\uFE0F", "\u{1F46E}\u200D\u2640\uFE0F", "\u{1F575}\uFE0F", "\u{1F575}\uFE0F\u200D\u2642\uFE0F", "\u{1F575}\uFE0F\u200D\u2640\uFE0F", "\u{1F482}", "\u{1F482}\u200D\u2642\uFE0F", "\u{1F482}\u200D\u2640\uFE0F", "\u{1F477}", "\u{1F477}\u200D\u2642\uFE0F", "\u{1F477}\u200D\u2640\uFE0F", "\u{1F934}", "\u{1F478}", "\u{1F473}", "\u{1F473}\u200D\u2642\uFE0F", "\u{1F473}\u200D\u2640\uFE0F", "\u{1F472}", "\u{1F9D5}", "\u{1F935}", "\u{1F470}", "\u{1F930}", "\u{1F931}", "\u{1F47C}", "\u{1F385}", "\u{1F936}", "\u{1F9B8}", "\u{1F9B8}\u200D\u2642\uFE0F", "\u{1F9B8}\u200D\u2640\uFE0F", "\u{1F9B9}", "\u{1F9B9}\u200D\u2642\uFE0F", "\u{1F9B9}\u200D\u2640\uFE0F", "\u{1F9D9}", "\u{1F9D9}\u200D\u2642\uFE0F", "\u{1F9D9}\u200D\u2640\uFE0F", "\u{1F9DA}", "\u{1F9DA}\u200D\u2642\uFE0F", "\u{1F9DA}\u200D\u2640\uFE0F", "\u{1F9DB}", "\u{1F9DB}\u200D\u2642\uFE0F", "\u{1F9DB}\u200D\u2640\uFE0F", "\u{1F9DC}", "\u{1F9DC}\u200D\u2642\uFE0F", "\u{1F9DC}\u200D\u2640\uFE0F", "\u{1F9DD}", "\u{1F9DD}\u200D\u2642\uFE0F", "\u{1F9DD}\u200D\u2640\uFE0F", "\u{1F486}", "\u{1F486}\u200D\u2642\uFE0F", "\u{1F486}\u200D\u2640\uFE0F", "\u{1F487}", "\u{1F487}\u200D\u2642\uFE0F", "\u{1F487}\u200D\u2640\uFE0F", "\u{1F6B6}", "\u{1F6B6}\u200D\u2642\uFE0F", "\u{1F6B6}\u200D\u2640\uFE0F", "\u{1F9CD}", "\u{1F9CD}\u200D\u2642\uFE0F", "\u{1F9CD}\u200D\u2640\uFE0F", "\u{1F9CE}", "\u{1F9CE}\u200D\u2642\uFE0F", "\u{1F9CE}\u200D\u2640\uFE0F", "\u{1F468}\u200D\u{1F9AF}", "\u{1F469}\u200D\u{1F9AF}", "\u{1F468}\u200D\u{1F9BC}", "\u{1F469}\u200D\u{1F9BC}", "\u{1F468}\u200D\u{1F9BD}", "\u{1F469}\u200D\u{1F9BD}", "\u{1F3C3}", "\u{1F3C3}\u200D\u2642\uFE0F", "\u{1F3C3}\u200D\u2640\uFE0F", "\u{1F483}", "\u{1F57A}", "\u{1F574}\uFE0F", "\u{1F9D6}", "\u{1F9D6}\u200D\u2642\uFE0F", "\u{1F9D6}\u200D\u2640\uFE0F", "\u{1F9D7}", "\u{1F9D7}\u200D\u2642\uFE0F", "\u{1F9D7}\u200D\u2640\uFE0F", "\u{1F3C7}", "\u{1F3C2}", "\u{1F3CC}\uFE0F", "\u{1F3CC}\uFE0F\u200D\u2642\uFE0F", "\u{1F3CC}\uFE0F\u200D\u2640\uFE0F", "\u{1F3C4}", "\u{1F3C4}\u200D\u2642\uFE0F", "\u{1F3C4}\u200D\u2640\uFE0F", "\u{1F6A3}", "\u{1F6A3}\u200D\u2642\uFE0F", "\u{1F6A3}\u200D\u2640\uFE0F", "\u{1F3CA}", "\u{1F3CA}\u200D\u2642\uFE0F", "\u{1F3CA}\u200D\u2640\uFE0F", "\u26F9\uFE0F", "\u26F9\uFE0F\u200D\u2642\uFE0F", "\u26F9\uFE0F\u200D\u2640\uFE0F", "\u{1F3CB}\uFE0F", "\u{1F3CB}\uFE0F\u200D\u2642\uFE0F", "\u{1F3CB}\uFE0F\u200D\u2640\uFE0F", "\u{1F6B4}", "\u{1F6B4}\u200D\u2642\uFE0F", "\u{1F6B4}\u200D\u2640\uFE0F", "\u{1F6B5}", "\u{1F6B5}\u200D\u2642\uFE0F", "\u{1F6B5}\u200D\u2640\uFE0F", "\u{1F938}", "\u{1F938}\u200D\u2642\uFE0F", "\u{1F938}\u200D\u2640\uFE0F", "\u{1F93D}", "\u{1F93D}\u200D\u2642\uFE0F", "\u{1F93D}\u200D\u2640\uFE0F", "\u{1F93E}", "\u{1F93E}\u200D\u2642\uFE0F", "\u{1F93E}\u200D\u2640\uFE0F", "\u{1F939}", "\u{1F939}\u200D\u2642\uFE0F", "\u{1F939}\u200D\u2640\uFE0F", "\u{1F9D8}", "\u{1F9D8}\u200D\u2642\uFE0F", "\u{1F9D8}\u200D\u2640\uFE0F", "\u{1F6C0}", "\u{1F6CC}", "\u{1F9D1}\u200D\u{1F91D}\u200D\u{1F9D1}", "\u{1F46D}", "\u{1F46B}", "\u{1F46C}"]);

                function I(t) {
                    return P.has(t)
                }
                c(I, "isModifiable");
                const x = "\u200D",
                    _ = 65039;

                function W(t, n) {
                    const a = B(t);
                    if (!I(a)) return t;
                    const h = R(n);
                    return h ? a.split(x).map(g => I(g) ? H(g, h) : g).join(x) : t
                }
                c(W, "applyTone");

                function S(t, n) {
                    const a = B(t);
                    if (!I(a)) return t;
                    const h = n.map(g => R(g));
                    return a.split(x).map(g => {
                        if (!I(g)) return g;
                        const y = h.shift();
                        return y ? H(g, y) : g
                    }).join(x)
                }
                c(S, "applyTones");

                function B(t) {
                    return [...t].filter(n => !M(n.codePointAt(0))).join("")
                }
                c(B, "removeTone");

                function H(t, n) {
                    const a = [...t].map(h => h.codePointAt(0));
                    return a[1] && (M(a[1]) || a[1] === _) ? a[1] = n : a.splice(1, 0, n), String.fromCodePoint(...a)
                }
                c(H, "tint");

                function M(t) {
                    return t >= 127995 && t <= 127999
                }
                c(M, "isTone");

                function R(t) {
                    switch (t) {
                        case 1:
                            return 127995;
                        case 2:
                            return 127996;
                        case 3:
                            return 127997;
                        case 4:
                            return 127998;
                        case 5:
                            return 127999;
                        default:
                            return null
                    }
                }
                c(R, "toneModifier");
                class k extends HTMLElement {
                    get image() {
                        return this.firstElementChild instanceof HTMLImageElement ? this.firstElementChild : null
                    }
                    get tone() {
                        return (this.getAttribute("tone") || "").split(" ").map(n => {
                            const a = parseInt(n, 10);
                            return a >= 0 && a <= 5 ? a : 0
                        }).join(" ")
                    }
                    set tone(n) {
                        this.setAttribute("tone", n)
                    }
                    connectedCallback() {
                        if (this.image === null && !j()) {
                            const n = this.getAttribute("fallback-src");
                            if (n) {
                                this.textContent = "";
                                const a = v(this);
                                a.src = n, this.appendChild(a)
                            }
                        }
                        this.hasAttribute("tone") && m(this)
                    }
                    static get observedAttributes() {
                        return ["tone"]
                    }
                    attributeChangedCallback(n) {
                        switch (n) {
                            case "tone":
                                m(this);
                                break
                        }
                    }
                }
                c(k, "GEmojiElement");

                function m(t) {
                    if (t.image) return;
                    const n = t.tone.split(" ").map(a => parseInt(a, 10));
                    if (n.length === 0) t.textContent = B(t.textContent || "");
                    else if (n.length === 1) {
                        const a = n[0];
                        t.textContent = a === 0 ? B(t.textContent || "") : W(t.textContent || "", a)
                    } else t.textContent = S(t.textContent || "", n)
                }
                c(m, "updateTone");

                function v(t) {
                    const n = document.createElement("img");
                    return n.className = "emoji", n.alt = t.getAttribute("alias") || "", n.height = 20, n.width = 20, n
                }
                c(v, "emojiImage"), window.customElements.get("g-emoji") || (window.GEmojiElement = k, window.customElements.define("g-emoji", k));
                var d = null
            },
            51941: () => {
                const j = ["[data-md-button]", "md-header", "md-bold", "md-italic", "md-quote", "md-code", "md-link", "md-image", "md-unordered-list", "md-ordered-list", "md-task-list", "md-mention", "md-ref", "md-strikethrough"];

                function P(l) {
                    const o = [];
                    for (const e of l.querySelectorAll(j.join(", "))) e.hidden || e.offsetWidth <= 0 && e.offsetHeight <= 0 || e.closest("markdown-toolbar") === l && o.push(e);
                    return o
                }
                c(P, "getButtons");

                function I(l) {
                    return function(o) {
                        (o.key === " " || o.key === "Enter") && (o.preventDefault(), l(o))
                    }
                }
                c(I, "keydown");
                const x = new WeakMap;
                class _ extends HTMLElement {
                    constructor() {
                        super();
                        const o = c(() => {
                            const e = x.get(this);
                            !e || it(this, e)
                        }, "apply");
                        this.addEventListener("keydown", I(o)), this.addEventListener("click", o)
                    }
                    connectedCallback() {
                        this.hasAttribute("role") || this.setAttribute("role", "button")
                    }
                    click() {
                        const o = x.get(this);
                        !o || it(this, o)
                    }
                }
                c(_, "MarkdownButtonElement");
                class W extends _ {
                    constructor() {
                        super();
                        const o = parseInt(this.getAttribute("level") || "3", 10);
                        if (o < 1 || o > 6) return;
                        const e = `${"#".repeat(o)} `;
                        x.set(this, {
                            prefix: e
                        })
                    }
                }
                c(W, "MarkdownHeaderButtonElement"), window.customElements.get("md-header") || (window.MarkdownHeaderButtonElement = W, window.customElements.define("md-header", W));
                class S extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "**",
                            suffix: "**",
                            trimFirst: !0
                        })
                    }
                }
                c(S, "MarkdownBoldButtonElement"), window.customElements.get("md-bold") || (window.MarkdownBoldButtonElement = S, window.customElements.define("md-bold", S));
                class B extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "_",
                            suffix: "_",
                            trimFirst: !0
                        })
                    }
                }
                c(B, "MarkdownItalicButtonElement"), window.customElements.get("md-italic") || (window.MarkdownItalicButtonElement = B, window.customElements.define("md-italic", B));
                class H extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "> ",
                            multiline: !0,
                            surroundWithNewlines: !0
                        })
                    }
                }
                c(H, "MarkdownQuoteButtonElement"), window.customElements.get("md-quote") || (window.MarkdownQuoteButtonElement = H, window.customElements.define("md-quote", H));
                class M extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "`",
                            suffix: "`",
                            blockPrefix: "```",
                            blockSuffix: "```"
                        })
                    }
                }
                c(M, "MarkdownCodeButtonElement"), window.customElements.get("md-code") || (window.MarkdownCodeButtonElement = M, window.customElements.define("md-code", M));
                class R extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "[",
                            suffix: "](url)",
                            replaceNext: "url",
                            scanFor: "https?://"
                        })
                    }
                }
                c(R, "MarkdownLinkButtonElement"), window.customElements.get("md-link") || (window.MarkdownLinkButtonElement = R, window.customElements.define("md-link", R));
                class k extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "![",
                            suffix: "](url)",
                            replaceNext: "url",
                            scanFor: "https?://"
                        })
                    }
                }
                c(k, "MarkdownImageButtonElement"), window.customElements.get("md-image") || (window.MarkdownImageButtonElement = k, window.customElements.define("md-image", k));
                class m extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "- ",
                            multiline: !0,
                            unorderedList: !0
                        })
                    }
                }
                c(m, "MarkdownUnorderedListButtonElement"), window.customElements.get("md-unordered-list") || (window.MarkdownUnorderedListButtonElement = m, window.customElements.define("md-unordered-list", m));
                class v extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "1. ",
                            multiline: !0,
                            orderedList: !0
                        })
                    }
                }
                c(v, "MarkdownOrderedListButtonElement"), window.customElements.get("md-ordered-list") || (window.MarkdownOrderedListButtonElement = v, window.customElements.define("md-ordered-list", v));
                class d extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "- [ ] ",
                            multiline: !0,
                            surroundWithNewlines: !0
                        })
                    }
                }
                c(d, "MarkdownTaskListButtonElement"), window.customElements.get("md-task-list") || (window.MarkdownTaskListButtonElement = d, window.customElements.define("md-task-list", d));
                class t extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "@",
                            prefixSpace: !0
                        })
                    }
                }
                c(t, "MarkdownMentionButtonElement"), window.customElements.get("md-mention") || (window.MarkdownMentionButtonElement = t, window.customElements.define("md-mention", t));
                class n extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "#",
                            prefixSpace: !0
                        })
                    }
                }
                c(n, "MarkdownRefButtonElement"), window.customElements.get("md-ref") || (window.MarkdownRefButtonElement = n, window.customElements.define("md-ref", n));
                class a extends _ {
                    constructor() {
                        super();
                        x.set(this, {
                            prefix: "~~",
                            suffix: "~~",
                            trimFirst: !0
                        })
                    }
                }
                c(a, "MarkdownStrikethroughButtonElement"), window.customElements.get("md-strikethrough") || (window.MarkdownStrikethroughButtonElement = a, window.customElements.define("md-strikethrough", a));
                class h extends HTMLElement {
                    constructor() {
                        super()
                    }
                    connectedCallback() {
                        this.hasAttribute("role") || this.setAttribute("role", "toolbar"), this.addEventListener("keydown", y), this.setAttribute("tabindex", "0"), this.addEventListener("focus", g, {
                            once: !0
                        })
                    }
                    disconnectedCallback() {
                        this.removeEventListener("keydown", y)
                    }
                    get field() {
                        const o = this.getAttribute("for");
                        if (!o) return null;
                        const e = "getRootNode" in this ? this.getRootNode() : document;
                        let r;
                        return (e instanceof Document || e instanceof ShadowRoot) && (r = e.getElementById(o)), r instanceof HTMLTextAreaElement ? r : null
                    }
                }
                c(h, "MarkdownToolbarElement");

                function g({
                    target: l
                }) {
                    if (!(l instanceof Element)) return;
                    l.removeAttribute("tabindex");
                    let o = "0";
                    for (const e of P(l)) e.setAttribute("tabindex", o), o === "0" && (e.focus(), o = "-1")
                }
                c(g, "onToolbarFocus");

                function y(l) {
                    const o = l.key;
                    if (o !== "ArrowRight" && o !== "ArrowLeft" && o !== "Home" && o !== "End") return;
                    const e = l.currentTarget;
                    if (!(e instanceof HTMLElement)) return;
                    const r = P(e),
                        p = r.indexOf(l.target),
                        b = r.length;
                    if (p === -1) return;
                    let w = 0;
                    o === "ArrowLeft" && (w = p - 1), o === "ArrowRight" && (w = p + 1), o === "End" && (w = b - 1), w < 0 && (w = b - 1), w > b - 1 && (w = 0);
                    for (let A = 0; A < b; A += 1) r[A].setAttribute("tabindex", A === w ? "0" : "-1");
                    l.preventDefault(), r[w].focus()
                }
                c(y, "focusKeydown"), window.customElements.get("markdown-toolbar") || (window.MarkdownToolbarElement = h, window.customElements.define("markdown-toolbar", h));

                function T(l) {
                    return l.trim().split(`
`).length > 1
                }
                c(T, "isMultipleLines");

                function u(l, o) {
                    return Array(o + 1).join(l)
                }
                c(u, "repeat");

                function s(l, o) {
                    let e = o;
                    for (; l[e] && l[e - 1] != null && !l[e - 1].match(/\s/);) e--;
                    return e
                }
                c(s, "wordSelectionStart");

                function i(l, o, e) {
                    let r = o;
                    const p = e ? /\n/ : /\s/;
                    for (; l[r] && !l[r].match(p);) r++;
                    return r
                }
                c(i, "wordSelectionEnd");
                let f = null;

                function E(l, {
                    text: o,
                    selectionStart: e,
                    selectionEnd: r
                }) {
                    const p = l.selectionStart,
                        b = l.value.slice(0, p),
                        w = l.value.slice(l.selectionEnd);
                    if (f === null || f === !0) {
                        l.contentEditable = "true";
                        try {
                            f = document.execCommand("insertText", !1, o)
                        } catch {
                            f = !1
                        }
                        l.contentEditable = "false"
                    }
                    if (f && !l.value.slice(0, l.selectionStart).endsWith(o) && (f = !1), !f) {
                        try {
                            document.execCommand("ms-beginUndoUnit")
                        } catch {}
                        l.value = b + o + w;
                        try {
                            document.execCommand("ms-endUndoUnit")
                        } catch {}
                        l.dispatchEvent(new CustomEvent("input", {
                            bubbles: !0,
                            cancelable: !0
                        }))
                    }
                    e != null && r != null ? l.setSelectionRange(e, r) : l.setSelectionRange(p, l.selectionEnd)
                }
                c(E, "insertText");

                function L(l, o) {
                    const e = l.value.slice(l.selectionStart, l.selectionEnd);
                    let r;
                    o.orderedList || o.unorderedList ? r = nt(l, o) : o.multiline && T(e) ? r = D(l, o) : r = K(l, o), E(l, r)
                }
                c(L, "styleSelectedText");

                function O(l) {
                    const o = l.value.split(`
`);
                    let e = 0;
                    for (let r = 0; r < o.length; r++) {
                        const p = o[r].length + 1;
                        l.selectionStart >= e && l.selectionStart < e + p && (l.selectionStart = e), l.selectionEnd >= e && l.selectionEnd < e + p && (l.selectionEnd = e + p - 1), e += p
                    }
                }
                c(O, "expandSelectionToLine");

                function U(l, o, e, r = !1) {
                    if (l.selectionStart === l.selectionEnd) l.selectionStart = s(l.value, l.selectionStart), l.selectionEnd = i(l.value, l.selectionEnd, r);
                    else {
                        const p = l.selectionStart - o.length,
                            b = l.selectionEnd + e.length,
                            w = l.value.slice(p, l.selectionStart) === o,
                            A = l.value.slice(l.selectionEnd, b) === e;
                        w && A && (l.selectionStart = p, l.selectionEnd = b)
                    }
                    return l.value.slice(l.selectionStart, l.selectionEnd)
                }
                c(U, "expandSelectedText");

                function G(l) {
                    const o = l.value.slice(0, l.selectionStart),
                        e = l.value.slice(l.selectionEnd),
                        r = o.match(/\n*$/),
                        p = e.match(/^\n*/),
                        b = r ? r[0].length : 0,
                        w = p ? p[0].length : 0;
                    let A, C;
                    return o.match(/\S/) && b < 2 && (A = u(`
`, 2 - b)), e.match(/\S/) && w < 2 && (C = u(`
`, 2 - w)), A == null && (A = ""), C == null && (C = ""), {
                        newlinesToAppend: A,
                        newlinesToPrepend: C
                    }
                }
                c(G, "newlinesToSurroundSelectedText");

                function K(l, o) {
                    let e, r;
                    const {
                        prefix: p,
                        suffix: b,
                        blockPrefix: w,
                        blockSuffix: A,
                        replaceNext: C,
                        prefixSpace: $,
                        scanFor: N,
                        surroundWithNewlines: ot
                    } = o, Z = l.selectionStart, rt = l.selectionEnd;
                    let X = l.value.slice(l.selectionStart, l.selectionEnd),
                        q = T(X) && w.length > 0 ? `${w}
` : p,
                        Y = T(X) && A.length > 0 ? `
${A}` : b;
                    if ($) {
                        const V = l.value[l.selectionStart - 1];
                        l.selectionStart !== 0 && V != null && !V.match(/\s/) && (q = ` ${q}`)
                    }
                    X = U(l, q, Y, o.multiline);
                    let F = l.selectionStart,
                        J = l.selectionEnd;
                    const ut = C.length > 0 && Y.indexOf(C) > -1 && X.length > 0;
                    if (ot) {
                        const V = G(l);
                        e = V.newlinesToAppend, r = V.newlinesToPrepend, q = e + p, Y += r
                    }
                    if (X.startsWith(q) && X.endsWith(Y)) {
                        const V = X.slice(q.length, X.length - Y.length);
                        if (Z === rt) {
                            let tt = Z - q.length;
                            tt = Math.max(tt, F), tt = Math.min(tt, F + V.length), F = J = tt
                        } else J = F + V.length;
                        return {
                            text: V,
                            selectionStart: F,
                            selectionEnd: J
                        }
                    } else if (ut)
                        if (N.length > 0 && X.match(N)) {
                            Y = Y.replace(C, X);
                            const V = q + Y;
                            return F = J = F + q.length, {
                                text: V,
                                selectionStart: F,
                                selectionEnd: J
                            }
                        } else {
                            const V = q + X + Y;
                            return F = F + q.length + X.length + Y.indexOf(C), J = F + C.length, {
                                text: V,
                                selectionStart: F,
                                selectionEnd: J
                            }
                        }
                    else {
                        let V = q + X + Y;
                        F = Z + q.length, J = rt + q.length;
                        const tt = X.match(/^\s*|\s*$/g);
                        if (o.trimFirst && tt) {
                            const ct = tt[0] || "",
                                at = tt[1] || "";
                            V = ct + q + X.trim() + Y + at, F += ct.length, J -= at.length
                        }
                        return {
                            text: V,
                            selectionStart: F,
                            selectionEnd: J
                        }
                    }
                }
                c(K, "blockStyle");

                function D(l, o) {
                    const {
                        prefix: e,
                        suffix: r,
                        surroundWithNewlines: p
                    } = o;
                    let b = l.value.slice(l.selectionStart, l.selectionEnd),
                        w = l.selectionStart,
                        A = l.selectionEnd;
                    const C = b.split(`
`);
                    if (C.every(N => N.startsWith(e) && N.endsWith(r))) b = C.map(N => N.slice(e.length, N.length - r.length)).join(`
`), A = w + b.length;
                    else if (b = C.map(N => e + N + r).join(`
`), p) {
                        const {
                            newlinesToAppend: N,
                            newlinesToPrepend: ot
                        } = G(l);
                        w += N.length, A = w + b.length, b = N + b + ot
                    }
                    return {
                        text: b,
                        selectionStart: w,
                        selectionEnd: A
                    }
                }
                c(D, "multilineStyle");

                function z(l) {
                    const o = l.split(`
`),
                        e = /^\d+\.\s+/,
                        r = o.every(b => e.test(b));
                    let p = o;
                    return r && (p = o.map(b => b.replace(e, ""))), {
                        text: p.join(`
`),
                        processed: r
                    }
                }
                c(z, "undoOrderedListStyle");

                function et(l) {
                    const o = l.split(`
`),
                        e = "- ",
                        r = o.every(b => b.startsWith(e));
                    let p = o;
                    return r && (p = o.map(b => b.slice(e.length, b.length))), {
                        text: p.join(`
`),
                        processed: r
                    }
                }
                c(et, "undoUnorderedListStyle");

                function Q(l, o) {
                    return o ? "- " : `${l+1}. `
                }
                c(Q, "makePrefix");

                function st(l, o) {
                    let e, r, p;
                    return l.orderedList ? (r = z(o), e = et(r.text), p = e.text) : (r = et(o), e = z(r.text), p = e.text), [r, e, p]
                }
                c(st, "clearExistingListStyle");

                function nt(l, o) {
                    const e = l.selectionStart === l.selectionEnd;
                    let r = l.selectionStart,
                        p = l.selectionEnd;
                    O(l);
                    const b = l.value.slice(l.selectionStart, l.selectionEnd),
                        [w, A, C] = st(o, b),
                        $ = C.split(`
`).map((q, Y) => `${Q(Y,o.unorderedList)}${q}`),
                        N = $.reduce((q, Y, F) => q + Q(F, o.unorderedList).length, 0),
                        ot = $.reduce((q, Y, F) => q + Q(F, !o.unorderedList).length, 0);
                    if (w.processed) return e ? (r = Math.max(r - Q(0, o.unorderedList).length, 0), p = r) : (r = l.selectionStart, p = l.selectionEnd - N), {
                        text: C,
                        selectionStart: r,
                        selectionEnd: p
                    };
                    const {
                        newlinesToAppend: Z,
                        newlinesToPrepend: rt
                    } = G(l), X = Z + $.join(`
`) + rt;
                    return e ? (r = Math.max(r + Q(0, o.unorderedList).length + Z.length, 0), p = r) : A.processed ? (r = Math.max(l.selectionStart + Z.length, 0), p = l.selectionEnd + Z.length + N - ot) : (r = Math.max(l.selectionStart + Z.length, 0), p = l.selectionEnd + Z.length + N), {
                        text: X,
                        selectionStart: r,
                        selectionEnd: p
                    }
                }
                c(nt, "listStyle");

                function it(l, o) {
                    const e = l.closest("markdown-toolbar");
                    if (!(e instanceof h)) return;
                    const p = Object.assign(Object.assign({}, {
                            prefix: "",
                            suffix: "",
                            blockPrefix: "",
                            blockSuffix: "",
                            multiline: !1,
                            replaceNext: "",
                            prefixSpace: !1,
                            scanFor: "",
                            surroundWithNewlines: !1,
                            orderedList: !1,
                            unorderedList: !1,
                            trimFirst: !1
                        }), o),
                        b = e.field;
                    b && (b.focus(), L(b, p))
                }
                c(it, "applyStyle");
                var lt = null
            },
            57852: (j, P, I) => {
                var x = I(10160);
                const _ = /\s|\(|\[/;

                function W(t, n, a, {
                    multiWord: h,
                    lookBackIndex: g,
                    lastMatchPosition: y
                } = {
                    multiWord: !1,
                    lookBackIndex: 0,
                    lastMatchPosition: null
                }) {
                    let T = t.lastIndexOf(n, a - 1);
                    if (T === -1 || T < g) return;
                    if (h) {
                        if (y != null) {
                            if (y === T) return;
                            T = y - n.length
                        }
                        if (t[T + 1] === " " && a >= T + n.length + 1 || t.lastIndexOf(`
`, a - 1) > T || t.lastIndexOf(".", a - 1) > T) return
                    } else if (t.lastIndexOf(" ", a - 1) > T) return;
                    const u = t[T - 1];
                    return u && !_.test(u) ? void 0 : {
                        text: t.substring(T + n.length, a),
                        position: T + n.length
                    }
                }
                c(W, "query");
                const S = ["position:absolute;", "overflow:auto;", "word-wrap:break-word;", "top:0px;", "left:-9999px;"],
                    B = ["box-sizing", "font-family", "font-size", "font-style", "font-variant", "font-weight", "height", "letter-spacing", "line-height", "max-height", "min-height", "padding-bottom", "padding-left", "padding-right", "padding-top", "border-bottom", "border-left", "border-right", "border-top", "text-decoration", "text-indent", "text-transform", "width", "word-spacing"],
                    H = new WeakMap;

                function M(t, n) {
                    const a = t.nodeName.toLowerCase();
                    if (a !== "textarea" && a !== "input") throw new Error("expected textField to a textarea or input");
                    let h = H.get(t);
                    if (h && h.parentElement === t.parentElement) h.innerHTML = "";
                    else {
                        h = document.createElement("div"), H.set(t, h);
                        const u = window.getComputedStyle(t),
                            s = S.slice(0);
                        a === "textarea" ? s.push("white-space:pre-wrap;") : s.push("white-space:nowrap;");
                        for (let i = 0, f = B.length; i < f; i++) {
                            const E = B[i];
                            s.push(`${E}:${u.getPropertyValue(E)};`)
                        }
                        h.style.cssText = s.join(" ")
                    }
                    const g = document.createElement("span");
                    g.style.cssText = "position: absolute;", g.innerHTML = "&nbsp;";
                    let y, T;
                    if (typeof n == "number") {
                        let u = t.value.substring(0, n);
                        u && (y = document.createTextNode(u)), u = t.value.substring(n), u && (T = document.createTextNode(u))
                    } else {
                        const u = t.value;
                        u && (y = document.createTextNode(u))
                    }
                    if (y && h.appendChild(y), h.appendChild(g), T && h.appendChild(T), !h.parentElement) {
                        if (!t.parentElement) throw new Error("textField must have a parentElement to mirror");
                        t.parentElement.insertBefore(h, t)
                    }
                    return h.scrollTop = t.scrollTop, h.scrollLeft = t.scrollLeft, {
                        mirror: h,
                        marker: g
                    }
                }
                c(M, "textFieldMirror");

                function R(t, n = t.selectionEnd) {
                    const {
                        mirror: a,
                        marker: h
                    } = M(t, n), g = a.getBoundingClientRect(), y = h.getBoundingClientRect();
                    return setTimeout(() => {
                        a.remove()
                    }, 5e3), {
                        top: y.top - g.top,
                        left: y.left - g.left
                    }
                }
                c(R, "textFieldSelectionPosition");
                const k = new WeakMap;
                class m {
                    constructor(n, a) {
                        this.expander = n, this.input = a, this.combobox = null, this.menu = null, this.match = null, this.justPasted = !1, this.lookBackIndex = 0, this.oninput = this.onInput.bind(this), this.onpaste = this.onPaste.bind(this), this.onkeydown = this.onKeydown.bind(this), this.oncommit = this.onCommit.bind(this), this.onmousedown = this.onMousedown.bind(this), this.onblur = this.onBlur.bind(this), this.interactingWithList = !1, a.addEventListener("paste", this.onpaste), a.addEventListener("input", this.oninput), a.addEventListener("keydown", this.onkeydown), a.addEventListener("blur", this.onblur)
                    }
                    destroy() {
                        this.input.removeEventListener("paste", this.onpaste), this.input.removeEventListener("input", this.oninput), this.input.removeEventListener("keydown", this.onkeydown), this.input.removeEventListener("blur", this.onblur)
                    }
                    dismissMenu() {
                        this.deactivate() && (this.lookBackIndex = this.input.selectionEnd || this.lookBackIndex)
                    }
                    activate(n, a) {
                        var h, g;
                        if (this.input !== document.activeElement && this.input !== ((g = (h = document.activeElement) === null || h === void 0 ? void 0 : h.shadowRoot) === null || g === void 0 ? void 0 : g.activeElement)) return;
                        this.deactivate(), this.menu = a, a.id || (a.id = `text-expander-${Math.floor(Math.random()*1e5).toString()}`), this.expander.append(a), this.combobox = new x.Z(this.input, a);
                        const {
                            top: y,
                            left: T
                        } = R(this.input, n.position);
                        a.style.top = `${y}px`, a.style.left = `${T}px`, this.combobox.start(), a.addEventListener("combobox-commit", this.oncommit), a.addEventListener("mousedown", this.onmousedown), this.combobox.navigate(1)
                    }
                    deactivate() {
                        const n = this.menu;
                        return !n || !this.combobox ? !1 : (this.menu = null, n.removeEventListener("combobox-commit", this.oncommit), n.removeEventListener("mousedown", this.onmousedown), this.combobox.destroy(), this.combobox = null, n.remove(), !0)
                    }
                    onCommit({
                        target: n
                    }) {
                        const a = n;
                        if (!(a instanceof HTMLElement) || !this.combobox) return;
                        const h = this.match;
                        if (!h) return;
                        const g = this.input.value.substring(0, h.position - h.key.length),
                            y = this.input.value.substring(h.position + h.text.length),
                            T = {
                                item: a,
                                key: h.key,
                                value: null
                            };
                        if (!this.expander.dispatchEvent(new CustomEvent("text-expander-value", {
                                cancelable: !0,
                                detail: T
                            })) || !T.value) return;
                        const s = `${T.value} `;
                        this.input.value = g + s + y;
                        const i = g.length + s.length;
                        this.deactivate(), this.input.focus({
                            preventScroll: !0
                        }), this.input.selectionStart = i, this.input.selectionEnd = i, this.lookBackIndex = i, this.match = null
                    }
                    onBlur() {
                        if (this.interactingWithList) {
                            this.interactingWithList = !1;
                            return
                        }
                        this.deactivate()
                    }
                    onPaste() {
                        this.justPasted = !0
                    }
                    async onInput() {
                        if (this.justPasted) {
                            this.justPasted = !1;
                            return
                        }
                        const n = this.findMatch();
                        if (n) {
                            this.match = n;
                            const a = await this.notifyProviders(n);
                            if (!this.match) return;
                            a ? this.activate(n, a) : this.deactivate()
                        } else this.match = null, this.deactivate()
                    }
                    findMatch() {
                        const n = this.input.selectionEnd || 0,
                            a = this.input.value;
                        n <= this.lookBackIndex && (this.lookBackIndex = n - 1);
                        for (const {
                                key: h,
                                multiWord: g
                            } of this.expander.keys) {
                            const y = W(a, h, n, {
                                multiWord: g,
                                lookBackIndex: this.lookBackIndex,
                                lastMatchPosition: this.match ? this.match.position : null
                            });
                            if (y) return {
                                text: y.text,
                                key: h,
                                position: y.position
                            }
                        }
                    }
                    async notifyProviders(n) {
                        const a = [],
                            h = c(u => a.push(u), "provide");
                        return this.expander.dispatchEvent(new CustomEvent("text-expander-change", {
                            cancelable: !0,
                            detail: {
                                provide: h,
                                text: n.text,
                                key: n.key
                            }
                        })) ? (await Promise.all(a)).filter(u => u.matched).map(u => u.fragment)[0] : void 0
                    }
                    onMousedown() {
                        this.interactingWithList = !0
                    }
                    onKeydown(n) {
                        n.key === "Escape" && (this.match = null, this.deactivate() && (this.lookBackIndex = this.input.selectionEnd || this.lookBackIndex, n.stopImmediatePropagation(), n.preventDefault()))
                    }
                }
                c(m, "TextExpander");
                class v extends HTMLElement {
                    get keys() {
                        const n = this.getAttribute("keys"),
                            a = n ? n.split(" ") : [],
                            h = this.getAttribute("multiword"),
                            g = h ? h.split(" ") : [],
                            y = g.length === 0 && this.hasAttribute("multiword");
                        return a.map(T => ({
                            key: T,
                            multiWord: y || g.includes(T)
                        }))
                    }
                    connectedCallback() {
                        const n = this.querySelector('input[type="text"], textarea');
                        if (!(n instanceof HTMLInputElement || n instanceof HTMLTextAreaElement)) return;
                        const a = new m(this, n);
                        k.set(this, a)
                    }
                    disconnectedCallback() {
                        const n = k.get(this);
                        !n || (n.destroy(), k.delete(this))
                    }
                    dismiss() {
                        const n = k.get(this);
                        !n || n.dismissMenu()
                    }
                }
                c(v, "TextExpanderElement"), window.customElements.get("text-expander") || (window.TextExpanderElement = v, window.customElements.define("text-expander", v));
                var d = null
            },
            88823: () => {
                const j = function() {
                    return document.readyState === "complete" ? Promise.resolve() : new Promise(W => {
                        window.addEventListener("load", W)
                    })
                }();
                class P extends HTMLElement {
                    async connectedCallback() {
                        await j, this.content && await x(this.lines, this.content, this.characterDelay, this.lineDelay), this.cursor && (this.cursor.hidden = !0), this.dispatchEvent(new CustomEvent("typing:complete", {
                            bubbles: !0,
                            cancelable: !0
                        }))
                    }
                    get content() {
                        return this.querySelector('[data-target="typing-effect.content"]')
                    }
                    get cursor() {
                        return this.querySelector('[data-target="typing-effect.cursor"]')
                    }
                    get lines() {
                        const S = this.getAttribute("data-lines");
                        try {
                            return S ? JSON.parse(S) : []
                        } catch {
                            return []
                        }
                    }
                    get prefersReducedMotion() {
                        return window.matchMedia("(prefers-reduced-motion)").matches
                    }
                    get characterDelay() {
                        return this.prefersReducedMotion ? 0 : Math.max(0, Math.min(Math.floor(Number(this.getAttribute("data-character-delay"))), 2147483647)) || 40
                    }
                    set characterDelay(S) {
                        if (S > 2147483647 || S < 0) throw new DOMException("Value is negative or greater than the allowed amount");
                        this.setAttribute("data-character-delay", String(S))
                    }
                    get lineDelay() {
                        return this.prefersReducedMotion ? 0 : Math.max(0, Math.min(Math.floor(Number(this.getAttribute("data-line-delay"))), 2147483647)) || 40
                    }
                    set lineDelay(S) {
                        if (S > 2147483647 || S < 0) throw new DOMException("Value is negative or greater than the allowed amount");
                        this.setAttribute("data-line-delay", String(S))
                    }
                }
                c(P, "TypingEffectElement");
                var I = null;
                window.customElements.get("typing-effect") || (window.TypingEffectElement = P, window.customElements.define("typing-effect", P));
                async function x(W, S, B, H) {
                    for (let M = 0; M < W.length; M++) {
                        if (B === 0) S.append(W[M]);
                        else
                            for (const R of W[M].split("")) await _(B), S.innerHTML += R;
                        H !== 0 && await _(H), M < W.length - 1 && S.append(document.createElement("br"))
                    }
                }
                c(x, "typeLines");
                async function _(W) {
                    return new Promise(S => {
                        setTimeout(S, W)
                    })
                }
                c(_, "wait")
            }
        }
    ]);
})();

//# sourceMappingURL=9207-4e71139c14e5.js.map