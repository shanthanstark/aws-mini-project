"use strict";
(() => {
    var B = Object.defineProperty;
    var i = (L, D) => B(L, "name", {
        value: D,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [5157], {
            90420: (L, D, z) => {
                z.d(D, {
                    Lj: () => Y,
                    Ih: () => T,
                    P4: () => x,
                    fA: () => P,
                    GO: () => U
                });
                const F = new WeakSet;

                function _(e) {
                    F.add(e), e.shadowRoot && g(e.shadowRoot), p(e), b(e.ownerDocument)
                }
                i(_, "bind");

                function g(e) {
                    p(e), b(e)
                }
                i(g, "bindShadow");
                const w = new WeakMap;

                function b(e = document) {
                    if (w.has(e)) return w.get(e);
                    let o = !1;
                    const a = new MutationObserver(m => {
                        for (const n of m)
                            if (n.type === "attributes" && n.target instanceof Element) M(n.target);
                            else if (n.type === "childList" && n.addedNodes.length)
                            for (const t of n.addedNodes) t instanceof Element && p(t)
                    });
                    a.observe(e, {
                        childList: !0,
                        subtree: !0,
                        attributeFilter: ["data-action"]
                    });
                    const l = {
                        get closed() {
                            return o
                        },
                        unsubscribe() {
                            o = !0, w.delete(e), a.disconnect()
                        }
                    };
                    return w.set(e, l), l
                }
                i(b, "listenForBind");

                function p(e) {
                    for (const o of e.querySelectorAll("[data-action]")) M(o);
                    e instanceof Element && e.hasAttribute("data-action") && M(e)
                }
                i(p, "bindElements");

                function N(e) {
                    const o = e.currentTarget;
                    for (const a of C(o))
                        if (e.type === a.type) {
                            const l = o.closest(a.tag);
                            F.has(l) && typeof l[a.method] == "function" && l[a.method](e);
                            const m = o.getRootNode();
                            if (m instanceof ShadowRoot && F.has(m.host) && m.host.matches(a.tag)) {
                                const n = m.host;
                                typeof n[a.method] == "function" && n[a.method](e)
                            }
                        }
                }
                i(N, "handleEvent");

                function* C(e) {
                    for (const o of (e.getAttribute("data-action") || "").trim().split(/\s+/)) {
                        const a = o.lastIndexOf(":"),
                            l = Math.max(0, o.lastIndexOf("#")) || o.length;
                        yield {
                            type: o.slice(0, a),
                            tag: o.slice(a + 1, l),
                            method: o.slice(l + 1) || "handleEvent"
                        }
                    }
                }
                i(C, "bindings");

                function M(e) {
                    for (const o of C(e)) e.addEventListener(o.type, N)
                }
                i(M, "bindActions");

                function x(e, o) {
                    const a = e.tagName.toLowerCase();
                    if (e.shadowRoot) {
                        for (const l of e.shadowRoot.querySelectorAll(`[data-target~="${a}.${o}"]`))
                            if (!l.closest(a)) return l
                    }
                    for (const l of e.querySelectorAll(`[data-target~="${a}.${o}"]`))
                        if (l.closest(a) === e) return l
                }
                i(x, "findTarget");

                function q(e, o) {
                    const a = e.tagName.toLowerCase(),
                        l = [];
                    if (e.shadowRoot)
                        for (const m of e.shadowRoot.querySelectorAll(`[data-targets~="${a}.${o}"]`)) m.closest(a) || l.push(m);
                    for (const m of e.querySelectorAll(`[data-targets~="${a}.${o}"]`)) m.closest(a) === e && l.push(m);
                    return l
                }
                i(q, "findTargets");

                function P(e, o) {
                    return Object.defineProperty(e, o, {
                        configurable: !0,
                        get() {
                            return x(this, o)
                        }
                    })
                }
                i(P, "target");

                function U(e, o) {
                    return Object.defineProperty(e, o, {
                        configurable: !0,
                        get() {
                            return q(this, o)
                        }
                    })
                }
                i(U, "targets");

                function E(e) {
                    const o = e.name.replace(/([A-Z]($|[a-z]))/g, "-$1").replace(/(^-|-Element$)/g, "").toLowerCase();
                    window.customElements.get(o) || (window[e.name] = e, window.customElements.define(o, e))
                }
                i(E, "register");

                function R(e) {
                    for (const o of e.querySelectorAll("template[data-shadowroot]")) o.parentElement === e && e.attachShadow({
                        mode: o.getAttribute("data-shadowroot") === "closed" ? "closed" : "open"
                    }).append(o.content.cloneNode(!0))
                }
                i(R, "autoShadowRoot");
                const A = new WeakMap;

                function Y(e, o) {
                    A.has(e) || A.set(e, []), A.get(e).push(o)
                }
                i(Y, "attr");

                function v(e, o) {
                    o || (o = S(Object.getPrototypeOf(e)));
                    for (const a of o) {
                        const l = e[a],
                            m = I(a);
                        let n = {
                            configurable: !0,
                            get() {
                                return this.getAttribute(m) || ""
                            },
                            set(t) {
                                this.setAttribute(m, t || "")
                            }
                        };
                        typeof l == "number" ? n = {
                            configurable: !0,
                            get() {
                                return Number(this.getAttribute(m) || 0)
                            },
                            set(t) {
                                this.setAttribute(m, t)
                            }
                        } : typeof l == "boolean" && (n = {
                            configurable: !0,
                            get() {
                                return this.hasAttribute(m)
                            },
                            set(t) {
                                this.toggleAttribute(m, t)
                            }
                        }), Object.defineProperty(e, a, n), a in e && !e.hasAttribute(m) && n.set.call(e, l)
                    }
                }
                i(v, "initializeAttrs");

                function S(e) {
                    const o = new Set;
                    let a = e;
                    for (; a && a !== HTMLElement;) {
                        const l = A.get(a) || [];
                        for (const m of l) o.add(m);
                        a = Object.getPrototypeOf(a)
                    }
                    return o
                }
                i(S, "getAttrNames");

                function I(e) {
                    return `data-${e.replace(/([A-Z]($|[a-z]))/g,"-$1")}`.replace(/--/g, "-").toLowerCase()
                }
                i(I, "attrToAttributeName");

                function H(e) {
                    let o = e.observedAttributes || [];
                    Object.defineProperty(e, "observedAttributes", {
                        configurable: !0,
                        get() {
                            return [...S(e.prototype)].map(I).concat(o)
                        },
                        set(a) {
                            o = a
                        }
                    })
                }
                i(H, "defineObservedAttributes");
                const y = new WeakSet;

                function f(e, o) {
                    e.toggleAttribute("data-catalyst", !0), customElements.upgrade(e), y.add(e), R(e), v(e), _(e), o && o.call(e), e.shadowRoot && g(e.shadowRoot)
                }
                i(f, "initializeInstance");

                function O(e) {
                    H(e), E(e)
                }
                i(O, "initializeClass");

                function Z(e) {
                    return y.has(e)
                }
                i(Z, "initialized");

                function T(e) {
                    const o = e.prototype.connectedCallback;
                    e.prototype.connectedCallback = function() {
                        f(this, o)
                    }, O(e)
                }
                i(T, "controller")
            },
            75329: (L, D, z) => {
                z.d(D, {
                    nJ: () => T
                });
                const F = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    _ = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

                function g(n) {
                    return `0${n}`.slice(-2)
                }
                i(g, "pad");

                function w(n, t) {
                    const r = n.getDay(),
                        s = n.getDate(),
                        c = n.getMonth(),
                        u = n.getFullYear(),
                        d = n.getHours(),
                        h = n.getMinutes(),
                        $ = n.getSeconds();
                    return t.replace(/%([%aAbBcdeHIlmMpPSwyYZz])/g, function(W) {
                        let k;
                        switch (W[1]) {
                            case "%":
                                return "%";
                            case "a":
                                return F[r].slice(0, 3);
                            case "A":
                                return F[r];
                            case "b":
                                return _[c].slice(0, 3);
                            case "B":
                                return _[c];
                            case "c":
                                return n.toString();
                            case "d":
                                return g(s);
                            case "e":
                                return String(s);
                            case "H":
                                return g(d);
                            case "I":
                                return g(w(n, "%l"));
                            case "l":
                                return String(d === 0 || d === 12 ? 12 : (d + 12) % 12);
                            case "m":
                                return g(c + 1);
                            case "M":
                                return g(h);
                            case "p":
                                return d > 11 ? "PM" : "AM";
                            case "P":
                                return d > 11 ? "pm" : "am";
                            case "S":
                                return g($);
                            case "w":
                                return String(r);
                            case "y":
                                return g(u % 100);
                            case "Y":
                                return String(u);
                            case "Z":
                                return k = n.toString().match(/\((\w+)\)$/), k ? k[1] : "";
                            case "z":
                                return k = n.toString().match(/\w([+-]\d\d\d\d) /), k ? k[1] : ""
                        }
                        return ""
                    })
                }
                i(w, "strftime");

                function b(n) {
                    let t;
                    return function() {
                        if (t) return t;
                        if ("Intl" in window) try {
                            return t = new Intl.DateTimeFormat(void 0, n), t
                        } catch (r) {
                            if (!(r instanceof RangeError)) throw r
                        }
                    }
                }
                i(b, "makeFormatter");
                let p = null;
                const N = b({
                    day: "numeric",
                    month: "short"
                });

                function C() {
                    if (p !== null) return p;
                    const n = N();
                    return n ? (p = !!n.format(new Date(0)).match(/^\d/), p) : !1
                }
                i(C, "isDayFirst");
                let M = null;
                const x = b({
                    day: "numeric",
                    month: "short",
                    year: "numeric"
                });

                function q() {
                    if (M !== null) return M;
                    const n = x();
                    return n ? (M = !!n.format(new Date(0)).match(/\d,/), M) : !0
                }
                i(q, "isYearSeparator");

                function P(n) {
                    return new Date().getUTCFullYear() === n.getUTCFullYear()
                }
                i(P, "isThisYear");

                function U(n, t) {
                    if ("Intl" in window && "RelativeTimeFormat" in window.Intl) try {
                        return new Intl.RelativeTimeFormat(n, t)
                    } catch (r) {
                        if (!(r instanceof RangeError)) throw r
                    }
                }
                i(U, "makeRelativeFormat");

                function E(n) {
                    const t = n.closest("[lang]");
                    return t instanceof HTMLElement && t.lang ? t.lang : "default"
                }
                i(E, "localeFromElement");
                const R = new WeakMap;
                class A extends HTMLElement {
                    static get observedAttributes() {
                        return ["datetime", "day", "format", "lang", "hour", "minute", "month", "second", "title", "weekday", "year", "time-zone-name"]
                    }
                    connectedCallback() {
                        const t = this.getFormattedTitle();
                        t && !this.hasAttribute("title") && this.setAttribute("title", t);
                        const r = this.getFormattedDate();
                        r && (this.textContent = r)
                    }
                    attributeChangedCallback(t, r, s) {
                        const c = this.getFormattedTitle();
                        if (t === "datetime") {
                            const $ = Date.parse(s);
                            isNaN($) ? R.delete(this) : R.set(this, new Date($))
                        }
                        const u = this.getFormattedTitle(),
                            d = this.getAttribute("title");
                        t !== "title" && u && (!d || d === c) && this.setAttribute("title", u);
                        const h = this.getFormattedDate();
                        h && (this.textContent = h)
                    }
                    get date() {
                        return R.get(this)
                    }
                    getFormattedTitle() {
                        const t = this.date;
                        if (!t) return;
                        const r = Y();
                        if (r) return r.format(t);
                        try {
                            return t.toLocaleString()
                        } catch (s) {
                            if (s instanceof RangeError) return t.toString();
                            throw s
                        }
                    }
                    getFormattedDate() {}
                }
                i(A, "ExtendedTimeElement");
                const Y = b({
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                        timeZoneName: "short"
                    }),
                    v = new WeakMap;
                class S extends A {
                    attributeChangedCallback(t, r, s) {
                        (t === "hour" || t === "minute" || t === "second" || t === "time-zone-name") && v.delete(this), super.attributeChangedCallback(t, r, s)
                    }
                    getFormattedDate() {
                        const t = this.date;
                        if (!t) return;
                        const r = I(this, t) || "",
                            s = H(this, t) || "";
                        return `${r} ${s}`.trim()
                    }
                }
                i(S, "LocalTimeElement");

                function I(n, t) {
                    const r = {
                        weekday: {
                            short: "%a",
                            long: "%A"
                        },
                        day: {
                            numeric: "%e",
                            "2-digit": "%d"
                        },
                        month: {
                            short: "%b",
                            long: "%B"
                        },
                        year: {
                            numeric: "%Y",
                            "2-digit": "%y"
                        }
                    };
                    let s = C() ? "weekday day month year" : "weekday month day, year";
                    for (const c in r) {
                        const u = r[c][n.getAttribute(c) || ""];
                        s = s.replace(c, u || "")
                    }
                    return s = s.replace(/(\s,)|(,\s$)/, ""), w(t, s).replace(/\s+/, " ").trim()
                }
                i(I, "formatDate");

                function H(n, t) {
                    const r = {},
                        s = n.getAttribute("hour");
                    (s === "numeric" || s === "2-digit") && (r.hour = s);
                    const c = n.getAttribute("minute");
                    (c === "numeric" || c === "2-digit") && (r.minute = c);
                    const u = n.getAttribute("second");
                    (u === "numeric" || u === "2-digit") && (r.second = u);
                    const d = n.getAttribute("time-zone-name");
                    if ((d === "short" || d === "long") && (r.timeZoneName = d), Object.keys(r).length === 0) return;
                    let h = v.get(n);
                    h || (h = b(r), v.set(n, h));
                    const $ = h();
                    if ($) return $.format(t); {
                        const W = r.second ? "%H:%M:%S" : "%H:%M";
                        return w(t, W)
                    }
                }
                i(H, "formatTime"), window.customElements.get("local-time") || (window.LocalTimeElement = S, window.customElements.define("local-time", S));
                class y {
                    constructor(t, r) {
                        this.date = t, this.locale = r
                    }
                    toString() {
                        const t = this.timeElapsed();
                        if (t) return t; {
                            const r = this.timeAhead();
                            return r || `on ${this.formatDate()}`
                        }
                    }
                    timeElapsed() {
                        const t = new Date().getTime() - this.date.getTime(),
                            r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24);
                        return t >= 0 && u < 30 ? this.timeAgoFromMs(t) : null
                    }
                    timeAhead() {
                        const t = this.date.getTime() - new Date().getTime(),
                            r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24);
                        return t >= 0 && u < 30 ? this.timeUntil() : null
                    }
                    timeAgo() {
                        const t = new Date().getTime() - this.date.getTime();
                        return this.timeAgoFromMs(t)
                    }
                    timeAgoFromMs(t) {
                        const r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24),
                            d = Math.round(u / 30),
                            h = Math.round(d / 12);
                        return t < 0 ? f(this.locale, 0, "second") : r < 10 ? f(this.locale, 0, "second") : r < 45 ? f(this.locale, -r, "second") : r < 90 ? f(this.locale, -s, "minute") : s < 45 ? f(this.locale, -s, "minute") : s < 90 ? f(this.locale, -c, "hour") : c < 24 ? f(this.locale, -c, "hour") : c < 36 ? f(this.locale, -u, "day") : u < 30 ? f(this.locale, -u, "day") : d < 18 ? f(this.locale, -d, "month") : f(this.locale, -h, "year")
                    }
                    microTimeAgo() {
                        const t = new Date().getTime() - this.date.getTime(),
                            r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24),
                            d = Math.round(u / 30),
                            h = Math.round(d / 12);
                        return s < 1 ? "1m" : s < 60 ? `${s}m` : c < 24 ? `${c}h` : u < 365 ? `${u}d` : `${h}y`
                    }
                    timeUntil() {
                        const t = this.date.getTime() - new Date().getTime();
                        return this.timeUntilFromMs(t)
                    }
                    timeUntilFromMs(t) {
                        const r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24),
                            d = Math.round(u / 30),
                            h = Math.round(d / 12);
                        return d >= 18 ? f(this.locale, h, "year") : d >= 12 ? f(this.locale, h, "year") : u >= 45 ? f(this.locale, d, "month") : u >= 30 ? f(this.locale, d, "month") : c >= 36 ? f(this.locale, u, "day") : c >= 24 ? f(this.locale, u, "day") : s >= 90 ? f(this.locale, c, "hour") : s >= 45 ? f(this.locale, c, "hour") : r >= 90 ? f(this.locale, s, "minute") : r >= 45 ? f(this.locale, s, "minute") : r >= 10 ? f(this.locale, r, "second") : f(this.locale, 0, "second")
                    }
                    microTimeUntil() {
                        const t = this.date.getTime() - new Date().getTime(),
                            r = Math.round(t / 1e3),
                            s = Math.round(r / 60),
                            c = Math.round(s / 60),
                            u = Math.round(c / 24),
                            d = Math.round(u / 30),
                            h = Math.round(d / 12);
                        return u >= 365 ? `${h}y` : c >= 24 ? `${u}d` : s >= 60 ? `${c}h` : s > 1 ? `${s}m` : "1m"
                    }
                    formatDate() {
                        let t = C() ? "%e %b" : "%b %e";
                        return P(this.date) || (t += q() ? ", %Y" : " %Y"), w(this.date, t)
                    }
                    formatTime() {
                        const t = Z();
                        return t ? t.format(this.date) : w(this.date, "%l:%M%P")
                    }
                }
                i(y, "RelativeTime");

                function f(n, t, r) {
                    const s = U(n, {
                        numeric: "auto"
                    });
                    return s ? s.format(t, r) : O(t, r)
                }
                i(f, "formatRelativeTime");

                function O(n, t) {
                    if (n === 0) switch (t) {
                        case "year":
                        case "quarter":
                        case "month":
                        case "week":
                            return `this ${t}`;
                        case "day":
                            return "today";
                        case "hour":
                        case "minute":
                            return `in 0 ${t}s`;
                        case "second":
                            return "now"
                    } else if (n === 1) switch (t) {
                        case "year":
                        case "quarter":
                        case "month":
                        case "week":
                            return `next ${t}`;
                        case "day":
                            return "tomorrow";
                        case "hour":
                        case "minute":
                        case "second":
                            return `in 1 ${t}`
                    } else if (n === -1) switch (t) {
                        case "year":
                        case "quarter":
                        case "month":
                        case "week":
                            return `last ${t}`;
                        case "day":
                            return "yesterday";
                        case "hour":
                        case "minute":
                        case "second":
                            return `1 ${t} ago`
                    } else if (n > 1) switch (t) {
                        case "year":
                        case "quarter":
                        case "month":
                        case "week":
                        case "day":
                        case "hour":
                        case "minute":
                        case "second":
                            return `in ${n} ${t}s`
                    } else if (n < -1) switch (t) {
                        case "year":
                        case "quarter":
                        case "month":
                        case "week":
                        case "day":
                        case "hour":
                        case "minute":
                        case "second":
                            return `${-n} ${t}s ago`
                    }
                    throw new RangeError(`Invalid unit argument for format() '${t}'`)
                }
                i(O, "formatEnRelativeTime");
                const Z = b({
                    hour: "numeric",
                    minute: "2-digit"
                });
                class T extends A {
                    getFormattedDate() {
                        const t = this.date;
                        if (!!t) return new y(t, E(this)).toString()
                    }
                    connectedCallback() {
                        e.push(this), o || (a(), o = window.setInterval(a, 60 * 1e3)), super.connectedCallback()
                    }
                    disconnectedCallback() {
                        const t = e.indexOf(this);
                        t !== -1 && e.splice(t, 1), e.length || o && (clearInterval(o), o = null)
                    }
                }
                i(T, "RelativeTimeElement");
                const e = [];
                let o;

                function a() {
                    let n, t, r;
                    for (t = 0, r = e.length; t < r; t++) n = e[t], n.textContent = n.getFormattedDate() || ""
                }
                i(a, "updateNowElements"), window.customElements.get("relative-time") || (window.RelativeTimeElement = T, window.customElements.define("relative-time", T));
                class l extends T {
                    getFormattedDate() {
                        const t = this.getAttribute("format"),
                            r = this.date;
                        if (!!r) return t === "micro" ? new y(r, E(this)).microTimeAgo() : new y(r, E(this)).timeAgo()
                    }
                }
                i(l, "TimeAgoElement"), window.customElements.get("time-ago") || (window.TimeAgoElement = l, window.customElements.define("time-ago", l));
                class m extends T {
                    getFormattedDate() {
                        const t = this.getAttribute("format"),
                            r = this.date;
                        if (!!r) return t === "micro" ? new y(r, E(this)).microTimeUntil() : new y(r, E(this)).timeUntil()
                    }
                }
                i(m, "TimeUntilElement"), window.customElements.get("time-until") || (window.TimeUntilElement = m, window.customElements.define("time-until", m))
            }
        }
    ]);
})();

//# sourceMappingURL=5157-5bcb364a4278.js.map