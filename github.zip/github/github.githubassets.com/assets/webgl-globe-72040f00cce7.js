"use strict";
(() => {
    var e = Object.defineProperty;
    var s = (_, b) => e(_, "name", {
        value: b,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [5144], {
            94589: (_, b, a) => {
                var l = a(23198),
                    g = a.n(l)
            }
        },
        _ => {
            var b = s(l => _(_.s = l), "__webpack_exec__");
            _.O(0, [3198], () => b(94589));
            var a = _.O()
        }
    ]);
})();