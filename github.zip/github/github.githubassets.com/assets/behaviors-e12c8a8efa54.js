(() => {
    var Cl = Object.defineProperty;
    var s = (N, C) => Cl(N, "name", {
        value: C,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [1436], {
            88237: (N, C, u) => {
                "use strict";
                var w = u(52134),
                    l = u(59753);
                (0, l.on)("deprecatedAjaxSend", "[data-remote]", function(e) {
                    e.currentTarget === e.target && (e.defaultPrevented || e.currentTarget.classList.add("loading"))
                }), (0, l.on)("deprecatedAjaxComplete", "[data-remote]", function(e) {
                    e.currentTarget === e.target && e.currentTarget.classList.remove("loading")
                });
                var T = u(65935);
                (0, T.AC)("form.js-ajax-pagination, .js-ajax-pagination form", async function(e, t) {
                    const n = e.closest(".js-ajax-pagination");
                    let o;
                    try {
                        o = await t.html()
                    } catch (r) {
                        if (r.response && r.response.status === 404) {
                            n.remove();
                            return
                        } else throw r
                    }
                    n.replaceWith(o.html), (0, l.f)(e, "page:loaded")
                });
                var k = u(95186);
                const E = "analytics.click";
                (0, l.on)("click", "[data-analytics-event]", e => {
                    const n = e.currentTarget.getAttribute("data-analytics-event");
                    if (!n) return;
                    const o = JSON.parse(n);
                    (0, k.q)(E, o)
                });
                var h = u(1314);
                document.addEventListener("pjax:start", function() {
                    (0, h.x)("Loading page")
                }), document.addEventListener("pjax:error", function() {
                    (0, h.x)("Loading failed")
                }), document.addEventListener("pjax:end", function() {
                    (0, h.x)("Loading complete")
                });
                var d = u(64463),
                    y = u(90087);
                const j = new WeakMap;
                (0, d.N7)("auto-check", function(e) {
                    if (e.classList.contains("js-prevent-default-behavior")) return;
                    const t = e.querySelector("input");
                    if (!t) return;
                    const n = t.closest(".form-group") || e,
                        o = t.form;
                    let r;

                    function i() {
                        return r || (r = `input-check-${(Math.random()*1e4).toFixed(0)}`), r
                    }
                    s(i, "generateId");
                    const a = t.getAttribute("aria-describedby");
                    t.addEventListener("focusout:delay", () => {
                        t.setAttribute("aria-describedby", [r, a].join(" "))
                    });
                    const c = n.querySelector("p.note");
                    c && (c.id || (c.id = i()), j.set(c, c.innerHTML)), e.addEventListener("loadstart", () => {
                        v(t, n), n.classList.add("is-loading"), t.classList.add("is-autocheck-loading"), (0, y.G)(o)
                    }), e.addEventListener("loadend", () => {
                        n.classList.remove("is-loading"), t.classList.remove("is-autocheck-loading")
                    }), t.addEventListener("auto-check-success", async m => {
                        t.classList.add("is-autocheck-successful"), n.classList.add("successed"), (0, y.G)(o);
                        const {
                            response: p
                        } = m.detail;
                        if (!p) return;
                        const S = await p.text();
                        if (!!S) {
                            if (c instanceof HTMLElement) c.innerHTML = S, (0, h.N)(c);
                            else {
                                const q = p.status === 200,
                                    O = n.tagName === "DL" ? "dd" : "div",
                                    B = document.createElement(O);
                                B.id = i(), B.classList.add(q ? "success" : "warning"), B.innerHTML = S, n.append(B), n.classList.add(q ? "successed" : "warn"), (0, h.N)(B), q && (B.hidden = document.activeElement !== t)
                            }(0, l.f)(t, "auto-check-message-updated")
                        }
                    }), t.addEventListener("auto-check-error", async m => {
                        t.classList.add("is-autocheck-errored"), n.classList.add("errored"), (0, y.G)(o);
                        const {
                            response: p
                        } = m.detail;
                        if (!p) return;
                        const S = await p.text();
                        if (c instanceof HTMLElement) c.innerHTML = S || "Something went wrong", (0, h.N)(c);
                        else {
                            const q = n.tagName === "DL" ? "dd" : "div",
                                O = document.createElement(q);
                            O.id = i(), O.classList.add("error"), O.innerHTML = S || "Something went wrong", n.append(O), (0, h.N)(O)
                        }
                    }), t.addEventListener("input", () => {
                        t.removeAttribute("aria-describedby"), t.value || v(t, n)
                    }), t.addEventListener("blur", () => {
                        const m = n.querySelector(".success");
                        m && (m.hidden = !0)
                    }), t.addEventListener("focus", () => {
                        const m = n.querySelector(".success");
                        m && (m.hidden = !1)
                    }), o.addEventListener("reset", () => {
                        v(t, n)
                    })
                });

                function v(e, t) {
                    var n, o, r, i, a, c;
                    t.classList.remove("is-loading", "successed", "errored", "warn"), e.classList.remove("is-autocheck-loading", "is-autocheck-successful", "is-autocheck-errored");
                    const m = t.querySelector("p.note");
                    if (m) {
                        const p = j.get(m);
                        p && (m.innerHTML = p)
                    }
                    t.tagName === "DL" ? ((n = t.querySelector("dd.error")) == null || n.remove(), (o = t.querySelector("dd.warning")) == null || o.remove(), (r = t.querySelector("dd.success")) == null || r.remove()) : ((i = t.querySelector("div.error")) == null || i.remove(), (a = t.querySelector("div.warning")) == null || a.remove(), (c = t.querySelector("div.success")) == null || c.remove())
                }
                s(v, "autocheck_reset");
                var b = u(46481);
                (0, d.N7)("auto-complete", function(e) {
                    e.addEventListener("loadstart", () => e.classList.add("is-auto-complete-loading")), e.addEventListener("loadend", () => e.classList.remove("is-auto-complete-loading"))
                }), (0, d.N7)("auto-complete", {
                    constructor: b.Z,
                    initialize: g
                }), (0, l.on)("auto-complete-change", "auto-complete", function(e) {
                    g(e.currentTarget)
                });

                function g(e) {
                    const t = e.closest("form");
                    if (!t) return;
                    const n = t.querySelector(".js-auto-complete-button");
                    n instanceof HTMLButtonElement && (n.disabled = !e.value)
                }
                s(g, "toggleSubmitButton");
                var f = u(82036),
                    L = u(10900),
                    R = u(40728);
                let I = null;
                (0, l.on)("submit", "[data-autosearch-results-container]", async function(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLFormElement)) return;
                    e.preventDefault(), I == null || I.abort(), t.classList.add("is-sending");
                    const n = new URL(t.action, window.location.origin),
                        o = t.method,
                        r = new FormData(t),
                        i = (0, f.KL)(n, r);
                    let a = null;
                    o === "get" ? n.search = i : a = r;
                    const {
                        signal: c
                    } = I = new AbortController, m = new Request(n.toString(), {
                        method: o,
                        body: a,
                        signal: c,
                        headers: {
                            Accept: "text/html",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    let p;
                    try {
                        p = await fetch(m)
                    } catch {}
                    if (t.classList.remove("is-sending"), !p || !p.ok || c.aborted) return;
                    const S = t.getAttribute("data-autosearch-results-container"),
                        q = S ? document.getElementById(S) : null;
                    q && (q.innerHTML = "", q.appendChild((0, L.r)(document, await p.text()))), (0, R.lO)(null, "", `?${i}`)
                });
                var $ = u(12020),
                    P = u(84570);
                (0, P.ZG)("input[data-autoselect], textarea[data-autoselect]", async function(e) {
                    await (0, $.gJ)(), e.select()
                });
                var U = u(46263),
                    x = u(86404);
                (0, l.on)("change", "form[data-autosubmit]", function(e) {
                    const t = e.currentTarget;
                    (0, f.Bt)(t)
                }), (0, l.on)("change", "input[data-autosubmit], select[data-autosubmit]", Y);

                function Y(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLInputElement) && !(t instanceof HTMLSelectElement)) return;
                    const n = t.form;
                    (0, f.Bt)(n)
                }
                s(Y, "autosubmit_submit");
                const D = (0, U.D)(Y, 300);
                (0, d.N7)("input[data-throttled-autosubmit]", {
                    subscribe: e => (0, x.RB)(e, "input", D)
                });
                async function H(e) {
                    const t = e.getAttribute("data-url") || "";
                    if (await M(t)) {
                        const o = e.getAttribute("data-gravatar-text");
                        o != null && (e.textContent = o)
                    }
                }
                s(H, "detectGravatar"), (0, d.N7)(".js-detect-gravatar", function(e) {
                    H(e)
                });
                async function M(e) {
                    const t = e;
                    if (!t) return !1;
                    try {
                        const n = await fetch(t, {
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        return n.ok ? (await n.json()).has_gravatar : !1
                    } catch {
                        return !1
                    }
                }
                s(M, "fetchGravatarInfo");
                var A = u(90420),
                    F = Object.defineProperty,
                    _ = Object.getOwnPropertyDescriptor,
                    V = s((e, t, n, o) => {
                        for (var r = o > 1 ? void 0 : o ? _(t, n) : t, i = e.length - 1, a; i >= 0; i--)(a = e[i]) && (r = (o ? a(t, n, r) : a(r)) || r);
                        return o && r && F(t, n, r), r
                    }, "__decorateClass");
                class G {
                    constructor(t = 50, n = 30) {
                        this.elements = [], this.timer = null, this.callbacks = [], this.csrf = null, this.timeout = t, this.limit = n
                    }
                    push(t) {
                        if (this.timer && (window.clearTimeout(this.timer), this.timer = null), t instanceof HTMLElement) {
                            const n = t.querySelector("[data-csrf]");
                            n !== null && (this.csrf = n.value)
                        }
                        this.elements.length >= this.limit && this.flush(), this.elements.push(t), this.timer = window.setTimeout(() => {
                            this.flush()
                        }, this.timeout)
                    }
                    onFlush(t) {
                        this.callbacks.push(t)
                    }
                    async flush() {
                        const t = this.elements.splice(0, this.limit);
                        t.length !== 0 && await Promise.all(this.callbacks.map(n => n(t)))
                    }
                }
                s(G, "AutoFlushingQueue");
                async function de(e, t) {
                    const n = await fetch(e, {
                        method: "POST",
                        body: t,
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (n.ok) {
                        const o = await n.json(),
                            r = new Map;
                        for (const i in o) r.set(i, o[i]);
                        return r
                    } else return new Map
                }
                s(de, "fetchContents");
                const ee = new Map;
                let re = s(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.url = ""
                    }
                    connectedCallback() {
                        this.queue.push(this)
                    }
                    get queue() {
                        let e = ee.get(this.url);
                        return e || (e = this.buildAutoFlushingQueue(), ee.set(this.url, e), e)
                    }
                    buildAutoFlushingQueue() {
                        const e = new G;
                        return e.onFlush(async t => {
                            const n = new Map,
                                o = new FormData;
                            e.csrf !== null && o.set("authenticity_token", e.csrf);
                            for (const i in t) {
                                const a = t[i],
                                    c = `item-${i}`;
                                n.set(c, a);
                                for (const m of a.inputs) o.append(`items[${c}][${m.name}]`, m.value)
                            }
                            o.set("_method", "GET");
                            const r = await de(this.url, o);
                            for (const [i, a] of r.entries()) n.get(i).replaceWith((0, L.r)(document, a))
                        }), e
                    }
                }, "BatchDeferredContentElement");
                V([A.Lj], re.prototype, "url", 2), V([A.GO], re.prototype, "inputs", 2), re = V([A.Ih], re);
                var te = u(43682),
                    In = u(57443),
                    Ye = u(12585);
                let It = null;
                (0, l.on)("click", ".js-org-signup-duration-change", e => {
                    e.preventDefault();
                    const n = e.currentTarget.getAttribute("data-plan-duration");
                    Br(n), Fr(n);
                    for (const o of document.querySelectorAll(".js-seat-field")) Ie(o);
                    Hr()
                }), (0, l.on)("change", ".js-org-signup-duration-toggle", function({
                    currentTarget: e
                }) {
                    const t = document.getElementById("js-pjax-container"),
                        n = new URL(e.getAttribute("data-url"), window.location.origin);
                    (0, te.ZP)({
                        url: n.toString(),
                        container: t
                    })
                });
                async function Ie(e) {
                    const t = e.getAttribute("data-item-name") || "items",
                        n = e.value,
                        o = new URL(e.getAttribute("data-url"), window.location.origin),
                        r = new URLSearchParams(o.search.slice(1)),
                        i = parseInt(e.getAttribute("data-item-minimum")) || 0,
                        a = parseInt(e.getAttribute("data-item-maximum")) || 300,
                        c = parseInt(e.getAttribute("data-item-count")) || 0,
                        m = Math.max(i, parseInt(n) || 0),
                        p = m > a,
                        S = document.querySelector(".js-downgrade-button"),
                        q = document.getElementById("downgrade-disabled-message");
                    S instanceof HTMLButtonElement && (S.disabled = m === c), q instanceof HTMLElement && S instanceof HTMLButtonElement && (q.hidden = !S.disabled), r.append(t, m.toString()), document.querySelector(".js-transform-user") && r.append("transform_user", "1"), o.search = r.toString(), It == null || It.abort();
                    const {
                        signal: B
                    } = It = new AbortController;
                    let K = null;
                    try {
                        const ie = await fetch(o.toString(), {
                            signal: B,
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        if (!ie.ok) return;
                        K = await ie.json()
                    } catch {}
                    if (B.aborted || !K) return;
                    const oe = document.querySelector(".js-contact-us");
                    oe && oe.classList.toggle("d-none", !p);
                    const J = document.querySelector(".js-payment-summary");
                    J && J.classList.toggle("d-none", p);
                    const ne = document.querySelector(".js-submit-billing");
                    ne instanceof HTMLElement && (ne.hidden = p);
                    const W = document.querySelector(".js-billing-section");
                    W && W.classList.toggle("has-removed-contents", K.free || K.is_enterprise_cloud_trial);
                    const X = document.querySelector(".js-upgrade-info");
                    X && X.classList.toggle("d-none", m <= 0);
                    const z = document.querySelector(".js-downgrade-info");
                    z && z.classList.toggle("d-none", m >= 0);
                    const Te = document.querySelector(".js-extra-seats-line-item");
                    Te && Te.classList.toggle("d-none", K.no_additional_seats), document.querySelector(".js-seat-field") && $r(n);
                    const Pe = document.querySelector(".js-minimum-seats-disclaimer");
                    Pe && (Pe.classList.toggle("tooltipped", K.seats === 5), Pe.classList.toggle("tooltipped-nw", K.seats === 5));
                    const Pt = K.selectors;
                    for (const ie in Pt)
                        for (const qn of document.querySelectorAll(ie)) qn.innerHTML = Pt[ie];
                    (0, R.lO)((0, te.y0)(), "", K.url)
                }
                s(Ie, "updateTotals");

                function Hr() {
                    for (const e of document.querySelectorAll(".js-unit-price")) e.hidden = !e.hidden
                }
                s(Hr, "toggleDurationUnitPrices");

                function Br(e) {
                    const t = e === "year" ? "month" : "year";
                    for (const o of document.querySelectorAll(".js-plan-duration-text")) o.textContent = e;
                    for (const o of document.querySelectorAll(".unstyled-available-plan-duration-adjective")) o.textContent = `${e}ly`;
                    for (const o of document.querySelectorAll(".js-org-signup-duration-change")) o.setAttribute("data-plan-duration", t);
                    const n = document.getElementById("signup-plan-duration");
                    n && (n.value = e)
                }
                s(Br, "updateDurationFields");

                function $r(e) {
                    var t;
                    for (const n of document.querySelectorAll(".js-seat-field")) {
                        const o = n.getAttribute("data-item-max-seats"),
                            r = (t = n == null ? void 0 : n.parentNode) == null ? void 0 : t.querySelector(".Popover");
                        o && o.length && (parseInt(e, 10) > parseInt(o, 10) ? (n.classList.add("color-border-danger-emphasis"), r == null || r.removeAttribute("hidden")) : (n.classList.remove("color-border-danger-emphasis"), r == null || r.setAttribute("hidden", "true")))
                    }
                }
                s($r, "updateSeatFields");

                function Fr(e) {
                    for (const t of document.querySelectorAll(".js-seat-field")) {
                        const n = new URL(t.getAttribute("data-url"), window.location.origin),
                            o = new URLSearchParams(n.search.slice(1));
                        o.delete("plan_duration"), o.append("plan_duration", e), n.search = o.toString(), t.setAttribute("data-url", n.toString())
                    }
                }
                s(Fr, "updateSeatFieldURLs"), (0, d.N7)(".js-addon-purchase-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        (0, Ye.Z)(e) && Ie(e), (0, In.oq)(e, function() {
                            Ie(e)
                        })
                    }
                }), (0, d.N7)(".js-addon-downgrade-field", {
                    constructor: HTMLSelectElement,
                    add(e) {
                        (0, Ye.Z)(e) && Ie(e), e.addEventListener("change", function() {
                            Ie(e)
                        })
                    }
                });

                function Ur(e) {
                    const t = document.querySelector(".js-addon-purchase-field"),
                        n = e.target.querySelector("input:checked");
                    if (t instanceof HTMLInputElement && n instanceof HTMLInputElement) {
                        const o = n.getAttribute("data-upgrade-url");
                        o && (t.setAttribute("data-url", o), t.value = "0", Ie(t))
                    }
                }
                s(Ur, "handleOrgChange"), (0, l.on)("details-menu-selected", ".js-organization-container", Ur, {
                    capture: !0
                }), (0, P.q6)(".js-csv-filter-field", function(e) {
                    const t = e.target.value.toLowerCase();
                    for (const n of document.querySelectorAll(".js-csv-data tbody tr")) n instanceof HTMLElement && (!n.textContent || (n.hidden = !!t && !n.textContent.toLowerCase().includes(t)))
                }), (0, d.N7)(".js-blob-header.is-stuck", {
                    add(e) {
                        Dn(e)
                    },
                    remove(e) {
                        Dn(e, !0)
                    }
                });

                function Dn(e, t = !1) {
                    const n = {
                        "tooltipped-nw": "tooltipped-sw",
                        "tooltipped-n": "tooltipped-s",
                        "tooltipped-ne": "tooltipped-se"
                    };
                    for (const [o, r] of Object.entries(n)) {
                        const i = t ? r : o,
                            a = t ? o : r;
                        for (const c of e.querySelectorAll(`.${i}`)) c.classList.replace(i, a)
                    }
                }
                s(Dn, "flipTooltip");

                function _r(e) {
                    const t = e.target,
                        n = t == null ? void 0 : t.closest(".js-branch-protection-integration-select"),
                        o = n == null ? void 0 : n.querySelector(".js-branch-protection-integration-select-current"),
                        r = t == null ? void 0 : t.closest(".js-branch-protection-integration-select-item"),
                        i = r == null ? void 0 : r.querySelector(".js-branch-protection-integration-select-label");
                    o && i && n && (o.innerHTML = i.innerHTML, n.open = !1)
                }
                s(_r, "changeSelection"), (0, l.on)("change", ".js-branch-protection-integration-select-input", _r);

                function Wr(e) {
                    const t = new URL(e.getAttribute("data-bulk-actions-url"), window.location.origin),
                        n = new URLSearchParams(t.search.slice(1)),
                        o = e.getAttribute("data-bulk-actions-parameter"),
                        r = Array.from(e.querySelectorAll(".js-bulk-actions-toggle:checked"));
                    if (o) {
                        const i = r.map(a => a.closest(".js-bulk-actions-item").getAttribute("data-bulk-actions-id")).sort();
                        for (const a of i) n.append(`${o}[]`, a)
                    } else
                        for (const i of r.sort((a, c) => a.value > c.value ? 1 : -1)) n.append(i.name, i.value);
                    return t.search = n.toString(), t.toString()
                }
                s(Wr, "bulkUrl");
                let Dt = null;
                async function zr(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLElement)) return;
                    const n = t.querySelector(".js-bulk-actions"),
                        o = !!t.querySelector(".js-bulk-actions-toggle:checked");
                    Dt == null || Dt.abort();
                    const {
                        signal: r
                    } = Dt = new AbortController;
                    let i = "";
                    try {
                        const a = await fetch(Wr(t), {
                            signal: r,
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!a.ok) return;
                        i = await a.text()
                    } catch {}
                    r.aborted || !i || (o ? (Nn(t), n.innerHTML = i) : (n.innerHTML = i, Nn(t)), (0, l.f)(t, "bulk-actions:updated"))
                }
                s(zr, "updateBulkActions");

                function Nn(e) {
                    const t = document.querySelector(".js-membership-tabs");
                    if (t) {
                        const n = e.querySelectorAll(".js-bulk-actions-toggle:checked");
                        t.classList.toggle("d-none", n.length > 0)
                    }
                }
                s(Nn, "toggleMembershipTabs"), (0, l.on)("change", ".js-bulk-actions-toggle", function(e) {
                    const n = e.currentTarget.closest(".js-bulk-actions-container");
                    (0, l.f)(n, "bulk-actions:update")
                }), (0, l.on)("bulk-actions:update", ".js-bulk-actions-container", (0, U.D)(zr, 100));
                var fe = u(34782),
                    me = u(83476);

                function Kr(e) {
                    try {
                        const t = window.localStorage.getItem(e);
                        return {
                            kind: "ok",
                            value: t ? JSON.parse(t) : null
                        }
                    } catch (t) {
                        return {
                            kind: "err",
                            value: t
                        }
                    }
                }
                s(Kr, "getLocalJSON");

                function On(e, t) {
                    try {
                        return window.localStorage.setItem(e, JSON.stringify(t)), {
                            kind: "ok",
                            value: null
                        }
                    } catch (n) {
                        return {
                            kind: "err",
                            value: n
                        }
                    }
                }
                s(On, "setLocalJSON");

                function Vr() {
                    const e = {};
                    for (const t of document.getElementsByTagName("script")) {
                        const n = t.src.match(/\/([\w-]+)-[0-9a-f]{8,}\.js$/);
                        n && (e[`${n[1]}.js`] = t.src)
                    }
                    for (const t of document.getElementsByTagName("link")) {
                        const n = t.href.match(/\/([\w-]+)-[0-9a-f]{8,}\.css$/);
                        n && (e[`${n[1]}.css`] = t.href)
                    }
                    return e
                }
                s(Vr, "gatherBundleURLs");

                function Xr() {
                    const e = Vr(),
                        t = Kr("bundle-urls");
                    if (t.kind === "err") {
                        On("bundle-urls", e);
                        return
                    }
                    const n = t.value || {},
                        o = Object.keys(e).filter(r => n[r] !== e[r]);
                    o.length && On("bundle-urls", { ...n,
                        ...e
                    }).kind === "ok" && (0, me.b)({
                        downloadedBundles: o
                    })
                }
                s(Xr, "report"), (async () => (await fe.C, window.requestIdleCallback(Xr)))();
                var kl = u(49908);

                function Gr(e) {
                    e.preventDefault(), e.stopPropagation()
                }
                s(Gr, "cancelEvent"), (0, d.N7)("a.btn.disabled", {
                    subscribe: e => (0, x.RB)(e, "click", Gr)
                });
                var Nt = u(81266),
                    xl = u(83954),
                    _e = u(81503);
                const Hn = "logout-was-successful";

                function Zr() {
                    for (const e of [sessionStorage, localStorage]) try {
                        e.clear()
                    } catch {}
                }
                s(Zr, "clearData");

                function Jr() {
                    (0, _e.$1)(Hn).length > 0 && (Zr(), (0, _e.kT)(Hn))
                }
                s(Jr, "clearDataIfJustLoggedOut"), Jr();
                const Bn = 2e3;
                (0, l.on)("clipboard-copy", "[data-copy-feedback]", e => {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-copy-feedback"),
                        o = t.getAttribute("aria-label"),
                        r = t.getAttribute("data-tooltip-direction") || "s";
                    t.setAttribute("aria-label", n), t.classList.add("tooltipped", `tooltipped-${r}`), t instanceof HTMLElement && ((0, h.N)(t), setTimeout(() => {
                        o ? t.setAttribute("aria-label", o) : t.removeAttribute("aria-label"), t.classList.remove("tooltipped", `tooltipped-${r}`)
                    }, Bn))
                });

                function Yr(e) {
                    Ot.delete(e), $n(e)
                }
                s(Yr, "timerCallback");

                function $n(e) {
                    const t = e.querySelector(".js-clipboard-copy-icon"),
                        n = e.querySelector(".js-clipboard-check-icon");
                    e.classList.toggle("ClipboardButton--success"), t && t.classList.toggle("d-none"), n && (n.classList.contains("d-sm-none") ? n.classList.toggle("d-sm-none") : n.classList.toggle("d-none"))
                }
                s($n, "toggleCopyButton");
                const Ot = new WeakMap;
                (0, l.on)("clipboard-copy", ".js-clipboard-copy:not([data-view-component])", function({
                    currentTarget: e
                }) {
                    if (!(e instanceof HTMLElement)) return;
                    const t = Ot.get(e);
                    t ? clearTimeout(t) : $n(e), Ot.set(e, window.setTimeout(Yr, Bn, e))
                }), (0, l.on)("click", ".js-code-nav-retry", async function(e) {
                    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
                    const t = document.querySelector(".js-tagsearch-popover");
                    if (!t) return;
                    const n = t.querySelector(".js-tagsearch-popover-content");
                    if (!n) return;
                    let o;
                    const r = e.currentTarget;
                    if (r.getAttribute("data-code-nav-kind") === "definitions" ? o = t.querySelector(".js-tagsearch-popover-content") : o = t.querySelector(".js-code-nav-references"), !o) return;
                    const a = r.getAttribute("data-code-nav-url");
                    if (!a) return;
                    const c = new URL(a, window.location.origin);
                    try {
                        const m = await fetch(c.toString(), {
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!m.ok) return;
                        const p = await m.text();
                        if (!p) return;
                        o.innerHTML = p
                    } catch {
                        return
                    }
                    n.scrollTop = 0
                }), (0, d.N7)(".js-code-nav-container", {
                    constructor: HTMLElement,
                    subscribe(e) {
                        const t = e,
                            n = document.querySelector(".js-tagsearch-popover");
                        if (!(n instanceof HTMLElement)) return {
                            unsubscribe() {}
                        };
                        const o = n.querySelector(".js-tagsearch-popover-content"),
                            r = new WeakMap,
                            i = new WeakMap;
                        let a;
                        c();

                        function c() {
                            K();
                            for (const W of document.getElementsByClassName("pl-token")) W.classList.remove("pl-token", "active")
                        }
                        s(c, "initialize");
                        async function m(W) {
                            const X = es(/\w+[!?]?/g, W.clientX, W.clientY);
                            if (!X) return;
                            const z = X.commonAncestorContainer.parentElement;
                            for (const Al of z.classList)
                                if (["pl-token", "pl-c", "pl-s", "pl-k"].includes(Al)) return;
                            if (z.closest(".js-skip-tagsearch")) return;
                            const Te = X.toString();
                            if (!Te || Te.match(/\n|\s|[();&.=",]/)) return;
                            let Fe = i.get(z);
                            if (Fe || (Fe = new Set, i.set(z, Fe)), Fe.has(Te)) return;
                            Fe.add(Te);
                            const Pe = z.closest(".js-tagsearch-file");
                            if (!Pe) return;
                            const Pt = Pe.getAttribute("data-tagsearch-path") || "";
                            let ie = Pe.getAttribute("data-tagsearch-lang") || "";
                            if (ie === "HTML+ERB")
                                if (z.closest(".pl-sre")) ie = "Ruby";
                                else return;
                            if (e.classList.contains("js-code-block-container") && (ie = ns(z) || "", !ie)) return;
                            const qn = os(X),
                                Rn = await Qr(n, Te, ie, qn, Pt);
                            if (!Rn) return;
                            const Ue = document.createElement("span");
                            Ue.classList.add("pl-token"), Ue.addEventListener("click", S);
                            const Dr = document.createElement("span");
                            Dr.innerHTML = Rn;
                            const Pn = Dr.firstElementChild;
                            if (!Pn) return;
                            const Nr = Pn.getAttribute("data-hydro-click"),
                                Or = Pn.getAttribute("data-hydro-click-hmac");
                            Or && Nr && (Ue.setAttribute("data-hydro-click", Nr), Ue.setAttribute("data-hydro-click-hmac", Or)), r.set(Ue, Rn), X.surroundContents(Ue)
                        }
                        s(m, "onMouseMove");

                        function p() {
                            o.scrollTop = 0
                        }
                        s(p, "resetScrollTop");

                        function S(W) {
                            if (W.altKey || W.ctrlKey || W.metaKey || W.shiftKey) return;
                            const X = W.currentTarget;
                            X === a ? K() : (q(X), B()), W.preventDefault()
                        }
                        s(S, "onClick");

                        function q(W) {
                            a && a.classList.remove("active"), a = W, a.classList.add("active"), o.innerHTML = r.get(W) || "", O(W)
                        }
                        s(q, "populatePopover");

                        function O(W) {
                            const X = t.getClientRects()[0],
                                z = W.getClientRects()[0];
                            n.style.position = "absolute", n.style.zIndex = "2", t.classList.contains("position-relative") ? (n.style.top = `${z.bottom-X.top+7}px`, n.style.left = `${z.left-X.left-10}px`) : (n.style.top = `${window.scrollY+z.bottom}px`, n.style.left = `${window.scrollX+z.left}px`)
                        }
                        s(O, "positionPopover");

                        function B() {
                            if (!n.hidden) {
                                p();
                                return
                            }
                            n.hidden = !1, p(), document.addEventListener("click", J), document.addEventListener("keyup", ne), window.addEventListener("resize", oe)
                        }
                        s(B, "showPopover");

                        function K() {
                            n.hidden || (n.hidden = !0, a && a.classList.remove("active"), a = void 0, document.removeEventListener("click", J), document.removeEventListener("keyup", ne), window.removeEventListener("resize", oe))
                        }
                        s(K, "hidePopover");

                        function oe() {
                            a instanceof HTMLElement && O(a)
                        }
                        s(oe, "onResize");

                        function J(W) {
                            const {
                                target: X
                            } = W;
                            X instanceof Node && !n.contains(X) && !a.contains(X) && K()
                        }
                        s(J, "onDocumentClick");

                        function ne(W) {
                            switch (W.key) {
                                case "Escape":
                                    K();
                                    break
                            }
                        }
                        return s(ne, "onKeyup"), e.addEventListener("mousemove", m), {
                            unsubscribe() {
                                e.removeEventListener("mousemove", m)
                            }
                        }
                    }
                });
                async function Qr(e, t, n, o, r) {
                    const i = e.getAttribute("data-tagsearch-url");
                    if (!i) return "";
                    const a = e.getAttribute("data-tagsearch-ref");
                    if (!a) return "";
                    let c = e.getAttribute("data-tagsearch-code-nav-context");
                    c || (c = "UNKNOWN_VIEW");
                    const m = new URL(i, window.location.origin),
                        p = new URLSearchParams;
                    p.set("q", t), p.set("blob_path", r), p.set("ref", a), p.set("language", n), p.set("row", o[0].toString()), p.set("col", o[1].toString()), p.set("code_nav_context", c), m.search = p.toString();
                    try {
                        const S = await fetch(m.toString(), {
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!S.ok) return "";
                        const q = await S.text();
                        return /js-tagsearch-no-definitions/.test(q) ? "" : q
                    } catch {
                        return ""
                    }
                }
                s(Qr, "fetchPopoverContents");

                function es(e, t, n) {
                    let o, r;
                    if (document.caretPositionFromPoint) {
                        const m = document.caretPositionFromPoint(t, n);
                        m && (o = m.offsetNode, r = m.offset)
                    } else if (document.caretRangeFromPoint) {
                        const m = document.caretRangeFromPoint(t, n);
                        m && (o = m.startContainer, r = m.startOffset)
                    }
                    if (!o || typeof r != "number" || o.nodeType !== Node.TEXT_NODE) return;
                    const i = o.textContent;
                    if (!i) return null;
                    const a = ts(i, e, r);
                    if (!a) return null;
                    const c = document.createRange();
                    return c.setStart(o, a[1]), c.setEnd(o, a[2]), c
                }
                s(es, "matchFromPoint");

                function ts(e, t, n) {
                    let o;
                    for (; o = t.exec(e);) {
                        const r = o.index + o[0].length;
                        if (o.index <= n && n < r) return [o[0], o.index, r]
                    }
                    return null
                }
                s(ts, "findNearestMatch");

                function ns(e) {
                    const t = e.closest(".highlight");
                    if (t)
                        for (const n of t.classList) switch (n) {
                            case "highlight-source-go":
                                return "Go";
                            case "highlight-source-js":
                                return "JavaScript";
                            case "highlight-source-python":
                                return "Python";
                            case "highlight-source-ruby":
                                return "Ruby";
                            case "highlight-source-ts":
                                return "TypeScript"
                        }
                    return null
                }
                s(ns, "getCodeBlockLanguage");

                function os(e) {
                    let t = e.startContainer,
                        n = e.startOffset,
                        o = !1;
                    for (;;) {
                        let r = t.previousSibling;
                        for (; !o && r;)["#comment", "BUTTON"].includes(r.nodeName) || (n += (r.textContent || "").length), r = r.previousSibling;
                        const i = t.parentElement;
                        if (i) {
                            if (i.classList.contains("js-code-nav-pass")) o = !0;
                            else if (i.classList.contains("js-file-line")) {
                                const a = i.previousElementSibling;
                                if (!a.classList.contains("js-code-nav-line-number")) throw new Error("invariant");
                                return [parseInt(a.getAttribute("data-line-number") || "1", 10) - 1, n]
                            }
                            t = i
                        } else return [0, 0]
                    }
                }
                s(os, "getRowAndColumn");
                var Ae = u(74136);

                function rs(e) {
                    const t = e.querySelector(".js-comment-form-error");
                    t instanceof HTMLElement && (t.hidden = !0)
                }
                s(rs, "clearFormError"), (0, l.on)("click", ".errored.js-remove-error-state-on-click", function({
                    currentTarget: e
                }) {
                    e.classList.remove("errored")
                }), (0, T.AC)(".js-new-comment-form", async function(e, t) {
                    let n;
                    rs(e);
                    try {
                        n = await t.json()
                    } catch (i) {
                        ss(e, i)
                    }
                    if (!n) return;
                    e.reset();
                    for (const i of e.querySelectorAll(".js-resettable-field"))(0, f.Se)(i, i.getAttribute("data-reset-value") || "");
                    const o = e.querySelector(".js-write-tab");
                    o instanceof HTMLElement && o.click();
                    const r = n.json.updateContent;
                    for (const i in r) {
                        const a = r[i],
                            c = document.querySelector(i);
                        c instanceof HTMLElement ? (0, Ae.Of)(c, a) : console.warn(`couldn't find ${i} for immediate update`)
                    }(0, l.f)(e, "comment:success")
                });

                function ss(e, t) {
                    let n = "You can't comment at this time";
                    if (t.response && t.response.status === 422) {
                        const r = t.response.json;
                        r.errors && (Array.isArray(r.errors) ? n += ` \u2014 your comment ${r.errors.join(", ")}` : n = r.errors)
                    }
                    n += ". ";
                    const o = e.querySelector(".js-comment-form-error");
                    if (o instanceof HTMLElement) {
                        o.textContent = n, o.hidden = !1;
                        const r = o.closest("div.form-group.js-remove-error-state-on-click");
                        r && r.classList.add("errored")
                    }
                }
                s(ss, "handleFormError");
                const is = s((e, t) => {
                        const n = e.querySelector(".js-form-action-text"),
                            o = n || e;
                        o.textContent = t ? e.getAttribute("data-comment-text") : o.getAttribute("data-default-action-text")
                    }, "setButtonText"),
                    as = s(e => {
                        let t;
                        return n => {
                            const r = n.currentTarget.value.trim();
                            r !== t && (t = r, is(e, Boolean(r)))
                        }
                    }, "createInputHandler");
                (0, d.N7)(".js-comment-and-button", {
                    constructor: HTMLButtonElement,
                    initialize(e) {
                        const t = e.form.querySelector(".js-comment-field"),
                            n = as(e);
                        return {
                            add() {
                                t.addEventListener("input", n), t.addEventListener("change", n)
                            },
                            remove() {
                                t.removeEventListener("input", n), t.removeEventListener("change", n)
                            }
                        }
                    }
                });
                var Ml = u(77546);

                function Fn(e, t) {
                    const n = e.closest(".js-write-bucket");
                    n && n.classList.toggle("focused", t)
                }
                s(Fn, "toggleFocus");

                function cs(e) {
                    const t = e.currentTarget;
                    t instanceof Element && Fn(t, !1)
                }
                s(cs, "blurred"), (0, P.ZG)(".js-comment-field", function(e) {
                    Fn(e, !0), e.addEventListener("blur", cs, {
                        once: !0
                    })
                });
                var be = u(77434),
                    ae = u(52769),
                    Ht = u(34078);
                const ls = 2303741511,
                    us = 4;
                class Qe {
                    static fromFile(t) {
                        return new Promise(function(n, o) {
                            const r = new FileReader;
                            r.onload = function() {
                                n(new Qe(r.result))
                            }, r.onerror = function() {
                                o(r.error)
                            }, r.readAsArrayBuffer(t)
                        })
                    }
                    constructor(t) {
                        this.dataview = new DataView(t), this.pos = 0
                    }
                    advance(t) {
                        this.pos += t
                    }
                    readInt(t) {
                        const n = this,
                            o = function() {
                                switch (t) {
                                    case 1:
                                        return n.dataview.getUint8(n.pos);
                                    case 2:
                                        return n.dataview.getUint16(n.pos);
                                    case 4:
                                        return n.dataview.getUint32(n.pos);
                                    default:
                                        throw new Error("bytes parameter must be 1, 2 or 4")
                                }
                            }();
                        return this.advance(t), o
                    }
                    readChar() {
                        return this.readInt(1)
                    }
                    readShort() {
                        return this.readInt(2)
                    }
                    readLong() {
                        return this.readInt(4)
                    }
                    readString(t) {
                        const n = [];
                        for (let o = 0; o < t; o++) n.push(String.fromCharCode(this.readChar()));
                        return n.join("")
                    }
                    scan(t) {
                        if (this.readLong() !== ls) throw new Error("invalid PNG");
                        for (this.advance(4);;) {
                            const n = this.readLong(),
                                o = this.readString(4),
                                r = this.pos + n + us;
                            if (t.call(this, o, n) === !1 || o === "IEND") break;
                            this.pos = r
                        }
                    }
                }
                s(Qe, "PNGScanner");
                const ds = .0254;
                async function fs(e) {
                    if (e.type !== "image/png") return null;
                    const t = e.slice(0, 10240, e.type),
                        n = await Qe.fromFile(t),
                        o = {
                            width: 0,
                            height: 0,
                            ppi: 1
                        };
                    return n.scan(function(r) {
                        switch (r) {
                            case "IHDR":
                                return o.width = this.readLong(), o.height = this.readLong(), !0;
                            case "pHYs":
                                {
                                    const i = this.readLong(),
                                        a = this.readLong(),
                                        c = this.readChar();
                                    let m;
                                    return c === 1 && (m = ds),
                                    m && (o.ppi = Math.round((i + a) / 2 * m)),
                                    !1
                                }
                            case "IDAT":
                                return !1
                        }
                        return !0
                    }), o
                }
                s(fs, "imageDimensions");
                var ms = u(89900);
                const et = new WeakMap;
                class Un {
                    constructor(t, n, o) {
                        this.index = t, this.coords = n, this.textArea = o
                    }
                    get top() {
                        return this.coords.top
                    }
                    get left() {
                        return this.coords.left
                    }
                    get height() {
                        return this.coords.height
                    }
                    currentChar(t = 1) {
                        return this.textArea.value.substring(this.index - t, this.index)
                    }
                    checkLine(t) {
                        return t < this.coords.top ? -1 : t > this.coords.top + this.coords.height ? 1 : 0
                    }
                    xDistance(t) {
                        return Math.abs(this.left - t)
                    }
                }
                s(Un, "CaretPosition");

                function ye(e, t) {
                    let n;
                    if (et.has(e) ? n = et.get(e) : (n = new Map, et.set(e, n)), n.has(t)) return n.get(t); {
                        const o = new Un(t, (0, ms.Z)(e, t), e);
                        return n.set(t, o), o
                    }
                }
                s(ye, "fetchCaretCoords");
                const We = s((e, t, n, o, r, i) => {
                        if (n === t) return n;
                        const a = s(S => {
                            const q = S.filter(O => O.checkLine(r) === 0).sort((O, B) => O.xDistance(o) > B.xDistance(o) ? 1 : -1);
                            return q.length === 0 ? n : q[0].index
                        }, "bestPosition");
                        if (n - t === 1) {
                            const S = ye(e, t),
                                q = ye(e, n);
                            return a([S, q])
                        }
                        if (n - t === 2) {
                            const S = ye(e, t),
                                q = ye(e, n - 1),
                                O = ye(e, n);
                            return a([S, q, O])
                        }
                        const c = Math.floor((n + t) / 2);
                        if (c === t || c === n) return c;
                        const m = ye(e, c);
                        if (r > m.top + m.height) return We(e, c + 1, n, o, r, i + 1);
                        if (r < m.top) return We(e, t, c - 1, o, r, i + 1);
                        const p = 3;
                        return m.xDistance(o) < p ? c : m.left < o ? ye(e, c + 1).checkLine(r) !== 0 ? c : We(e, c + 1, n, o, r, i + 1) : m.left > o ? ye(e, c - 1).checkLine(r) !== 0 ? c : We(e, t, c - 1, o, r, i + 1) : c
                    }, "binaryCursorSearch"),
                    ps = s((e, t, n) => {
                        const r = e.value.length - 1;
                        return We(e, 0, r, t, n, 0)
                    }, "findCursorPosition");

                function hs(e, t, n) {
                    const o = ps(e, t, n);
                    e.setSelectionRange(o, o)
                }
                s(hs, "setCursorPosition");

                function gs(e, t) {
                    const n = e.getBoundingClientRect();
                    t.type === "dragenter" && et.delete(e);
                    const o = t.clientX - n.left,
                        r = t.clientY - n.top + e.scrollTop;
                    hs(e, o, r)
                }
                s(gs, "caret_placement_updateCaret"), (0, d.N7)(".js-paste-markdown", {
                    constructor: HTMLElement,
                    add(e) {
                        (0, ae.F6)(e), (0, ae.CR)(e), (0, ae.jw)(e), (0, ae.AL)(e), (0, ae.AI)(e)
                    },
                    remove(e) {
                        (0, ae.KB)(e), (0, ae.XR)(e), (0, ae.Hl)(e), (0, ae.mK)(e), (0, ae.TR)(e)
                    }
                });
                const Bt = new WeakMap;

                function ql(e, t) {
                    Bt.set(e, t)
                }
                s(ql, "cachePlaceholder");

                function bs(e) {
                    return Bt.get(e) || Wn(e)
                }
                s(bs, "getPlaceholder");

                function $t(e) {
                    return ["video/mp4", "video/quicktime"].includes(e.file.type)
                }
                s($t, "isVideo");

                function ys(e) {
                    return e.replace(/[[\]\\"<>&]/g, ".").replace(/\.{2,}/g, ".").replace(/^\.|\.$/gi, "")
                }
                s(ys, "parameterizeName");

                function _n(e) {
                    return $t(e) ? `
Uploading ${e.file.name}\u2026
` : `${e.isImage()?"!":""}[Uploading ${e.file.name}\u2026]()`
                }
                s(_n, "placeholderText");

                function vs(e) {
                    return ys(e).replace(/\.[^.]+$/, "").replace(/\./g, " ")
                }
                s(vs, "altText");
                const ws = 72 * 2;

                function tt(e) {
                    const n = e.target.closest("form").querySelector(".btn-primary");
                    n.disabled = !0
                }
                s(tt, "disableSubmit");

                function nt(e) {
                    const n = e.target.closest("form").querySelector(".btn-primary");
                    n.disabled = !1
                }
                s(nt, "enableSubmit");
                async function Es(e) {
                    const {
                        attachment: t
                    } = e.detail, n = e.currentTarget;
                    let o;
                    t.isImage() ? o = await js(t) : $t(t) ? o = Ss(t) : o = Ls(t), Kn("", o, e, n)
                }
                s(Es, "onUploadCompleted");

                function Ls(e) {
                    return `[${e.file.name}](${e.href})`
                }
                s(Ls, "mdLink");

                function Ss(e) {
                    return `
${e.href}
`
                }
                s(Ss, "videoMarkdown");
                async function js(e) {
                    const t = await Ts(e.file),
                        n = vs(e.file.name),
                        o = e.href;
                    return t.ppi === ws ? `<img width="${Math.round(t.width/2)}" alt="${n}" src="${o}">` : `![${n}](${o})`
                }
                s(js, "imageTag");
                async function Ts(e) {
                    var t;
                    const n = {
                        width: 0,
                        height: 0,
                        ppi: 0
                    };
                    try {
                        return (t = await fs(e)) != null ? t : n
                    } catch {
                        return n
                    }
                }
                s(Ts, "imageSize");

                function Wn(e) {
                    const t = _n(e);
                    return $t(e) ? `
${t}
` : `${t}
`
                }
                s(Wn, "replacementText");

                function zn(e) {
                    const t = e.currentTarget.querySelector(".js-comment-field"),
                        n = bs(e.detail.attachment);
                    if (t) t.setCustomValidity(""), (0, be.lp)(t, n, "");
                    else {
                        const r = (0, Ht.P)(e.currentTarget.querySelector(".js-code-editor")).editor.getSearchCursor(n);
                        r.findNext(), r.replace("")
                    }
                }
                s(zn, "removeFailedUpload");

                function Kn(e, t, n, o) {
                    const r = (o || n.currentTarget).querySelector(".js-comment-field"),
                        i = (o || n.currentTarget).querySelector(".js-file-upload-loading-text"),
                        a = _n(n.detail.attachment),
                        {
                            batch: c
                        } = n.detail;
                    if (r) {
                        const m = r.value.substring(r.selectionStart, r.selectionEnd);
                        if (e === "uploading") {
                            let p;
                            m.length ? p = (0, be.t4)(r, m, a) : p = (0, be.Om)(r, a, {
                                appendNewline: !0
                            }), Bt.set(n.detail.attachment, p)
                        } else(0, be.lp)(r, a, t);
                        c.isFinished() ? nt(n) : tt(n)
                    } else {
                        const m = (0, Ht.P)((o || n.currentTarget).querySelector(".js-code-editor")).editor;
                        if (e === "uploading")
                            if (m.getSelection().length) m.replaceSelection(a);
                            else {
                                const p = m.getCursor(),
                                    S = Wn(n.detail.attachment);
                                m.replaceRange(S, p)
                            }
                        else {
                            const p = m.getSearchCursor(a);
                            p.findNext(), p.replace(t)
                        }
                        c.isFinished() ? nt(n) : tt(n)
                    }
                    if (i) {
                        const m = i.getAttribute("data-file-upload-message");
                        i.textContent = `${m} (${c.uploaded()+1}/${c.size})`
                    }
                }
                s(Kn, "setValidityAndLinkText"), (0, l.on)("upload:setup", ".js-upload-markdown-image", function(e) {
                    Kn("uploading", "", e)
                }), (0, l.on)("upload:complete", ".js-upload-markdown-image", Es), (0, l.on)("upload:error", ".js-upload-markdown-image", function(e) {
                    zn(e);
                    const {
                        batch: t
                    } = e.detail;
                    t.isFinished() ? nt(e) : tt(e)
                });

                function Vn(e) {
                    var t;
                    e.stopPropagation();
                    const n = e.currentTarget;
                    if (!n) return;
                    const o = n.querySelector(".js-comment-field");
                    if (o) gs(o, e);
                    else {
                        const r = (t = (0, Ht.P)(n.querySelector(".js-code-editor"))) == null ? void 0 : t.editor;
                        if (r) {
                            const i = r.coordsChar({
                                left: e.pageX,
                                top: e.pageY
                            });
                            r.setCursor(i)
                        }
                    }
                }
                s(Vn, "updateCursor");
                const Rl = s(e => {
                    const t = e.currentTarget,
                        n = t.getBoundingClientRect(),
                        o = e.clientX - n.left,
                        r = e.clientY - n.top + t.scrollTop;
                    console.log({
                        x: o,
                        y: r,
                        cursor: t.selectionStart,
                        t: t.value.substring(t.selectionStart - 10, t.selectionStart)
                    });
                    const i = new DragEvent("dragenter", {
                        clientX: e.clientX,
                        clientY: e.clientY
                    });
                    updateCaret(t, i)
                }, "debugUpdateCaret");
                (0, l.on)("dragenter", "file-attachment", Vn), (0, l.on)("dragover", "file-attachment", Vn), (0, l.on)("upload:invalid", ".js-upload-markdown-image", function(e) {
                    zn(e);
                    const {
                        batch: t
                    } = e.detail;
                    t.isFinished() ? nt(e) : tt(e)
                });
                var Ft = u(29501),
                    Ce = u(15205);

                function As(e) {
                    const t = e.querySelector(".js-data-preview-url-csrf"),
                        n = e.closest("form").elements.namedItem("authenticity_token");
                    if (t instanceof HTMLInputElement) return t.value;
                    if (n instanceof HTMLInputElement) return n.value;
                    throw new Error("Comment preview authenticity token not found")
                }
                s(As, "token");

                function Ut(e) {
                    const t = e.closest(".js-previewable-comment-form"),
                        n = e.classList.contains("js-preview-tab");
                    if (n) {
                        const i = t.querySelector(".js-write-bucket"),
                            a = t.querySelector(".js-preview-body");
                        i.clientHeight > 0 && (a.style.minHeight = `${i.clientHeight}px`)
                    }
                    t.classList.toggle("preview-selected", n), t.classList.toggle("write-selected", !n);
                    const o = t.querySelector('.tabnav-tab.selected, .tabnav-tab[aria-selected="true"]');
                    o.setAttribute("aria-selected", "false"), o.classList.remove("selected"), e.classList.add("selected"), e.setAttribute("aria-selected", "true");
                    const r = t.querySelector(".js-write-tab");
                    return n ? r.setAttribute("data-hotkey", "Control+P,Meta+Shift+p") : r.removeAttribute("data-hotkey"), t
                }
                s(Ut, "activateTab"), (0, l.on)("click", ".js-write-tab", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-previewable-comment-form");
                    if (n instanceof Ft.Z) {
                        setTimeout(() => {
                            n.querySelector(".js-comment-field").focus()
                        });
                        return
                    }
                    const o = Ut(t);
                    (0, l.f)(n, "preview:toggle:off");
                    const r = n.querySelector(".js-discussion-poll-form-component");
                    r && (0, l.f)(r, "poll-preview:toggle:off"), setTimeout(() => {
                        o.querySelector(".js-comment-field").focus()
                    });
                    const i = n.querySelector("markdown-toolbar");
                    i instanceof HTMLElement && (i.hidden = !1)
                }), (0, l.on)("click", ".js-preview-tab", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-previewable-comment-form");
                    if (n instanceof Ft.Z) return;
                    const o = Ut(t);
                    (0, l.f)(n, "preview:toggle:on"), setTimeout(() => {
                        Wt(o)
                    });
                    const r = n.querySelector("markdown-toolbar");
                    r instanceof HTMLElement && (r.hidden = !0), e.stopPropagation(), e.preventDefault()
                }), (0, l.on)("tab-container-change", ".js-previewable-comment-form", function(e) {
                    const t = e.detail.relatedTarget,
                        n = t && t.classList.contains("js-preview-panel"),
                        o = e.currentTarget,
                        r = o.querySelector(".js-write-tab");
                    if (n) {
                        const i = o.querySelector(".js-write-bucket"),
                            a = o.querySelector(".js-preview-body");
                        !a.hasAttribute("data-skip-sizing") && i.clientHeight > 0 && (a.style.minHeight = `${i.clientHeight}px`), r.setAttribute("data-hotkey", "Control+P,Meta+Shift+p"), Wt(o);
                        const m = o.querySelector("markdown-toolbar");
                        m instanceof HTMLElement && (m.hidden = !0)
                    } else {
                        r.removeAttribute("data-hotkey");
                        const i = o.querySelector("markdown-toolbar");
                        i instanceof HTMLElement && (i.hidden = !1);
                        const a = document.querySelector(".js-discussion-poll-form-component");
                        a && (0, l.f)(a, "poll-preview:toggle:off")
                    }
                    o.classList.toggle("preview-selected", n), o.classList.toggle("write-selected", !n)
                }), (0, l.on)("preview:render", ".js-previewable-comment-form", function(e) {
                    const t = e.target.querySelector(".js-preview-tab"),
                        n = Ut(t);
                    setTimeout(() => {
                        Wt(n);
                        const o = n.querySelector("markdown-toolbar");
                        o instanceof HTMLElement && (o.hidden = !0)
                    })
                });

                function Cs(e) {
                    var t, n, o, r, i, a, c, m, p;
                    const S = e.querySelector(".js-comment-field").value,
                        q = (t = e.querySelector(".js-path")) == null ? void 0 : t.value,
                        O = (n = e.querySelector(".js-line-number")) == null ? void 0 : n.value,
                        B = (o = e.querySelector(".js-start-line-number")) == null ? void 0 : o.value,
                        K = (r = e.querySelector(".js-side")) == null ? void 0 : r.value,
                        oe = (i = e.querySelector(".js-start-side")) == null ? void 0 : i.value,
                        J = (a = e.querySelector(".js-start-commit-oid")) == null ? void 0 : a.value,
                        ne = (c = e.querySelector(".js-end-commit-oid")) == null ? void 0 : c.value,
                        W = (m = e.querySelector(".js-base-commit-oid")) == null ? void 0 : m.value,
                        X = (p = e.querySelector(".js-comment-id")) == null ? void 0 : p.value,
                        z = new FormData;
                    return z.append("text", S), z.append("authenticity_token", As(e)), q && z.append("path", q), O && z.append("line_number", O), B && z.append("start_line_number", B), K && z.append("side", K), oe && z.append("start_side", oe), J && z.append("start_commit_oid", J), ne && z.append("end_commit_oid", ne), W && z.append("base_commit_oid", W), X && z.append("comment_id", X), z
                }
                s(Cs, "previewForm");

                function Xn(e) {
                    const t = e.getAttribute("data-preview-url"),
                        n = Cs(e);
                    return (0, l.f)(e, "preview:setup", {
                        data: n
                    }), ks(t, n)
                }
                s(Xn, "fetchPreview");
                const ks = (0, Ce.Z)(xs, {
                    hash: Ms
                });
                let _t = null;
                async function xs(e, t) {
                    _t == null || _t.abort();
                    const {
                        signal: n
                    } = _t = new AbortController, o = await fetch(e, {
                        method: "post",
                        body: t,
                        signal: n
                    });
                    if (!o.ok) throw new Error("something went wrong");
                    return o.text()
                }
                s(xs, "uncachedFetch");

                function Ms(e, t) {
                    const n = [...t.entries()].toString();
                    return `${e}:${n}`
                }
                s(Ms, "hash");
                async function Wt(e) {
                    const t = e.querySelector(".comment-body");
                    t.innerHTML = "<p>Loading preview&hellip;</p>";
                    try {
                        const n = await Xn(e);
                        t.innerHTML = n || "<p>Nothing to preview</p>", (0, l.f)(e, "preview:rendered")
                    } catch (n) {
                        n.name !== "AbortError" && (t.innerHTML = "<p>Error rendering preview</p>")
                    }
                }
                s(Wt, "renderPreview"), (0, d.N7)(".js-preview-tab", function(e) {
                    e.addEventListener("mouseenter", async () => {
                        const t = e.closest(".js-previewable-comment-form");
                        try {
                            await Xn(t)
                        } catch {}
                    })
                }), (0, P.w4)("keydown", ".js-comment-field", function(e) {
                    const t = e.target;
                    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toUpperCase() === "P") {
                        const n = t.closest(".js-previewable-comment-form");
                        n.classList.contains("write-selected") && (n instanceof Ft.Z ? n.querySelector(".js-preview-tab").click() : (t.blur(), n.dispatchEvent(new CustomEvent("preview:render", {
                            bubbles: !0,
                            cancelable: !1
                        }))), e.preventDefault(), e.stopImmediatePropagation())
                    }
                });
                const Gn = /^(\+1|-1|:\+1?|:-1?)$/,
                    qs = s(e => {
                        let t = !1;
                        for (const n of e.split(`
`)) {
                            const o = n.trim();
                            if (!(!o || o.startsWith(">"))) {
                                if (t && Gn.test(o) === !1) return !1;
                                !t && Gn.test(o) && (t = !0)
                            }
                        }
                        return t
                    }, "isReactionLikeComment");
                (0, l.on)("focusout", "#new_comment_field", function(e) {
                    const n = e.currentTarget.closest(".js-reaction-suggestion");
                    n && Jn(n)
                }), (0, l.on)("focusin", "#new_comment_field", function(e) {
                    Zn(e)
                }), (0, P.w4)("keyup", "#new_comment_field", function(e) {
                    Zn(e)
                });

                function Zn(e) {
                    const t = e.target,
                        n = t.value,
                        o = t.closest(".js-reaction-suggestion");
                    if (!!o)
                        if (qs(n)) {
                            o.classList.remove("hide-reaction-suggestion"), o.classList.add("reaction-suggestion");
                            const r = o.getAttribute("data-reaction-markup");
                            o.setAttribute("data-reaction-suggestion-message", r)
                        } else Jn(o)
                }
                s(Zn, "toggleReactionSuggestion");

                function Jn(e) {
                    e.classList.remove("reaction-suggestion"), e.classList.add("hide-reaction-suggestion"), e.removeAttribute("data-reaction-suggestion-message")
                }
                s(Jn, "clearReactionSuggestion");
                var Yn = u(82453);
                (0, l.on)("navigation:keydown", ".js-commits-list-item", function(e) {
                    !(0, Yn.Zf)(e.detail.originalEvent) || e.target instanceof Element && e.detail.hotkey === "c" && e.target.querySelector(".js-navigation-open").click()
                });
                var Pl = u(24473);
                (0, P.q6)(".js-company-name-input", function(e) {
                    const t = e.target,
                        n = t.form,
                        o = n.querySelector(".js-corp-tos-link"),
                        r = n.querySelector(".js-tos-link");
                    r && (r.classList.add("d-none"), r.setAttribute("aria-hidden", "true"), o && (o.classList.remove("d-none"), o.setAttribute("aria-hidden", "false")));
                    const i = n.querySelectorAll(".js-company-name-text");
                    if (i.length !== 0)
                        for (const a of i)
                            if (t.value)
                                if (a.hasAttribute("data-wording")) {
                                    const m = a.getAttribute("data-wording");
                                    a.textContent = ` ${m} ${t.value}`
                                } else a.textContent = t.value;
                    else a.textContent = ""
                }), (0, d.N7)(".js-company-owned:not(:checked)", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const n = e.form.querySelector(".js-company-name-input"),
                            o = document.querySelector(".js-company-name-text"),
                            r = document.querySelector(".js-corp-tos-link"),
                            i = document.querySelector(".js-tos-link");
                        n && (e.getAttribute("data-optional") && n.removeAttribute("required"), (0, f.Se)(n, "")), i.classList.remove("d-none"), i.setAttribute("aria-hidden", "false"), r.classList.add("d-none"), r.setAttribute("aria-hidden", "true"), o && (o.textContent = "")
                    }
                }), (0, d.N7)(".js-company-owned:checked", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const n = e.form.querySelector(".js-company-name-input");
                        n && (n.setAttribute("required", ""), (0, l.f)(n, "focus"), (0, l.f)(n, "input"))
                    }
                }), (0, d.N7)(".js-company-owned-autoselect", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e;

                        function n() {
                            if (t.checked && t.form) {
                                const o = t.form.querySelector(".js-company-owned");
                                (0, f.Se)(o, !0)
                            }
                        }
                        s(n, "autoselect"), t.addEventListener("change", n), n()
                    }
                });
                var zt = u(79046),
                    Kt = u(70130),
                    Vt = u(17364);
                let ve = null;
                document.addEventListener("keydown", function(e) {
                    !e.defaultPrevented && e.key === "Escape" && ve && ve.removeAttribute("open")
                }), (0, d.N7)(".js-dropdown-details", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "toggle", Ps), (0, x.RB)(e, "toggle", Rs))
                });

                function Rs({
                    currentTarget: e
                }) {
                    const t = e;
                    if (t.hasAttribute("open")) {
                        const n = t.querySelector("[autofocus]");
                        n && n.focus()
                    } else {
                        const n = t.querySelector("summary");
                        n && n.focus()
                    }
                }
                s(Rs, "autofocus");

                function Ps({
                    currentTarget: e
                }) {
                    const t = e;
                    t.hasAttribute("open") ? (ve && ve !== t && ve.removeAttribute("open"), ve = t) : t === ve && (ve = null)
                }
                s(Ps, "closeCurrentDetailsDropdown"), (0, d.N7)("[data-deferred-details-content-url]:not([data-details-no-preload-on-hover])", {
                    subscribe: e => {
                        const t = e.querySelector("summary");
                        return (0, x.RB)(t, "mouseenter", Vt.G)
                    }
                }), (0, d.N7)("[data-deferred-details-content-url]", {
                    subscribe: e => (0, x.RB)(e, "toggle", Vt.G)
                }), (0, l.on)("click", "[data-toggle-for]", function(e) {
                    const t = e.currentTarget.getAttribute("data-toggle-for") || "",
                        n = document.getElementById(t);
                    !n || (n.hasAttribute("open") ? n.removeAttribute("open") : n.setAttribute("open", "open"))
                }), (0, Kt.Z)(function({
                    target: e
                }) {
                    if (!e || e.closest("summary")) return;
                    let t = e.parentElement;
                    for (; t;) t = t.closest("details"), t && (t.hasAttribute("open") || t.setAttribute("open", ""), t = t.parentElement)
                }), (0, l.on)("details-dialog-close", "[data-disable-dialog-dismiss]", function(e) {
                    e.preventDefault()
                });
                var Is = u(88309);
                (0, d.N7)("details.select-menu details-menu include-fragment", function(e) {
                    const t = e.closest("details");
                    !t || (e.addEventListener("loadstart", function() {
                        t.classList.add("is-loading"), t.classList.remove("has-error")
                    }), e.addEventListener("error", function() {
                        t.classList.add("has-error")
                    }), e.addEventListener("loadend", function() {
                        t.classList.remove("is-loading");
                        const n = t.querySelector(".js-filterable-field");
                        n && (0, l.f)(n, "filterable:change")
                    }))
                }), (0, d.N7)("details details-menu .js-filterable-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e.closest("details");
                        t.addEventListener("toggle", function() {
                            t.hasAttribute("open") || (e.value = "", (0, l.f)(e, "filterable:change"))
                        })
                    }
                }), (0, d.N7)("details-menu[role=menu] [role=menu]", e => {
                    const t = e.closest("details-menu[role]");
                    t && t !== e && t.removeAttribute("role")
                }), (0, d.N7)("details details-menu remote-input input", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e.closest("details");
                        t.addEventListener("toggle", function() {
                            t.hasAttribute("open") || (e.value = "")
                        })
                    }
                }), (0, d.N7)("form details-menu", e => {
                    const t = e.closest("form");
                    t.addEventListener("reset", () => {
                        setTimeout(() => Ds(t), 0)
                    })
                });

                function Ds(e) {
                    const t = e.querySelectorAll("details-menu [role=menuitemradio] input[type=radio]:checked");
                    for (const n of t)(0, l.f)(n, "change")
                }
                s(Ds, "resetMenus"), (0, P.w4)("keypress", "details-menu .js-filterable-field, details-menu filter-input input", e => {
                    if (e.key === "Enter") {
                        const o = e.currentTarget.closest("details-menu").querySelector('[role^="menuitem"]:not([hidden])');
                        o instanceof HTMLElement && o.click(), e.preventDefault()
                    }
                }), (0, l.on)("details-menu-selected", "details-menu", e => {
                    const n = e.currentTarget.querySelector(".js-filterable-field");
                    n instanceof HTMLInputElement && n.value && n.focus()
                }, {
                    capture: !0
                }), (0, l.on)("details-menu-selected", "[data-menu-input]", e => {
                    if (!(e.target instanceof Element)) return;
                    const t = e.target.getAttribute("data-menu-input"),
                        n = document.getElementById(t);
                    (n instanceof HTMLInputElement || n instanceof HTMLTextAreaElement) && (n.value = e.detail.relatedTarget.value)
                }, {
                    capture: !0
                }), (0, d.N7)("details-menu remote-input", {
                    constructor: Is.Z,
                    initialize(e) {
                        const t = document.getElementById(e.getAttribute("aria-owns") || "");
                        if (!t) return;
                        let n = null;
                        e.addEventListener("load", () => {
                            document.activeElement && t.contains(document.activeElement) && document.activeElement.id ? n = document.activeElement.id : n = null
                        }), e.addEventListener("loadend", () => {
                            if (n) {
                                const o = t.querySelector(`#${n}`) || t.querySelector('[role^="menu"]');
                                o instanceof HTMLElement ? o.focus() : e.input && e.input.focus()
                            }
                        })
                    }
                }), (0, l.on)("details-menu-selected", "details-menu[data-menu-max-options]", e => {
                    const t = +e.currentTarget.getAttribute("data-menu-max-options"),
                        n = e.currentTarget.querySelectorAll('[role="menuitemcheckbox"][aria-checked="true"]'),
                        o = t === n.length;
                    e.currentTarget.querySelector("[data-menu-max-options-warning]").hidden = !o;
                    for (const r of e.currentTarget.querySelectorAll('[role="menuitemcheckbox"] input')) r.disabled = o && !r.checked
                }, {
                    capture: !0
                }), (0, d.N7)("details > details-menu", {
                    subscribe(e) {
                        const t = e.closest("details");
                        return (0, x.RB)(t, "toggle", Ns)
                    }
                });
                async function Ns({
                    currentTarget: e
                }) {
                    const t = e,
                        n = t.hasAttribute("open");
                    (0, l.f)(t, n ? "menu:activate" : "menu:deactivate"), await (0, $.gJ)(), (0, l.f)(t, n ? "menu:activated" : "menu:deactivated")
                }
                s(Ns, "fireMenuToggleEvent"), (0, d.N7)("details > details-menu[preload]:not([src])", {
                    subscribe(e) {
                        return (0, x.RB)(e.parentElement, "mouseover", function(t) {
                            const o = t.currentTarget.querySelector("include-fragment[src]");
                            o == null || o.load()
                        })
                    }
                });
                const Xt = new WeakMap,
                    Qn = ["input[type=submit][data-disable-with]", "button[data-disable-with]"].join(", ");

                function Os(e) {
                    return e instanceof HTMLInputElement ? e.value || "Submit" : e.innerHTML || ""
                }
                s(Os, "getButtonText");

                function eo(e, t) {
                    e instanceof HTMLInputElement ? e.value = t : e.innerHTML = t
                }
                s(eo, "disable_with_setButtonText"), (0, l.on)("submit", "form", function(e) {
                    for (const t of e.currentTarget.querySelectorAll(Qn)) {
                        Xt.set(t, Os(t));
                        const n = t.getAttribute("data-disable-with");
                        n && eo(t, n), t.disabled = !0
                    }
                }, {
                    capture: !0
                });

                function to(e) {
                    for (const t of e.querySelectorAll(Qn)) {
                        const n = Xt.get(t);
                        n != null && (eo(t, n), (!t.hasAttribute("data-disable-invalid") || e.checkValidity()) && (t.disabled = !1), Xt.delete(t))
                    }
                }
                s(to, "revert"), (0, l.on)("deprecatedAjaxComplete", "form", function({
                    currentTarget: e,
                    target: t
                }) {
                    e === t && to(e)
                }), (0, T.uT)(to), (0, d.N7)(".js-document-dropzone", {
                    constructor: HTMLElement,
                    add(e) {
                        document.body.addEventListener("dragstart", so), document.body.addEventListener("dragend", io), document.body.addEventListener("dragenter", ot), document.body.addEventListener("dragover", ot), document.body.addEventListener("dragleave", oo), e.addEventListener("drop", ro)
                    },
                    remove(e) {
                        document.body.removeEventListener("dragstart", so), document.body.removeEventListener("dragend", io), document.body.removeEventListener("dragenter", ot), document.body.removeEventListener("dragover", ot), document.body.removeEventListener("dragleave", oo), e.removeEventListener("drop", ro)
                    }
                });

                function no(e) {
                    return Array.from(e.types).indexOf("Files") >= 0
                }
                s(no, "hasFile");
                let Gt = null;

                function ot(e) {
                    if (Zt) return;
                    const t = e.currentTarget;
                    Gt && window.clearTimeout(Gt), Gt = window.setTimeout(() => t.classList.remove("dragover"), 200);
                    const n = e.dataTransfer;
                    !n || !no(n) || (n.dropEffect = "copy", t.classList.add("dragover"), e.stopPropagation(), e.preventDefault())
                }
                s(ot, "onDragenter");

                function oo(e) {
                    e.target instanceof Element && e.target.classList.contains("js-document-dropzone") && e.currentTarget.classList.remove("dragover")
                }
                s(oo, "onBodyDragleave");

                function ro(e) {
                    const t = e.currentTarget;
                    t.classList.remove("dragover"), document.body.classList.remove("dragover");
                    const n = e.dataTransfer;
                    !n || !no(n) || ((0, l.f)(t, "document:drop", {
                        transfer: n
                    }), e.stopPropagation(), e.preventDefault())
                }
                s(ro, "onDrop");
                let Zt = !1;

                function so() {
                    Zt = !0
                }
                s(so, "onDragstart");

                function io() {
                    Zt = !1
                }
                s(io, "onDragend");
                var rt = u(69567);
                async function ao(e, t) {
                    const o = new TextEncoder().encode(t),
                        {
                            seal: r
                        } = await Promise.all([u.e(9833), u.e(7178)]).then(u.bind(u, 86556));
                    return r(o, e)
                }
                s(ao, "encrypt");

                function co(e) {
                    const t = atob(e).split("").map(n => n.charCodeAt(0));
                    return Uint8Array.from(t)
                }
                s(co, "decode");

                function lo(e) {
                    let t = "";
                    for (const n of e) t += String.fromCharCode(n);
                    return btoa(t)
                }
                s(lo, "encode"), (0, l.on)("submit", "form.js-encrypt-submit", async function(e) {
                    const t = e.currentTarget;
                    if (e.defaultPrevented || !t.checkValidity()) return;
                    const n = t.elements.namedItem("secret_value");
                    if (n.disabled = !0, !n.value) return;
                    e.preventDefault();
                    const o = co(t.getAttribute("data-public-key"));
                    t.elements.namedItem("encrypted_value").value = lo(await ao(o, n.value)), t.submit()
                }), (0, l.on)("submit", "form.js-encrypt-bulk-submit", uo(!0)), (0, l.on)("submit", "form.js-encrypt-bulk-submit-enable-empty", uo(!1));

                function uo(e) {
                    return async function(t) {
                        const n = t.currentTarget;
                        if (t.defaultPrevented || !n.checkValidity()) return;
                        const o = co(n.getAttribute("data-public-key"));
                        t.preventDefault();
                        for (const r of n.elements) {
                            const i = r;
                            if (i.id.endsWith("secret")) {
                                if (i.disabled = !0, i.required && !i.value) {
                                    const c = `${i.name} is invalid!`,
                                        m = document.querySelector("template.js-flash-template");
                                    m.after(new rt.R(m, {
                                        className: "flash-error",
                                        message: c
                                    }));
                                    return
                                }
                                const a = `${i.name}_encrypted_value`;
                                if (!i.value) {
                                    n.elements.namedItem(a).disabled = e;
                                    continue
                                }
                                n.elements.namedItem(a).value = lo(await ao(o, i.value))
                            }
                        }
                        n.submit()
                    }
                }
                s(uo, "submitBulk");
                let st;

                function it(e, t) {
                    const n = document.querySelector('.js-site-favicon[type="image/svg+xml"]'),
                        o = document.querySelector('.js-site-favicon[type="image/png"]');
                    t || (t = "light");
                    const r = t === "light" ? "" : "-dark";
                    if (n && o)
                        if (st == null && (st = n.href), e) {
                            e = e.substr(0, e.lastIndexOf(".")), e = `${e}${r}.svg`, n.href = e;
                            const i = n.href.substr(0, n.href.lastIndexOf("."));
                            o.href = `${i}.png`
                        } else {
                            const i = n.href.indexOf("-dark.svg"),
                                a = n.href.substr(0, i !== -1 ? i : n.href.lastIndexOf("."));
                            n.href = `${a}${r}.svg`, o.href = `${a}${r}.png`
                        }
                }
                s(it, "updateFavicon");

                function at() {
                    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
                }
                s(at, "prefersDarkColorScheme");

                function Hs() {
                    st != null && it(st, at() ? "dark" : "light")
                }
                s(Hs, "resetIcon"), (0, d.N7)("[data-favicon-override]", {
                    add(e) {
                        const t = e.getAttribute("data-favicon-override");
                        setTimeout(() => it(t, at() ? "dark" : "light"))
                    },
                    remove() {
                        Hs()
                    }
                }), at() && it(void 0, "dark"), window.matchMedia("(prefers-color-scheme: dark)").addListener(() => {
                    it(void 0, at() ? "dark" : "light")
                }), (0, d.N7)(".js-feature-preview-indicator-container", e => {
                    Bs(e)
                });
                async function Bs(e) {
                    const t = e.getAttribute("data-feature-preview-indicator-src"),
                        n = await $s(t),
                        o = e.querySelectorAll(".js-feature-preview-indicator");
                    for (const r of o) r.hidden = !n
                }
                s(Bs, "fetchFeaturePreviewIndicator");
                async function $s(e) {
                    try {
                        const t = await fetch(e, {
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        return t.ok ? (await t.json()).show_indicator : !1
                    } catch {
                        return !1
                    }
                }
                s($s, "fetchIndicator");
                var we = u(51374),
                    ce = u(52660);
                (0, l.on)("click", "[data-feature-preview-trigger-url]", async e => {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-feature-preview-trigger-url"),
                        o = await (0, we.W)({
                            content: (0, ce.a)(document, n),
                            dialogClass: "feature-preview-dialog"
                        }),
                        r = t.getAttribute("data-feature-preview-close-details"),
                        i = t.getAttribute("data-feature-preview-close-hmac");
                    o.addEventListener("dialog:remove", () => {
                        (0, me.b)({
                            hydroEventPayload: r,
                            hydroEventHmac: i
                        }, !0)
                    });
                    const a = document.querySelectorAll(".js-feature-preview-indicator");
                    for (const c of a) c.hidden = !0
                }), (0, T.AC)(".js-feature-preview-unenroll", async (e, t) => {
                    await t.text();
                    const n = e.querySelector(".js-feature-preview-slug").value;
                    (0, l.f)(e, `feature-preview-unenroll:${n}`)
                }), (0, T.AC)(".js-feature-preview-enroll", async (e, t) => {
                    await t.text();
                    const n = e.querySelector(".js-feature-preview-slug").value;
                    (0, l.f)(e, `feature-preview-enroll:${n}`)
                });
                class fo {
                    constructor(t, n) {
                        this.attachment = t, this.policy = n
                    }
                    async process(t) {
                        var n, o, r, i;
                        const a = window.performance.now(),
                            c = new Headers(this.policy.header || {}),
                            m = new XMLHttpRequest;
                        m.open("POST", this.policy.upload_url, !0);
                        for (const [O, B] of c) m.setRequestHeader(O, B);
                        m.onloadstart = () => {
                            t.attachmentUploadDidStart(this.attachment, this.policy)
                        }, m.upload.onprogress = O => {
                            if (O.lengthComputable) {
                                const B = Math.round(O.loaded / O.total * 100);
                                t.attachmentUploadDidProgress(this.attachment, B)
                            }
                        }, await Fs(m, Us(this.attachment, this.policy)), m.status === 204 ? (mo(this.policy), t.attachmentUploadDidComplete(this.attachment, this.policy, {})) : m.status === 201 ? (mo(this.policy), t.attachmentUploadDidComplete(this.attachment, this.policy, JSON.parse(m.responseText))) : t.attachmentUploadDidError(this.attachment, {
                            status: m.status,
                            body: m.responseText
                        });
                        const q = {
                            duration: window.performance.now() - a,
                            size: (o = (n = this.attachment) == null ? void 0 : n.file) == null ? void 0 : o.size,
                            fileType: (i = (r = this.attachment) == null ? void 0 : r.file) == null ? void 0 : i.type,
                            success: m.status === 204 || m.status === 201
                        };
                        (0, me.b)({
                            uploadTiming: q
                        }, !0)
                    }
                }
                s(fo, "AttachmentUpload");

                function Fs(e, t) {
                    return new Promise((n, o) => {
                        e.onload = () => n(e), e.onerror = o, e.send(t)
                    })
                }
                s(Fs, "send");

                function Us(e, t) {
                    const n = new FormData;
                    t.same_origin && n.append("authenticity_token", t.upload_authenticity_token);
                    for (const o in t.form) n.append(o, t.form[o]);
                    return n.append("file", e.file), n
                }
                s(Us, "uploadForm");

                function mo(e) {
                    const t = typeof e.asset_upload_url == "string" ? e.asset_upload_url : null,
                        n = typeof e.asset_upload_authenticity_token == "string" ? e.asset_upload_authenticity_token : null;
                    if (!(t && n)) return;
                    const o = new FormData;
                    o.append("authenticity_token", n), fetch(t, {
                        method: "PUT",
                        body: o,
                        credentials: "same-origin",
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }
                s(mo, "markComplete");
                async function _s(e, t) {
                    const n = Vs(e, t);
                    for (const o of e.attachments) {
                        const r = await Ws(e, o, t);
                        if (!r) return;
                        try {
                            await new fo(o, r).process(n)
                        } catch {
                            (0, l.f)(t, "upload:error", {
                                batch: e,
                                attachment: o
                            }), Ee(t, "is-failed");
                            return
                        }
                    }
                }
                s(_s, "upload");
                async function Ws(e, t, n) {
                    const o = zs(t, n),
                        r = [];
                    (0, l.f)(n, "upload:setup", {
                        batch: e,
                        attachment: t,
                        form: o,
                        preprocess: r
                    });
                    try {
                        await Promise.all(r);
                        const i = await fetch(Ks(o, n));
                        if (i.ok) return await i.json();
                        (0, l.f)(n, "upload:invalid", {
                            batch: e,
                            attachment: t
                        });
                        const a = await i.text(),
                            c = i.status,
                            {
                                state: m,
                                messaging: p
                            } = po({
                                status: c,
                                body: a
                            }, t.file);
                        Ee(n, m, p)
                    } catch {
                        (0, l.f)(n, "upload:invalid", {
                            batch: e,
                            attachment: t
                        }), Ee(n, "is-failed")
                    }
                    return null
                }
                s(Ws, "validate");

                function zs(e, t) {
                    const n = t.querySelector(".js-data-upload-policy-url-csrf").value,
                        o = t.getAttribute("data-upload-repository-id"),
                        r = t.getAttribute("data-subject-type"),
                        i = t.getAttribute("data-subject-param"),
                        a = e.file,
                        c = new FormData;
                    return c.append("name", a.name), c.append("size", String(a.size)), c.append("content_type", a.type), c.append("authenticity_token", n), r && c.append("subject_type", r), i && c.append("subject", i), o && c.append("repository_id", o), e.directory && c.append("directory", e.directory), c
                }
                s(zs, "policyForm");

                function Ks(e, t) {
                    return new Request(t.getAttribute("data-upload-policy-url"), {
                        method: "POST",
                        body: e,
                        credentials: "same-origin",
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }
                s(Ks, "policyRequest");

                function Vs(e, t) {
                    return {
                        attachmentUploadDidStart(n, o) {
                            n.saving(0), Ee(t, "is-uploading"), (0, l.f)(t, "upload:start", {
                                batch: e,
                                attachment: n,
                                policy: o
                            })
                        },
                        attachmentUploadDidProgress(n, o) {
                            n.saving(o), (0, l.f)(t, "upload:progress", {
                                batch: e,
                                attachment: n
                            })
                        },
                        attachmentUploadDidComplete(n, o, r) {
                            n.saved(Xs(r, o)), (0, l.f)(t, "upload:complete", {
                                batch: e,
                                attachment: n
                            }), e.isFinished() && Ee(t, "is-default")
                        },
                        attachmentUploadDidError(n, o) {
                            (0, l.f)(t, "upload:error", {
                                batch: e,
                                attachment: n
                            });
                            const {
                                state: r
                            } = po(o);
                            Ee(t, r)
                        }
                    }
                }
                s(Vs, "createDelegate");

                function Xs(e, t) {
                    const n = (e.id == null ? null : String(e.id)) || (t.asset.id == null ? null : String(t.asset.id)),
                        o = (typeof e.href == "string" ? e.href : null) || (typeof t.asset.href == "string" ? t.asset.href : null);
                    return {
                        id: n,
                        href: o,
                        name: t.asset.name
                    }
                }
                s(Xs, "savedAttributes");

                function po(e, t) {
                    if (e.status === 400) return {
                        state: "is-bad-file"
                    };
                    if (e.status !== 422) return {
                        state: "is-failed"
                    };
                    const n = JSON.parse(e.body);
                    if (!n || !n.errors) return {
                        state: "is-failed"
                    };
                    for (const o of n.errors) switch (o.field) {
                        case "size":
                            {
                                const r = t ? t.size : null;
                                return r != null && r === 0 ? {
                                    state: "is-empty"
                                } : {
                                    state: "is-too-big",
                                    messaging: {
                                        message: Gs(o.message),
                                        target: ".js-upload-too-big"
                                    }
                                }
                            }
                        case "file_count":
                            return {
                                state: "is-too-many"
                            };
                        case "width":
                        case "height":
                            return {
                                state: "is-bad-dimensions"
                            };
                        case "name":
                            return o.code === "already_exists" ? {
                                state: "is-duplicate-filename"
                            } : {
                                state: "is-bad-file"
                            };
                        case "content_type":
                            return {
                                state: "is-bad-file"
                            };
                        case "uploader_id":
                            return {
                                state: "is-bad-permissions"
                            };
                        case "repository_id":
                            return {
                                state: "is-repository-required"
                            };
                        case "format":
                            return {
                                state: "is-bad-format"
                            }
                    }
                    return {
                        state: "is-failed"
                    }
                }
                s(po, "policyErrorState");
                const Gs = s(e => e.startsWith("size") ? e.substring(5) : e, "trimSizeErrorMessage"),
                    Zs = ["is-default", "is-uploading", "is-bad-file", "is-duplicate-filename", "is-too-big", "is-too-many", "is-hidden-file", "is-failed", "is-bad-dimensions", "is-empty", "is-bad-permissions", "is-repository-required", "is-bad-format"];

                function Ee(e, t, n) {
                    if (n) {
                        const {
                            message: o,
                            target: r
                        } = n, i = e.querySelector(r);
                        i && (i.innerHTML = o)
                    }
                    e.classList.remove(...Zs), e.classList.add(t)
                }
                s(Ee, "resetState");
                class ho {
                    constructor(t) {
                        this.attachments = t, this.size = this.attachments.length, this.total = Jt(this.attachments, n => n.file.size)
                    }
                    percent() {
                        const t = s(o => o.file.size * o.percent / 100, "bytes"),
                            n = Jt(this.attachments, t);
                        return Math.round(n / this.total * 100)
                    }
                    uploaded() {
                        const t = s(n => n.isSaved() ? 1 : 0, "value");
                        return Jt(this.attachments, t)
                    }
                    isFinished() {
                        return this.attachments.every(t => t.isSaved())
                    }
                }
                s(ho, "Batch");

                function Jt(e, t) {
                    return e.reduce((n, o) => n + t(o), 0)
                }
                s(Jt, "sum"), (0, d.N7)("file-attachment[hover]", {
                    add(e) {
                        e.classList.add("dragover")
                    },
                    remove(e) {
                        e.classList.remove("dragover")
                    }
                }), (0, l.on)("file-attachment-accept", "file-attachment", function(e) {
                    const {
                        attachments: t
                    } = e.detail;
                    t.length === 0 && (Ee(e.currentTarget, "is-hidden-file"), e.preventDefault())
                }), (0, l.on)("file-attachment-accepted", "file-attachment", function(e) {
                    const t = e.currentTarget.querySelector(".drag-and-drop");
                    if (t && t.hidden) return;
                    const {
                        attachments: n
                    } = e.detail;
                    _s(new ho(n), e.currentTarget)
                });
                let go = 0;
                (0, d.N7)("file-attachment", {
                    add(e) {
                        go++ === 0 && (document.addEventListener("drop", yo), document.addEventListener("dragover", vo));
                        const t = e.closest("form");
                        t && t.addEventListener("reset", wo)
                    },
                    remove(e) {
                        --go === 0 && (document.removeEventListener("drop", yo), document.removeEventListener("dragover", vo));
                        const t = e.closest("form");
                        t && t.removeEventListener("reset", wo)
                    }
                });

                function bo(e) {
                    return Array.from(e.types).indexOf("Files") >= 0
                }
                s(bo, "file_attachment_hasFile");

                function yo(e) {
                    const t = e.dataTransfer;
                    t && bo(t) && e.preventDefault()
                }
                s(yo, "onDocumentDrop");

                function vo(e) {
                    const t = e.dataTransfer;
                    t && bo(t) && e.preventDefault()
                }
                s(vo, "onDocumentDragover");

                function wo({
                    currentTarget: e
                }) {
                    const t = e.querySelector("file-attachment");
                    Ee(t, "is-default")
                }
                s(wo, "onFormReset");
                var Js = u(13002);
                (0, l.on)("filter-input-updated", "filter-input", e => {
                    const t = e.currentTarget.input;
                    if (!(document.activeElement && document.activeElement === t)) return;
                    const {
                        count: n,
                        total: o
                    } = e.detail;
                    (0, h.x)(`Found ${n} out of ${o} ${o===1?"item":"items"}`)
                }), (0, l.on)("toggle", "details", e => {
                    setTimeout(() => Ys(e.target), 0)
                }, {
                    capture: !0
                }), (0, l.on)("tab-container-changed", "tab-container", e => {
                    if (!(e.target instanceof HTMLElement)) return;
                    const {
                        relatedTarget: t
                    } = e.detail, n = e.target.querySelector("filter-input");
                    n instanceof Js.Z && n.setAttribute("aria-owns", t.id)
                }, {
                    capture: !0
                });

                function Ys(e) {
                    const t = e.querySelector("filter-input");
                    t && !e.hasAttribute("open") && t.reset()
                }
                s(Ys, "resetFilter");
                var Il = u(64909);
                const Eo = navigator.userAgent.match(/Firefox\/(\d+)/);
                Eo && Number(Eo[1]) < 76 && ((0, d.N7)('details-menu label[tabindex][role^="menuitem"]', e => {
                    const t = e.querySelector("input");
                    if (!t) return;
                    const n = e.classList.contains("select-menu-item"),
                        o = t.classList.contains("d-none"),
                        r = n || o || t.hidden;
                    n && t.classList.add("d-block"), o && t.classList.remove("d-none"), r && (t.classList.add("sr-only"), t.hidden = !1), e.removeAttribute("tabindex")
                }), (0, l.on)("focus", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', e => {
                    const t = e.currentTarget.closest("label");
                    t.classList.contains("select-menu-item") && t.classList.add("navigation-focus"), t.classList.contains("SelectMenu-item") && t.classList.add("hx_menuitem--focus"), t.classList.contains("dropdown-item") && t.classList.add("hx_menuitem--focus"), e.currentTarget.addEventListener("blur", () => {
                        t.classList.contains("select-menu-item") && t.classList.remove("navigation-focus"), t.classList.contains("SelectMenu-item") && t.classList.remove("hx_menuitem--focus"), t.classList.contains("dropdown-item") && t.classList.remove("hx_menuitem--focus")
                    }, {
                        once: !0
                    })
                }, {
                    capture: !0
                }), (0, P.w4)("keydown", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', async function(e) {
                    if (Lo(e)) e.currentTarget instanceof Element && Qs(e.currentTarget);
                    else if (e.key === "Enter") {
                        const t = e.currentTarget;
                        e.preventDefault(), await (0, $.gJ)(), t instanceof HTMLInputElement && t.click()
                    }
                }), (0, l.on)("blur", 'details-menu label input[role="menuitemradio"], details-menu label input[role="menuitemcheckbox"]', e => {
                    So(e.currentTarget)
                }, {
                    capture: !0
                }), (0, P.w4)("keyup", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', e => {
                    !Lo(e) || e.currentTarget instanceof Element && So(e.currentTarget)
                }));

                function Lo(e) {
                    return e.key === "ArrowDown" || e.key === "ArrowUp"
                }
                s(Lo, "isArrowKeys");

                function Qs(e) {
                    const t = e.closest("label");
                    t.hasAttribute("data-role") || t.setAttribute("data-role", t.getAttribute("role")), e.setAttribute("role", t.getAttribute("data-role")), t.removeAttribute("role")
                }
                s(Qs, "switchRoleToInputForNavigation");

                function So(e) {
                    const t = e.closest("label");
                    t.hasAttribute("data-role") || t.setAttribute("data-role", t.getAttribute("role")), t.setAttribute("role", t.getAttribute("data-role")), e.removeAttribute("role")
                }
                s(So, "switchRoleBackToOriginalState");
                var Yt = u(37713);

                function jo() {
                    document.firstElementChild.classList.contains("js-skip-scroll-target-into-view") || (0, Yt.lA)(document) && (0, Yt.kc)(document)
                }
                s(jo, "scrollTargetIntoViewIfNeeded"), (0, Kt.Z)(jo), (0, l.on)("click", 'a[href^="#"]', function(e) {
                    const {
                        currentTarget: t
                    } = e;
                    t instanceof HTMLAnchorElement && setTimeout(jo, 0)
                });
                var Dl = u(11997);
                const ei = ["flash-notice", "flash-error", "flash-message", "flash-warn"];

                function ti(e) {
                    for (const {
                            key: t,
                            value: n
                        } of ei.flatMap(_e.$1)) {
                        (0, _e.kT)(t);
                        let o;
                        try {
                            o = atob(decodeURIComponent(n))
                        } catch {
                            continue
                        }
                        e.after(new rt.R(e, {
                            className: t,
                            message: o
                        }))
                    }
                }
                s(ti, "displayFlash"), (0, d.N7)("template.js-flash-template", {
                    constructor: HTMLTemplateElement,
                    add(e) {
                        ti(e)
                    }
                });
                const Qt = new WeakMap;
                document.addEventListener("focus", function(e) {
                    const t = e.target;
                    t instanceof Element && !Qt.get(t) && ((0, l.f)(t, "focusin:delay"), Qt.set(t, !0))
                }, {
                    capture: !0
                }), document.addEventListener("blur", function(e) {
                    setTimeout(function() {
                        const t = e.target;
                        t instanceof Element && t !== document.activeElement && ((0, l.f)(t, "focusout:delay"), Qt.delete(t))
                    }, 200)
                }, {
                    capture: !0
                }), (0, T.AC)(".js-form-toggle-target", async function(e, t) {
                    try {
                        await t.text()
                    } catch {
                        return
                    }
                    const n = e.closest(".js-form-toggle-container");
                    n.querySelector(".js-form-toggle-target[hidden]").hidden = !1, e.hidden = !0
                });
                var ni = u(91603);

                function oi(e) {
                    e instanceof CustomEvent && (0, h.x)(`${e.detail} results found.`)
                }
                s(oi, "noticeHandler"), (0, d.N7)("fuzzy-list", {
                    constructor: ni.Z,
                    subscribe: e => (0, x.RB)(e, "fuzzy-list-sorted", oi)
                }), (0, l.on)("click", ".email-hidden-toggle", function(e) {
                    const t = e.currentTarget.nextElementSibling;
                    t instanceof HTMLElement && (t.style.display = "", t.classList.toggle("expanded"), e.preventDefault())
                });
                var Nl = u(42474);
                (0, d.N7)(".js-hook-url-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        function t() {
                            const n = e.form;
                            if (!n) return;
                            let o;
                            try {
                                o = new URL(e.value)
                            } catch {}
                            const r = n.querySelector(".js-invalid-url-notice");
                            r instanceof HTMLElement && (r.hidden = !!(e.value === "" || o && /^https?:/.test(o.protocol)));
                            const i = n.querySelector(".js-insecure-url-notice");
                            i instanceof HTMLElement && o && e.value && (i.hidden = /^https:$/.test(o.protocol));
                            const a = n.querySelector(".js-ssl-hook-fields");
                            a instanceof HTMLElement && (a.hidden = !(o && o.protocol === "https:"))
                        }
                        s(t, "checkUrl"), (0, In.oq)(e, t), t()
                    }
                });

                function To(e) {
                    const t = document.querySelectorAll(".js-hook-event-checkbox");
                    for (const n of t) n.checked = n.matches(e)
                }
                s(To, "chooseEvents"), (0, l.on)("change", ".js-hook-event-choice", function(e) {
                    const t = e.currentTarget,
                        n = t.checked && t.value === "custom",
                        o = t.closest(".js-hook-events-field");
                    if (o && o.classList.toggle("is-custom", n), t.checked)
                        if (n) {
                            const r = document.querySelector(".js-hook-wildcard-event");
                            r.checked = !1
                        } else t.value === "push" ? To('[value="push"]') : t.value === "all" && To(".js-hook-wildcard-event")
                }), (0, l.on)("click", ".js-hook-deliveries-pagination-button", async function(e) {
                    const t = e.currentTarget;
                    t.disabled = !0;
                    const n = t.parentElement,
                        o = t.getAttribute("data-url");
                    n.before(await (0, ce.a)(document, o)), n.remove()
                }), (0, T.AC)(".js-redeliver-hook-form", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch {
                        e.classList.add("failed");
                        return
                    }
                    document.querySelector(".js-hook-deliveries-container").replaceWith(n.html)
                });
                var Ol = u(25522),
                    en = u(81654);
                let Z = document.querySelector(".js-hovercard-content");
                (0, d.N7)(".js-hovercard-content", e => {
                    Z = e
                });
                const ri = (0, Ce.Z)(ce.a);
                let Le, ct = null,
                    tn, nn = 0;
                const on = 12,
                    rn = 24,
                    Ao = rn - 7,
                    Co = 16,
                    si = 100,
                    ii = 250;

                function ke(e) {
                    return "Popover-message--" + e
                }
                s(ke, "contentClass");

                function ai(e) {
                    setTimeout(() => {
                        if (document.body && document.body.contains(e)) {
                            const t = e.querySelector("[data-hovercard-tracking]");
                            if (t) {
                                const o = t.getAttribute("data-hovercard-tracking");
                                o && (0, k.q)("user-hovercard-load", JSON.parse(o))
                            }
                            const n = e.querySelector("[data-hydro-view]");
                            n instanceof HTMLElement && (0, en.Fk)(n)
                        }
                    }, 500)
                }
                s(ai, "trackLoad");

                function De() {
                    Z instanceof HTMLElement && (Z.style.display = "none", Z.children[0].innerHTML = "", ct = null, Le = null)
                }
                s(De, "hideCard");

                function ci(e) {
                    const t = e.getClientRects();
                    let n = t[0] || e.getBoundingClientRect() || {
                        top: 0,
                        left: 0,
                        height: 0,
                        width: 0
                    };
                    if (t.length > 0) {
                        for (const o of t)
                            if (o.left < nn && o.right > nn) {
                                n = o;
                                break
                            }
                    }
                    return n
                }
                s(ci, "selectRectNearestMouse");

                function li(e) {
                    const {
                        width: t,
                        height: n
                    } = Z.getBoundingClientRect(), {
                        left: o,
                        top: r,
                        height: i,
                        width: a
                    } = ci(e), c = r > n;
                    if (e.classList.contains("js-hovercard-left")) {
                        const p = o - t - on,
                            S = r + i / 2;
                        return {
                            containerTop: c ? S - n + Ao + Co / 2 : S - Ao - Co / 2,
                            containerLeft: p,
                            contentClassSuffix: c ? "right-bottom" : "right-top"
                        }
                    } else {
                        const p = window.innerWidth - o > t,
                            S = o + a / 2,
                            q = p ? S - rn : S - t + rn;
                        return {
                            containerTop: c ? r - n - on : r + i + on,
                            containerLeft: q,
                            contentClassSuffix: c ? p ? "bottom-left" : "bottom-right" : p ? "top-left" : "top-right"
                        }
                    }
                }
                s(li, "calculatePositions");

                function ui(e, t) {
                    if (!(Z instanceof HTMLElement)) return;
                    Z.style.visibility = "hidden", Z.style.display = "block", t.classList.remove(ke("bottom-left"), ke("bottom-right"), ke("right-top"), ke("right-bottom"), ke("top-left"), ke("top-right"));
                    const {
                        containerTop: n,
                        containerLeft: o,
                        contentClassSuffix: r
                    } = li(e);
                    t.classList.add(ke(r)), Z.style.top = `${n+window.pageYOffset}px`, Z.style.left = `${o+window.pageXOffset}px`, vi(e, Z), Z.style.visibility = ""
                }
                s(ui, "positionCard");

                function di(e, t) {
                    if (!(Z instanceof HTMLElement)) return;
                    const n = Z.children[0];
                    n.innerHTML = "";
                    const o = document.createElement("div");
                    for (const r of e.children) o.appendChild(r.cloneNode(!0));
                    n.appendChild(o), ui(t, n), ai(o), Z.style.display = "block"
                }
                s(di, "showCard");

                function fi(e) {
                    const t = e.closest("[data-hovercard-subject-tag]");
                    if (t) return t.getAttribute("data-hovercard-subject-tag");
                    const n = document.head && document.head.querySelector('meta[name="hovercard-subject-tag"]');
                    return n ? n.getAttribute("content") : null
                }
                s(fi, "determineEnclosingSubject");

                function mi(e) {
                    const t = e.getAttribute("data-hovercard-url");
                    if (t) {
                        const n = fi(e);
                        if (n) {
                            const o = new URL(t, window.location.origin),
                                r = new URLSearchParams(o.search.slice(1));
                            return r.append("subject", n), r.append("current_path", window.location.pathname + window.location.search), o.search = r.toString(), o.toString()
                        }
                        return t
                    }
                    return ""
                }
                s(mi, "hovercardUrlFromTarget");

                function pi(e) {
                    const t = e.getAttribute("data-hovercard-type");
                    return t === "pull_request" || t === "issue" ? !!e.closest("[data-issue-and-pr-hovercards-enabled]") : t === "team" ? !!e.closest("[data-team-hovercards-enabled]") : t === "repository" ? !!e.closest("[data-repository-hovercards-enabled]") : t === "commit" ? !!e.closest("[data-commit-hovercards-enabled]") : t === "project" ? !!e.closest("[data-project-hovercards-enabled]") : t === "discussion" ? !!e.closest("[data-discussion-hovercards-enabled]") : t === "acv_badge" ? !!e.closest("[data-acv-badge-hovercards-enabled]") : t === "sponsors_listing" ? !!e.closest("[data-sponsors-listing-hovercards-enabled]") : !0
                }
                s(pi, "hovercardsAreEnabledForType");
                async function hi(e, t) {
                    if ("ontouchstart" in document) return;
                    const o = e.currentTarget;
                    if (e instanceof MouseEvent && (nn = e.clientX), !(o instanceof Element) || Le === o || o.closest(".js-hovercard-content") || !pi(o)) return;
                    De(), Le = o, ct = document.activeElement;
                    const r = mi(o);
                    let i;
                    try {
                        const a = new Promise(c => window.setTimeout(c, t, 0));
                        i = await ri(document, r), await a
                    } catch (a) {
                        const c = a.response;
                        if (c && c.status === 404) {
                            const m = "Hovercard is unavailable";
                            o.setAttribute("aria-label", m), o.classList.add("tooltipped", "tooltipped-ne")
                        } else if (c && c.status === 410) {
                            const m = await c.clone().json();
                            o.setAttribute("aria-label", m.message), o.classList.add("tooltipped", "tooltipped-ne")
                        }
                        return
                    }
                    o === Le && (di(i, o), e instanceof KeyboardEvent && Z instanceof HTMLElement && Z.focus())
                }
                s(hi, "activateFn");

                function gi(e) {
                    hi(e, ii)
                }
                s(gi, "activateWithTimeoutFn");

                function sn(e) {
                    if (!!Le) {
                        if (e instanceof MouseEvent && e.relatedTarget instanceof HTMLElement) {
                            const t = e.relatedTarget;
                            if (t.closest(".js-hovercard-content") || t.closest("[data-hovercard-url]")) return
                        } else e instanceof KeyboardEvent && ct instanceof HTMLElement && ct.focus();
                        De()
                    }
                }
                s(sn, "deactivateFn");

                function bi(e) {
                    const t = Le;
                    tn = window.setTimeout(() => {
                        Le === t && sn(e)
                    }, si)
                }
                s(bi, "deactivateWithTimeoutFn");

                function ko(e) {
                    if (e instanceof KeyboardEvent) switch (e.key) {
                        case "Escape":
                            sn(e)
                    }
                }
                s(ko, "keyupFn");

                function yi() {
                    tn && clearTimeout(tn)
                }
                s(yi, "cancelDeactivation"), Z && ((0, d.N7)("[data-hovercard-url]", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "mouseover", gi), (0, x.RB)(e, "mouseleave", bi), (0, x.RB)(e, "keyup", ko))
                }), (0, d.N7)("[data-hovercard-url]", {
                    remove(e) {
                        Le === e && De()
                    }
                }), (0, d.N7)(".js-hovercard-content", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "mouseover", yi), (0, x.RB)(e, "mouseleave", sn), (0, x.RB)(e, "keyup", ko))
                }), (0, l.on)("menu:activated", "details", De), window.addEventListener("turbo:load", De), window.addEventListener("statechange", De));

                function vi(e, t) {
                    const n = e.getAttribute("data-hovercard-z-index-override");
                    n ? t.style.zIndex = n : t.style.zIndex = "100"
                }
                s(vi, "setZIndexOverride");
                var pe = u(31756);
                (async function() {
                    document.addEventListener("pjax:complete", () => (0, k.Y)({
                        pjax: "true"
                    })), (0, pe.c)("TURBO") ? document.addEventListener("turbo:load", () => (0, k.Y)({
                        turbo: "true"
                    })) : (await fe.C, (0, k.Y)())
                })(), (0, l.on)("click", "[data-octo-click]", function(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLElement)) return;
                    const n = t.getAttribute("data-octo-click") || "",
                        o = {};
                    if (t.hasAttribute("data-ga-click")) {
                        const i = t.getAttribute("data-ga-click").split(",");
                        o.category = i[0].trim(), o.action = i[1].trim()
                    }
                    if (t.hasAttribute("data-octo-dimensions")) {
                        const r = t.getAttribute("data-octo-dimensions").split(",");
                        for (const i of r) {
                            const [a, c] = i.split(/:(.+)/);
                            a && (o[a] = c || "")
                        }
                    }(0, k.q)(n, o)
                }), (0, l.on)("click", "[data-hydro-click]", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-hydro-click") || "",
                        o = t.getAttribute("data-hydro-click-hmac") || "",
                        r = t.getAttribute("data-hydro-client-context") || "";
                    (0, en.$S)(n, o, r)
                }), (0, l.on)("click", "[data-optimizely-hydro-click]", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-optimizely-hydro-click") || "",
                        o = t.getAttribute("data-optimizely-hydro-click-hmac") || "";
                    (0, en.$S)(n, o, "")
                }), (0, T.AC)(".js-immediate-updates", async function(e, t) {
                    let n;
                    try {
                        n = (await t.json()).json.updateContent
                    } catch (o) {
                        o.response.json && (n = o.response.json.updateContent)
                    }
                    if (n)
                        for (const o in n) {
                            const r = n[o],
                                i = document.querySelector(o);
                            i instanceof HTMLElement && (0, Ae.Of)(i, r)
                        }
                }), (0, d.N7)("[data-indeterminate]", {
                    constructor: HTMLInputElement,
                    initialize(e) {
                        e.indeterminate = !0
                    }
                });
                var wi = u(75552);

                function Ei() {
                    u.e(3754).then(u.bind(u, 23754))
                }
                s(Ei, "load"), (0, d.N7)(".js-jump-to-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        e.addEventListener("focusin", Ei, {
                            once: !0
                        }), (0, wi.Nc)(window.location.pathname)
                    }
                });
                var an = u(11793);
                let cn = !1;
                async function xo() {
                    if (cn) return;
                    cn = !0;
                    const t = {
                            contexts: document.querySelector("meta[name=github-keyboard-shortcuts]").content
                        },
                        n = `/site/keyboard_shortcuts?${new URLSearchParams(t).toString()}`,
                        o = await (0, we.W)({
                            content: (0, ce.a)(document, n),
                            labelledBy: "keyboard-shortcuts-heading"
                        });
                    o.style.width = "800px", o.addEventListener("dialog:remove", function() {
                        cn = !1
                    }, {
                        once: !0
                    })
                }
                s(xo, "showKeyboardShortcuts"), (0, l.on)("click", ".js-keyboard-shortcuts", xo), document.addEventListener("keydown", e => {
                    e instanceof KeyboardEvent && (!(0, Yn.Zf)(e) || e.target instanceof Node && (0, f.sw)(e.target) || (0, an.EL)(e) === "Shift+?" && xo())
                }), (0, d.N7)(".js-modifier-key", {
                    constructor: HTMLElement,
                    add(e) {
                        if (/Macintosh/.test(navigator.userAgent)) {
                            let t = e.textContent;
                            t && (t = t.replace(/ctrl/, "\u2318"), t = t.replace(/alt/, "\u2325"), e.textContent = t)
                        }
                    }
                }), (0, d.N7)(".js-modifier-label-key", {
                    add(e) {
                        var t;
                        let n = (t = e.textContent) == null ? void 0 : t.replace(/ctrl/i, "Ctrl");
                        !n || (/Macintosh/.test(navigator.userAgent) && (n = n.replace(/ctrl/i, "Cmd"), n = n.replace(/alt/i, "Option")), e.textContent = n)
                    }
                });

                function lt(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement)) return;
                    const n = parseInt(t.getAttribute("data-input-max-length") || "", 10),
                        o = parseInt(t.getAttribute("data-warning-length") || "", 10) || 5,
                        i = t.value.replace(/(\r\n|\n|\r)/g, `\r
`);
                    let a = n - i.length;
                    if (a <= 0) {
                        let S = i.substr(0, n);
                        S.endsWith("\r") ? (S = S.substr(0, n - 1), a = 1) : a = 0, t.value = S
                    }
                    const c = t.getAttribute("data-warning-text"),
                        p = t.closest(".js-length-limited-input-container").querySelector(".js-length-limited-input-warning");
                    a <= o ? (p.textContent = c.replace(new RegExp("{{remaining}}", "g"), `${a}`), p.classList.remove("d-none")) : (p.textContent = "", p.classList.add("d-none"))
                }
                s(lt, "displayLengthWarning"), (0, d.N7)(".js-length-limited-input", {
                    add(e) {
                        e.addEventListener("input", lt), e.addEventListener("change", lt)
                    },
                    remove(e) {
                        e.removeEventListener("input", lt), e.removeEventListener("change", lt)
                    }
                }), (0, d.N7)("link[rel=prefetch-viewed]", {
                    initialize() {
                        window.requestIdleCallback(() => {
                            fetch(location.href, {
                                method: "HEAD",
                                credentials: "same-origin",
                                headers: {
                                    Purpose: "prefetch-viewed"
                                }
                            })
                        })
                    }
                }), (0, l.on)("click", ".js-member-search-filter", function(e) {
                    e.preventDefault();
                    const t = e.currentTarget.getAttribute("data-filter"),
                        o = e.currentTarget.closest("[data-filter-on]").getAttribute("data-filter-on"),
                        r = document.querySelector(".js-member-filter-field"),
                        i = r.value,
                        a = new RegExp(`${o}:(?:[a-z]|_|((').*(')))+`),
                        c = i.toString().trim().replace(a, "");
                    r.value = `${c} ${t}`.replace(/\s\s/, " ").trim(), r.focus(), (0, l.f)(r, "input")
                }), (0, l.on)("auto-check-success", ".js-new-organization-name", function(e) {
                    const t = e.target,
                        o = t.closest("dd").querySelector(".js-field-hint-name");
                    !o || (o.textContent = t.value)
                }), (0, T.AC)(".js-notice-dismiss", async function(e, t) {
                    await t.text(), e.closest(".js-notice").remove()
                }), (0, l.on)("submit", ".js-notice-dismiss-remote", async function(e) {
                    const t = e.currentTarget;
                    e.preventDefault();
                    let n;
                    try {
                        n = await fetch(t.action, {
                            method: t.method,
                            body: new FormData(t),
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })
                    } catch {
                        (0, w.v)();
                        return
                    }
                    n && !n.ok ? (0, w.v)() : t.closest(".js-notice").remove()
                });

                function Li(e) {
                    try {
                        const t = e.getBoundingClientRect();
                        if (t.height === 0 && t.width === 0 || e.style.opacity === "0" || e.style.visibility === "hidden") return !1
                    } catch {}
                    return !0
                }
                s(Li, "isVisible"), (0, l.on)("click", ".js-github-dev-shortcut", function(e) {
                    e.preventDefault();
                    for (const n of document.querySelectorAll("textarea.js-comment-field"))
                        if (n.value && Li(n) && !confirm("Are you sure you want to open github.dev?")) return;
                    const t = e.currentTarget;
                    t.pathname = window.location.pathname, t.hash = window.location.hash, window.location.href = t.href
                }), (0, l.on)("click", ".js-github-dev-new-tab-shortcut", function(e) {
                    const t = e.currentTarget;
                    t.pathname = window.location.pathname, t.hash = window.location.hash
                });

                function Si(e, t, n) {
                    const o = new URL("", window.location.origin),
                        r = t.pathname.split("/");
                    o.pathname = r.slice(1, 3).join("/"), o.hash = t.hash, n && (o.search = `?q=${encodeURIComponent(n)}`);
                    const a = new URLSearchParams(t.search).get("q");
                    return a ? o.search = `?q=${encodeURIComponent(a)}` : r.length >= 6 && (r[3] === "blob" || r[3] === "tree") && (o.pathname = t.pathname), o.host = e.host, o.protocol = e.protocol, o.port = e.port, o
                }
                s(Si, "getBlackbirdURL"), (0, l.on)("click", ".js-blackbird-shortcut", function(e) {
                    var t;
                    const n = e.currentTarget,
                        o = Si(n, new URL(window.location.href, window.location.origin), (t = window.getSelection()) == null ? void 0 : t.toString());
                    n.href = o.href
                }), (0, l.on)("click", ".js-permalink-shortcut", function(e) {
                    const t = e.currentTarget;
                    try {
                        (0, R.lO)(null, "", t.href + window.location.hash)
                    } catch {
                        window.location.href = t.href + window.location.hash
                    }
                    for (const n of document.querySelectorAll(".js-permalink-replaceable-link")) n instanceof HTMLAnchorElement && (n.href = n.getAttribute("data-permalink-href"));
                    e.preventDefault()
                }), (0, T.AC)(".js-permission-menu-form", async function(e, t) {
                    const n = e.querySelector(".js-permission-success"),
                        o = e.querySelector(".js-permission-error");
                    n.hidden = !0, o.hidden = !0, e.classList.add("is-loading");
                    let r;
                    try {
                        r = await t.json()
                    } catch {
                        e.classList.remove("is-loading"), o.hidden = !1;
                        return
                    }
                    e.classList.remove("is-loading"), n.hidden = !1;
                    const i = e.closest(".js-org-repo");
                    if (i) {
                        const a = r.json;
                        i.classList.toggle("with-higher-access", a.members_with_higher_access)
                    }
                }), async function() {
                    await fe.x;
                    const e = document.querySelector(".js-pjax-loader-bar");
                    if (!e) return;
                    const t = e.firstElementChild;
                    if (!(t instanceof HTMLElement)) return;
                    let n = 0,
                        o = null,
                        r = null;

                    function i() {
                        a(0), e && e.classList.add("is-loading"), o = window.setTimeout(c, 0)
                    }
                    s(i, "initiateLoader");

                    function a(p) {
                        t instanceof HTMLElement && (p === 0 && (r == null && (r = getComputedStyle(t).transition), t.style.transition = "none"), n = p, t.style.width = `${n}%`, p === 0 && (t.clientWidth, t.style.transition = r || ""))
                    }
                    s(a, "setWidth");

                    function c() {
                        n === 0 && (n = 12), a(Math.min(n + 3, 95)), o = window.setTimeout(c, 500)
                    }
                    s(c, "increment");

                    function m() {
                        o && clearTimeout(o), a(100), e && e.classList.remove("is-loading")
                    }
                    s(m, "finishLoader"), document.addEventListener("pjax:start", i), document.addEventListener("pjax:end", m)
                }();
                let ln = null;
                const un = "last_pjax_request",
                    ut = "pjax_start",
                    dn = "pjax_end";

                function ji(e) {
                    e instanceof CustomEvent && e.detail && e.detail.url && (window.performance.mark(ut), ln = e.detail.url)
                }
                s(ji, "markPjaxStart");
                async function Ti() {
                    if (await (0, $.gJ)(), !window.performance.getEntriesByName(ut).length) return;
                    window.performance.mark(dn), window.performance.measure(un, ut, dn);
                    const t = window.performance.getEntriesByName(un).pop(),
                        n = t ? t.duration : null;
                    !n || (ln && (0, me.b)({
                        requestUrl: ln,
                        pjaxDuration: Math.round(n)
                    }), Ai())
                }
                s(Ti, "trackPjaxTiming");

                function Ai() {
                    window.performance.clearMarks(ut), window.performance.clearMarks(dn), window.performance.clearMeasures(un)
                }
                s(Ai, "clearPjaxMarks"), "getEntriesByName" in window.performance && (document.addEventListener("pjax:start", ji), document.addEventListener("pjax:end", Ti));
                let fn = null;
                const mn = "last_turbo_request",
                    dt = "turbo_start",
                    pn = "turbo_end";

                function Ci(e) {
                    var t;
                    e instanceof CustomEvent && (!((t = e.detail) == null ? void 0 : t.url) || (window.performance.mark(dt), fn = e.detail.url))
                }
                s(Ci, "markTurboStart");
                async function ki() {
                    if (await (0, $.gJ)(), !window.performance.getEntriesByName(dt).length) return;
                    window.performance.mark(pn), window.performance.measure(mn, dt, pn);
                    const t = window.performance.getEntriesByName(mn).pop(),
                        n = t ? t.duration : null;
                    !n || (fn && (0, me.b)({
                        requestUrl: fn,
                        turboDuration: Math.round(n)
                    }), xi())
                }
                s(ki, "trackTurboTiming");

                function xi() {
                    window.performance.clearMarks(dt), window.performance.clearMarks(pn), window.performance.clearMeasures(mn)
                }
                s(xi, "clearTurboMarks"), "getEntriesByName" in window.performance && (document.addEventListener("turbo:before-fetch-request", Ci), document.addEventListener("turbo:render", ki));
                var Bl = u(13728),
                    $l = u(76006);

                function Mi(e, t) {
                    const n = e.split("/", 3).join("/"),
                        o = t.split("/", 3).join("/");
                    return n === o
                }
                s(Mi, "isSameRepo"), (0, l.on)("pjax:click", "#js-repo-pjax-container a[href]", function(e) {
                    const t = e.currentTarget.pathname;
                    Mi(t, location.pathname) || e.preventDefault()
                }), (0, l.on)("pjax:click", ".js-comment-body", function(e) {
                    const t = e.target;
                    t instanceof HTMLAnchorElement && t.pathname.split("/")[3] === "files" && e.preventDefault()
                });
                var Fl = u(7143),
                    Ul = u(7796),
                    _l = u(15528),
                    ze = u(82762);
                (0, l.on)("click", "[data-pjax] a, a[data-pjax]", function(e) {
                    const t = e.currentTarget;
                    if (t instanceof HTMLAnchorElement) {
                        if (t.getAttribute("data-skip-pjax") != null || t.getAttribute("data-remote") != null) return;
                        const n = (0, ze.W)(t);
                        n && qi(e, {
                            container: n,
                            scrollTo: (0, ze.r)(t)
                        })
                    }
                }), (0, l.on)("change", "select[data-pjax]", function(e) {
                    if ((0, pe.c)("PJAX_DISABLED") || (0, pe.c)("TURBO")) return;
                    const t = e.currentTarget,
                        n = (0, ze.W)(t);
                    n && (0, te.ZP)({
                        url: t.value,
                        container: n
                    })
                });

                function qi(e, t) {
                    if ((0, pe.c)("PJAX_DISABLED") || (0, pe.c)("TURBO")) return;
                    const n = e.currentTarget;
                    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || location.protocol !== n.protocol || location.hostname !== n.hostname || n.href.indexOf("#") > -1 && Mo(n) === Mo(location) || e.defaultPrevented) return;
                    const o = {
                            url: n.href,
                            target: n,
                            ...t
                        },
                        r = new CustomEvent("pjax:click", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                options: o,
                                relatedEvent: e
                            }
                        });
                    n.dispatchEvent(r) && ((0, te.ZP)(o), e.preventDefault(), n.dispatchEvent(new CustomEvent("pjax:clicked", {
                        bubbles: !0,
                        cancelable: !0,
                        detail: {
                            options: o
                        }
                    })))
                }
                s(qi, "click");

                function Mo(e) {
                    return e.href.replace(/#.*/, "")
                }
                s(Mo, "stripHash"), (0, l.on)("submit", "form[data-pjax]", function(e) {
                    if ((0, pe.c)("PJAX_DISABLED") || (0, pe.c)("TURBO")) return;
                    const t = e.currentTarget,
                        n = (0, ze.W)(t);
                    if (!n) return;
                    const o = (0, ze.r)(t),
                        r = {
                            type: (t.method || "GET").toUpperCase(),
                            url: t.action,
                            target: t,
                            scrollTo: o,
                            container: n
                        };
                    if (r.type === "GET") {
                        if (t.querySelector("input[type=file]")) return;
                        const i = Ri(r.url);
                        i.search += (i.search ? "&" : "") + (0, f.qC)(t), r.url = i.toString()
                    } else r.data = new FormData(t);
                    (0, te.ZP)(r), e.preventDefault()
                });

                function Ri(e) {
                    const t = document.createElement("a");
                    return t.href = e, t
                }
                s(Ri, "parseURL"), (0, d.N7)("body.js-print-popup", () => {
                    window.print(), setTimeout(window.close, 1e3)
                }), (0, d.N7)("poll-include-fragment[data-redirect-url]", function(e) {
                    const t = e.getAttribute("data-redirect-url");
                    e.addEventListener("load", function() {
                        window.location.href = t
                    })
                }), (0, d.N7)("poll-include-fragment[data-reload]", function(e) {
                    e.addEventListener("load", function() {
                        window.location.reload()
                    })
                });
                var Pi = u(43452),
                    Ii = u(26360);
                const Di = "$__",
                    qo = document.querySelector("meta[name=js-proxy-site-detection-payload]"),
                    Ro = document.querySelector("meta[name=expected-hostname]");
                if (qo instanceof HTMLMetaElement && Ro instanceof HTMLMetaElement && (0, Pi.Z)(document)) {
                    const e = {
                            url: window.location.href,
                            expectedHostname: Ro.content,
                            documentHostname: document.location.hostname,
                            proxyPayload: qo.content
                        },
                        t = new Error,
                        n = {};
                    n[`${Di}`] = btoa(JSON.stringify(e)), (0, Ii.eK)(t, n)
                }(0, P.w4)("keydown", ".js-quick-submit", function(e) {
                    Ni(e)
                });

                function Ni(e) {
                    const t = e.target;
                    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
                        const n = t.form,
                            o = n.querySelector("input[type=submit], button[type=submit]");
                        if (e.shiftKey) {
                            const r = n.querySelector(".js-quick-submit-alternative");
                            (r instanceof HTMLInputElement || r instanceof HTMLButtonElement) && !r.disabled && (0, f.Bt)(n, r)
                        } else(o instanceof HTMLInputElement || o instanceof HTMLButtonElement) && o.disabled || (0, f.Bt)(n);
                        e.preventDefault()
                    }
                }
                s(Ni, "quickSubmit");
                var Po = u(55498);
                let ft;
                (0, d.N7)(".js-comment-quote-reply", function(e) {
                    var t;
                    e.hidden = ((t = e.closest(".js-quote-selection-container")) == null ? void 0 : t.querySelector(".js-inline-comment-form-container textarea, .js-new-comment-form textarea")) == null
                });

                function Io(e) {
                    return e.nodeName === "DIV" && e.classList.contains("highlight")
                }
                s(Io, "isHighlightContainer");

                function Oi(e) {
                    return e.nodeName === "IMG" || e.firstChild != null
                }
                s(Oi, "hasContent");
                const Do = {
                    PRE(e) {
                        const t = e.parentElement;
                        if (t && Io(t)) {
                            const n = t.className.match(/highlight-source-(\S+)/),
                                o = n ? n[1] : "",
                                r = (e.textContent || "").replace(/\n+$/, "");
                            e.textContent = `\`\`\`${o}
${r}
\`\`\``, e.append(`

`)
                        }
                        return e
                    },
                    A(e) {
                        const t = e.textContent || "";
                        return e.classList.contains("user-mention") || e.classList.contains("team-mention") || e.classList.contains("issue-link") && /^#\d+$/.test(t) ? t : e
                    },
                    IMG(e) {
                        const t = e.getAttribute("alt");
                        return t && e.classList.contains("emoji") ? t : e
                    },
                    DIV(e) {
                        if (e.classList.contains("js-suggested-changes-blob")) e.remove();
                        else if (e.classList.contains("blob-wrapper-embedded")) {
                            const t = e.parentElement,
                                n = t.querySelector("a[href]"),
                                o = document.createElement("p");
                            o.textContent = n.href, t.replaceWith(o)
                        }
                        return e
                    }
                };

                function Hi(e) {
                    const t = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT, {
                            acceptNode(r) {
                                return r.nodeName in Do && Oi(r) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                            }
                        }),
                        n = [];
                    let o = t.nextNode();
                    for (; o;) o instanceof HTMLElement && n.push(o), o = t.nextNode();
                    n.reverse();
                    for (const r of n) r.replaceWith(Do[r.nodeName](r))
                }
                s(Hi, "insertMarkdownSyntax"), (0, l.on)("click", ".js-comment-quote-reply", function({
                    isTrusted: e,
                    currentTarget: t
                }) {
                    const n = t.closest(".js-comment"),
                        o = n.querySelector(".js-comment-body"),
                        r = n.querySelector(".js-comment-body").cloneNode(!0),
                        i = n.closest(".js-quote-selection-container"),
                        a = o.querySelectorAll("button.js-convert-to-issue-button, span.js-clear");
                    for (const p of a) p.remove();
                    let c = new Po.p;
                    if (!e && c.range.collapsed || (i.hasAttribute("data-quote-markdown") && (c = new Po.I(i.getAttribute("data-quote-markdown") || "", p => {
                            const S = c.range.startContainer.parentElement,
                                q = S && S.closest("pre");
                            if (q instanceof HTMLElement) {
                                const O = q.parentElement;
                                if (O && Io(O)) {
                                    const B = document.createElement("div");
                                    B.className = O.className, B.appendChild(p), p.appendChild(B)
                                }
                            }
                            Hi(p)
                        })), ft && o.contains(ft.anchorNode) ? c.range = ft.range : c.range.collapsed && c.select(o), c.closest(".js-quote-selection-container") !== i)) return;
                    const m = c.range;
                    i.dispatchEvent(new CustomEvent("quote-selection", {
                        bubbles: !0,
                        detail: c
                    })), c.range = m;
                    for (const p of i.querySelectorAll("textarea"))
                        if ((0, Ye.Z)(p)) {
                            c.insert(p);
                            break
                        }
                    n.querySelector(".js-comment-body").replaceWith(r)
                });
                let hn;
                document.addEventListener("selectionchange", (0, U.D)(function() {
                    const e = window.getSelection();
                    let t;
                    try {
                        t = e.getRangeAt(0)
                    } catch {
                        hn = null;
                        return
                    }
                    hn = {
                        anchorNode: e.anchorNode,
                        range: t
                    }
                }, 100)), document.addEventListener("toggle", () => {
                    ft = hn
                }, {
                    capture: !0
                }), (0, T.AC)(".js-pick-reaction", async function(e, t) {
                    const n = await t.json(),
                        o = e.closest(".js-comment"),
                        r = o.querySelector(".js-reactions-container"),
                        i = o.querySelector(".js-comment-header-reaction-button"),
                        a = (0, L.r)(document, n.json.reactions_container.trim()),
                        c = (0, L.r)(document, n.json.comment_header_reaction_button.trim());
                    r.replaceWith(a), i.replaceWith(c)
                });

                function No(e) {
                    const t = e.target,
                        n = t.getAttribute("data-reaction-label"),
                        r = t.closest(".js-add-reaction-popover").querySelector(".js-reaction-description");
                    r.hasAttribute("data-default-text") || r.setAttribute("data-default-text", r.textContent || ""), r.textContent = n
                }
                s(No, "showReactionContent");

                function Oo(e) {
                    const n = e.target.closest(".js-add-reaction-popover").querySelector(".js-reaction-description"),
                        o = n.getAttribute("data-default-text");
                    o && (n.textContent = o)
                }
                s(Oo, "hideReactionContent"), (0, l.on)("toggle", ".js-reaction-popover-container", function(e) {
                    const t = e.currentTarget.hasAttribute("open");
                    for (const n of e.target.querySelectorAll(".js-reaction-option-item")) t ? (n.addEventListener("mouseenter", No), n.addEventListener("mouseleave", Oo)) : (n.removeEventListener("mouseenter", No), n.removeEventListener("mouseleave", Oo))
                }, {
                    capture: !0
                });
                var gn = u(90137),
                    Ho = u(85830);

                function Bi(e, t, n) {
                    e.getAttribute("data-type") === "json" && n.headers.set("Accept", "application/json"), (0, l.f)(e, "deprecatedAjaxSend", {
                        request: n
                    }), t.text().catch(r => {
                        if (r.response) return r.response;
                        throw r
                    }).then(r => {
                        r.status < 300 ? (0, l.f)(e, "deprecatedAjaxSuccess") : (0, l.f)(e, "deprecatedAjaxError", {
                            error: r.statusText,
                            status: r.status,
                            text: r.text
                        })
                    }, r => {
                        (0, l.f)(e, "deprecatedAjaxError", {
                            error: r.message,
                            status: 0,
                            text: null
                        })
                    }).then(() => {
                        (0, l.f)(e, "deprecatedAjaxComplete")
                    })
                }
                s(Bi, "submitWithLegacyEvents"), (0, l.on)("click", ["form button:not([type])", "form button[type=submit]", "form input[type=submit]"].join(", "), function(e) {
                    const t = e.currentTarget;
                    t.form && !e.defaultPrevented && (0, gn.j)(t)
                }), (0, T.AC)("form[data-remote]", Bi), (0, l.on)("deprecatedAjaxComplete", "form", function({
                    currentTarget: e
                }) {
                    const t = (0, gn.u)(e);
                    t && t.remove()
                }), (0, T.uT)(e => {
                    const t = (0, gn.u)(e);
                    t && t.remove()
                }), (0, T.rK)(Ho.Z), (0, d.N7)(".has-removed-contents", function() {
                    let e;
                    return {
                        add(t) {
                            e = Array.from(t.childNodes);
                            for (const o of e) t.removeChild(o);
                            const n = t.closest("form");
                            n && (0, l.f)(n, "change")
                        },
                        remove(t) {
                            for (const o of e) t.appendChild(o);
                            const n = t.closest("form");
                            n && (0, l.f)(n, "change")
                        }
                    }
                });
                var se = u(36162),
                    $i = (e => (e.Auto = "auto", e.Light = "light", e.Dark = "dark", e))($i || {});

                function Fi() {
                    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
                }
                s(Fi, "getUserSystemColorMode");
                const bn = ".js-render-plaintext";

                function Ui(e) {
                    const t = e.closest(".js-render-needs-enrichment");
                    if (!t) return;
                    t.querySelector(bn) && yn(t, !1)
                }
                s(Ui, "markdownEnrichmentSuccess");

                function _i(e, t) {
                    yn(e, !1), Bo(e, !0), e.classList.add("render-error");
                    const n = e.querySelector(bn);
                    if (!n) return;
                    n.classList.remove("render-plaintext-hidden");
                    const o = n.querySelector("pre");
                    (0, se.sY)(se.dy `${t} ${o}`, n)
                }
                s(_i, "showMarkdownRenderError");

                function yn(e, t) {
                    const n = e.getElementsByClassName("js-render-enrichment-loader")[0],
                        o = e.getElementsByClassName("render-expand")[0];
                    n && (n.hidden = !t), o && (o.hidden = t)
                }
                s(yn, "setCodeBlockLoaderVisibility");

                function Bo(e, t) {
                    const n = e.querySelector(bn);
                    t ? n.classList.remove("render-plaintext-hidden") : n.classList.add("render-plaintext-hidden")
                }
                s(Bo, "setRawCodeBlockVisibility");
                class $o {
                    constructor(t) {
                        this.el = t, this.enrichmentTarget = t.getElementsByClassName("js-render-enrichment-target")[0], this.iframeUrl = this.getIframeUrl(), this.identifier = this.el.getAttribute("data-identity"), this.iframeContentType = this.el.getAttribute("data-type"), this.iframeOrigin = new URL(this.iframeUrl, window.location.origin).origin, this.iframeContent = this.el.getAttribute("data-content"), yn(this.el, !0)
                    }
                    enrich() {
                        const t = this.createDialog();
                        (0, se.sY)(t, this.enrichmentTarget), this.setupModal()
                    }
                    getIframeUrl() {
                        const t = this.el.getAttribute("data-src"),
                            n = { ...this.colorMode()
                            },
                            o = Object.entries(n).map(([r, i]) => `${r}=${i}`).join("&");
                        return `${t}?${o}`
                    }
                    colorMode() {
                        var t;
                        let n = (t = document.querySelector("html")) == null ? void 0 : t.getAttribute("data-color-mode");
                        return (n === "auto" || !n) && (n = Fi()), {
                            color_mode: n
                        }
                    }
                    setupModal() {
                        const t = this.generateIframeCode("-fullscreen"),
                            n = this.el.querySelector(".Box-body");
                        this.el.querySelector(".js-full-screen-render").addEventListener("click", () => {
                            (0, se.sY)(t, n)
                        })
                    }
                    createDialog() {
                        const t = this.generateIframeCode();
                        return se.dy ` <div class="d-flex flex-column flex-auto js-render-box">
      <details class="details-reset details-overlay details-overlay-dark">
        <summary class="btn-sm btn position-absolute js-full-screen-render render-expand" aria-haspopup="dialog" hidden>
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="currentColor"
            class="octicon"
            style="display:inline-block;vertical-align:text-bottom"
          >
            <path
              fill-rule="evenodd"
              d="M3.72 3.72a.75.75 0 011.06 1.06L2.56 7h10.88l-2.22-2.22a.75.75 0 011.06-1.06l3.5 3.5a.75.75 0 010 1.06l-3.5 3.5a.75.75 0 11-1.06-1.06l2.22-2.22H2.56l2.22 2.22a.75.75 0 11-1.06 1.06l-3.5-3.5a.75.75 0 010-1.06l3.5-3.5z"
            ></path>
          </svg>
        </summary>
        <details-dialog class="Box Box--overlay render-full-screen d-flex flex-column anim-fade-in fast">
          <div>
            <button
              aria-label="Close dialog"
              data-close-dialog=""
              type="button"
              data-view-component="true"
              class="Link--muted btn-link position-absolute render-full-screen-close"
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="currentColor"
                style="display:inline-block;vertical-align:text-bottom"
                class="octicon octicon-x"
              >
                <path
                  fill-rule="evenodd"
                  d="M5.72 5.72a.75.75 0 011.06 0L12 10.94l5.22-5.22a.75.75 0 111.06 1.06L13.06 12l5.22 5.22a.75.75 0 11-1.06 1.06L12 13.06l-5.22 5.22a.75.75 0 01-1.06-1.06L10.94 12 5.72 6.78a.75.75 0 010-1.06z"
                ></path>
              </svg>
            </button>
            <div class="Box-body"></div>
          </div>
        </details-dialog>
      </details>
      ${t}
    </div>`
                    }
                    generateIframeCode(t = "") {
                        const n = this.identifier + t,
                            o = `${this.iframeUrl}#${n}`;
                        return se.dy `
      <div
        class="render-container js-render-target p-0"
        data-identity="${n}"
        data-host="${this.iframeOrigin}"
        data-type="${this.iframeContentType}"
      >
        <iframe
          class="render-viewer"
          src="${o}"
          name="${n}"
          data-content="${this.iframeContent}"
          sandbox="allow-scripts allow-same-origin allow-top-navigation"
        >
        </iframe>
      </div>
    `
                    }
                }
                s($o, "EnrichableMarkdownRenderer"), (0, d.N7)(".js-render-needs-enrichment", function(e) {
                    const t = e;
                    new $o(t).enrich()
                }), (0, l.on)("preview:toggle:off", ".js-previewable-comment-form", function(e) {
                    const n = e.currentTarget.querySelector(".js-render-needs-enrichment"),
                        o = n == null ? void 0 : n.querySelector(".js-render-enrichment-target");
                    !o || (o.innerHTML = "")
                }), (0, l.on)("preview:rendered", ".js-previewable-comment-form", function(e) {
                    const n = e.currentTarget.querySelector(".js-render-needs-enrichment");
                    n && Bo(n, !1)
                });
                const Wl = null,
                    mt = ["is-render-pending", "is-render-ready", "is-render-loading", "is-render-loaded"],
                    Wi = ["is-render-ready", "is-render-loading", "is-render-loaded", "is-render-failed", "is-render-failed-fatally"],
                    Ne = new WeakMap;

                function Fo(e) {
                    const t = Ne.get(e);
                    t != null && (t.load = t.hello = null, t.helloTimer && (clearTimeout(t.helloTimer), t.helloTimer = null), t.loadTimer && (clearTimeout(t.loadTimer), t.loadTimer = null))
                }
                s(Fo, "resetTiming");

                function Ke(e, t = "") {
                    var n;
                    e.classList.remove(...mt), e.classList.add("is-render-failed");
                    const o = Ki(t),
                        r = (n = e.parentElement) == null ? void 0 : n.closest(".js-render-needs-enrichment");
                    r ? _i(r, o) : zi(e, o), Fo(e)
                }
                s(Ke, "renderFailed");

                function zi(e, t) {
                    const n = e.querySelector(".render-viewer-error");
                    n && (n.remove(), e.classList.remove("render-container"), (0, se.sY)(t, e))
                }
                s(zi, "fileRenderError");

                function Ki(e) {
                    let t = se.dy `<p>Unable to render code block</p>`;
                    if (e !== "") {
                        const n = e.split(`
`);
                        t = se.dy `<p><b>Error rendering embedded code</b></p>
      <p>${n.map(o=>se.dy`${o}<br />`)}</p>`
                    }
                    return se.dy `<div class="flash flash-error">${t}</div>`
                }
                s(Ki, "renderError");

                function Uo(e, t = !1) {
                    var n;
                    !(0, Ye.Z)(e) || e.classList.contains("is-render-ready") || e.classList.contains("is-render-failed") || e.classList.contains("is-render-failed-fatally") || t && !((n = Ne.get(e)) == null ? void 0 : n.hello) || Ke(e)
                }
                s(Uo, "timeoutWatchdog"), (0, d.N7)(".js-render-target", function(e) {
                    var t;
                    const n = e;
                    n.classList.remove(...Wi), n.style.height = "auto", !((t = Ne.get(e)) == null ? void 0 : t.load) && (Fo(e), !Ne.get(e) && (Ne.set(e, {
                        load: Date.now(),
                        hello: null,
                        helloTimer: window.setTimeout(Uo, 1e4, e, !0),
                        loadTimer: window.setTimeout(Uo, 45e3, e)
                    }), e.classList.add("is-render-automatic", "is-render-requested")))
                });

                function pt(e, t) {
                    e && e.postMessage && e.postMessage(JSON.stringify(t), "*")
                }
                s(pt, "postAsJson");

                function Vi(e) {
                    let t = e.data;
                    if (!t) return;
                    if (typeof t == "string") try {
                        t = JSON.parse(t)
                    } catch {
                        return
                    }
                    if (t.type !== "render" || typeof t.identity != "string") return;
                    const n = t.identity;
                    if (typeof t.body != "string") return;
                    const o = t.body;
                    let r = null;
                    for (const p of document.querySelectorAll(".js-render-target"))
                        if (p.getAttribute("data-identity") === n) {
                            r = p;
                            break
                        }
                    if (!r || e.origin !== r.getAttribute("data-host")) return;
                    const i = t.payload != null ? t.payload : void 0,
                        a = r.querySelector("iframe"),
                        c = a == null ? void 0 : a.contentWindow;

                    function m() {
                        const p = a == null ? void 0 : a.getAttribute("data-content");
                        if (!p) return;
                        const S = {
                            type: "render:cmd",
                            body: {
                                cmd: "code_rendering_service:data:ready",
                                "code_rendering_service:data:ready": {
                                    data: JSON.parse(p).data,
                                    width: r == null ? void 0 : r.getBoundingClientRect().width
                                }
                            }
                        };
                        pt(c, S)
                    }
                    switch (s(m, "postData"), o) {
                        case "hello":
                            {
                                const p = Ne.get(r) || {
                                    untimed: !0
                                };p.hello = Date.now();
                                const S = {
                                        type: "render:cmd",
                                        body: {
                                            cmd: "ack",
                                            ack: !0
                                        }
                                    },
                                    q = {
                                        type: "render:cmd",
                                        body: {
                                            cmd: "branding",
                                            branding: !1
                                        }
                                    };
                                if (!c) return;pt(c, S),
                                pt(c, q)
                            }
                            break;
                        case "error":
                            i ? Ke(r, i.error) : Ke(r);
                            break;
                        case "error:fatal":
                            {
                                Ke(r),
                                r.classList.add("is-render-failed-fatal");
                                break
                            }
                        case "error:invalid":
                            Ke(r), r.classList.add("is-render-failed-invalid");
                            break;
                        case "loading":
                            r.classList.remove(...mt), r.classList.add("is-render-loading");
                            break;
                        case "loaded":
                            r.classList.remove(...mt), r.classList.add("is-render-loaded");
                            break;
                        case "ready":
                            Ui(r), r.classList.remove(...mt), r.classList.add("is-render-ready"), i && typeof i.height == "number" && (r.style.height = `${i.height}px`, location.hash !== "" && window.dispatchEvent(new HashChangeEvent("hashchange")));
                            break;
                        case "resize":
                            i && typeof i.height == "number" && (r.style.height = `${i.height}px`);
                            break;
                        case "code_rendering_service:container:get_size":
                            pt(c, {
                                type: "render:cmd",
                                body: {
                                    cmd: "code_rendering_service:container:size",
                                    "code_rendering_service:container:size": {
                                        width: r == null ? void 0 : r.getBoundingClientRect().width
                                    }
                                }
                            });
                            break;
                        case "code_rendering_service:markdown:get_data":
                            if (!c) return;
                            m();
                            break;
                        default:
                            break
                    }
                }
                s(Vi, "handleMessage"), window.addEventListener("message", Vi), (0, T.AC)("form[data-replace-remote-form]", async function(e, t) {
                    e.classList.remove("is-error"), e.classList.add("is-loading");
                    try {
                        let n = e;
                        const o = await t.html(),
                            r = e.closest("[data-replace-remote-form-target]");
                        if (r) {
                            const i = r.getAttribute("data-replace-remote-form-target");
                            n = i ? document.getElementById(i) : r
                        }
                        n.replaceWith(o.html)
                    } catch {
                        e.classList.remove("is-loading"), e.classList.add("is-error")
                    }
                }), PerformanceObserver && (PerformanceObserver.supportedEntryTypes || []).includes("longtask") && new PerformanceObserver(function(t) {
                    const n = t.getEntries().map(({
                        name: o,
                        duration: r
                    }) => ({
                        name: o,
                        duration: r,
                        url: window.location.href
                    }));
                    (0, me.b)({
                        longTasks: n
                    })
                }).observe({
                    entryTypes: ["longtask"]
                });
                const _o = new WeakMap;

                function Xi(e) {
                    return e.closest("markdown-toolbar").field
                }
                s(Xi, "getTextarea"), (0, l.on)("click", ".js-markdown-link-button", async function({
                    currentTarget: e
                }) {
                    const n = document.querySelector(".js-markdown-link-dialog").content.cloneNode(!0);
                    if (!(n instanceof DocumentFragment)) return;
                    const o = await (0, we.W)({
                        content: n,
                        labelledBy: "box-title"
                    });
                    e instanceof HTMLElement && _o.set(o, Xi(e).selectionEnd)
                }), (0, l.on)("click", ".js-markdown-link-insert", ({
                    currentTarget: e
                }) => {
                    const t = e.closest("details-dialog"),
                        n = document.querySelector(`#${e.getAttribute("data-for-textarea")}`),
                        o = _o.get(t) || 0,
                        r = t.querySelector("#js-dialog-link-href").value,
                        a = `[${t.querySelector("#js-dialog-link-text").value}](${r}) `,
                        c = n.value.slice(0, o),
                        m = n.value.slice(o);
                    n.value = c + a + m, n.focus(), n.selectionStart = n.selectionEnd = o + a.length
                });
                var zl = u(23651);
                (0, l.on)("details-menu-select", ".js-saved-reply-menu", function(e) {
                    if (!(e.target instanceof Element)) return;
                    const t = e.detail.relatedTarget.querySelector(".js-saved-reply-body");
                    if (!t) return;
                    const n = (t.textContent || "").trim(),
                        r = e.target.closest(".js-previewable-comment-form").querySelector("textarea.js-comment-field");
                    (0, be.Om)(r, n), setTimeout(() => r.focus(), 0)
                }, {
                    capture: !0
                }), (0, P.w4)("keydown", ".js-saved-reply-shortcut-comment-field", function(e) {
                    (0, an.EL)(e) === "Control+." && (e.target.closest(".js-previewable-comment-form").querySelector(".js-saved-reply-container").setAttribute("open", ""), e.preventDefault())
                }), (0, P.w4)("keydown", ".js-saved-reply-filter-input", function(e) {
                    if (/^Control\+[1-9]$/.test((0, an.EL)(e))) {
                        const n = e.target.closest(".js-saved-reply-container").querySelectorAll('[role="menuitem"]'),
                            o = Number(e.key),
                            r = n[o - 1];
                        r instanceof HTMLElement && (r.click(), e.preventDefault())
                    } else if (e.key === "Enter") {
                        const n = e.target.closest(".js-saved-reply-container").querySelectorAll('[role="menuitem"]');
                        n.length > 0 && n[0] instanceof HTMLButtonElement && n[0].click(), e.preventDefault()
                    }
                });
                var Gi = u(6216),
                    Zi = u(11178);

                function Ji(e, t) {
                    return e.querySelector(`#LC${t}`)
                }
                s(Ji, "queryLineElement");

                function ht(e, t, n, o) {
                    const r = (0, Gi.M9)(e, c => Ji(t, c));
                    if (!r) return;
                    if (n) {
                        const c = (0, be.yb)(r.startContainer.textContent, r.startOffset);
                        if (c === -1) return;
                        r.setStart(r.startContainer, c)
                    }
                    if (o) {
                        const c = (0, be.yb)(r.endContainer.textContent, r.endOffset);
                        if (c === -1) return;
                        r.setEnd(r.endContainer, c)
                    }
                    const i = document.createElement("span"),
                        a = ["text-bold", "hx_keyword-hl", "rounded-2", "d-inline-block"];
                    i.classList.add(...a), (0, Zi.v)(r, i)
                }
                s(ht, "highlightRange");

                function Yi(e, t) {
                    if (e.start.line !== e.end.line) {
                        const n = {
                            start: {
                                line: e.start.line,
                                column: e.start.column
                            },
                            end: {
                                line: e.start.line,
                                column: null
                            }
                        };
                        ht(n, t, !0, !1);
                        for (let r = e.start.line + 1; r < e.end.line; r += 1) ht({
                            start: {
                                line: r,
                                column: 0
                            },
                            end: {
                                line: r,
                                column: null
                            }
                        }, t, !1, !1);
                        const o = {
                            start: {
                                line: e.end.line,
                                column: 0
                            },
                            end: {
                                line: e.end.line,
                                column: e.end.column
                            }
                        };
                        ht(o, t, !1, !0)
                    } else ht(e, t, !0, !0)
                }
                s(Yi, "highlightColumns");

                function Qi(e) {
                    const t = parseInt(e.getAttribute("data-start-line")),
                        n = parseInt(e.getAttribute("data-end-line")),
                        o = parseInt(e.getAttribute("data-start-column")),
                        r = parseInt(e.getAttribute("data-end-column"));
                    return t === n && o === r ? null : {
                        start: {
                            line: t,
                            column: o
                        },
                        end: {
                            line: n,
                            column: r !== 0 ? r : null
                        }
                    }
                }
                s(Qi, "parseColumnHighlightRange"), (0, d.N7)(".js-highlight-code-snippet-columns", function(e) {
                    const t = Qi(e);
                    t !== null && Yi(t, e)
                }), (0, l.on)("click", ".js-segmented-nav-button", function(e) {
                    e.preventDefault();
                    const t = e.currentTarget,
                        n = t.getAttribute("data-selected-tab"),
                        o = t.closest(".js-segmented-nav"),
                        r = o.parentElement;
                    for (const i of o.querySelectorAll(".js-segmented-nav-button")) i.classList.remove("selected");
                    t.classList.add("selected");
                    for (const i of r.querySelectorAll(".js-selected-nav-tab")) i.parentElement === r && i.classList.remove("active");
                    document.querySelector(`.${n}`).classList.add("active")
                });
                var Se = u(407),
                    je = u(47437);
                const ea = (0, U.D)(function() {
                    (0, Se.e6)((0, je.e)())
                }, 50);

                function ta() {
                    var e, t;
                    return (t = (e = document.querySelector("html")) == null ? void 0 : e.hasAttribute("data-turbo-preview")) != null ? t : !1
                }
                s(ta, "isTurboRenderingCachePreview"), window.addEventListener("submit", Se.iO, {
                    capture: !0
                }), window.addEventListener("pageshow", function() {
                    (0, Se.e6)((0, je.e)())
                }), window.addEventListener("pjax:end", function() {
                    (0, Se.e6)((0, je.e)())
                }), (0, d.N7)(".js-session-resumable", function() {
                    ta() || ea()
                }), window.addEventListener("pagehide", function() {
                    (0, Se.Xm)((0, je.e)(), {
                        selector: ".js-session-resumable"
                    })
                }), window.addEventListener("pjax:beforeReplace", function(e) {
                    const t = e.detail.previousState,
                        n = t ? t.url : null;
                    if (n)(0, Se.Xm)((0, je.e)(new URL(n, window.location.origin)), {
                        selector: ".js-session-resumable"
                    });
                    else {
                        const o = new Error("pjax:beforeReplace event.detail.previousState.url is undefined");
                        setTimeout(function() {
                            throw o
                        })
                    }
                }), window.addEventListener("turbo:before-visit", function() {
                    (0, Se.Xm)((0, je.e)(), {
                        selector: ".js-session-resumable"
                    })
                }), window.addEventListener("turbo:load", function() {
                    (0, Se.e6)((0, je.e)())
                });
                var Kl = u(74675),
                    gt = u(46836);
                const vn = ["notification_referrer_id", "notifications_before", "notifications_after", "notifications_query"],
                    bt = "notification_shelf";

                function na(e, t = null) {
                    return e.has("notification_referrer_id") ? (ra(e, t), sa(e)) : null
                }
                s(na, "storeAndStripShelfParams");

                function oa(e = null) {
                    const t = Wo(e);
                    if (!t) return (0, gt.cl)(bt), null;
                    try {
                        const n = (0, gt.rV)(bt);
                        if (!n) return null;
                        const o = JSON.parse(n);
                        if (!o || !o.pathname) throw new Error("Must have a pathname");
                        if (o.pathname !== t) throw new Error("Stored pathname does not match current pathname.");
                        const r = {};
                        for (const i of vn) r[i] = o[i];
                        return r
                    } catch {
                        return (0, gt.cl)(bt), null
                    }
                }
                s(oa, "getStoredShelfParamsForCurrentPage");

                function ra(e, t) {
                    const n = Wo(t);
                    if (!n) return;
                    const o = {
                        pathname: n
                    };
                    for (const r of vn) {
                        const i = e.get(r);
                        i && (o[r] = i)
                    }(0, gt.LS)(bt, JSON.stringify(o))
                }
                s(ra, "storeShelfParams");

                function sa(e) {
                    for (const t of vn) e.delete(t);
                    return e
                }
                s(sa, "deleteShelfParams");

                function Wo(e) {
                    e = e || window.location.pathname;
                    const t = /^(\/[^/]+\/[^/]+\/pull\/[^/]+)/,
                        n = e.match(t);
                    return n ? n[0] : null
                }
                s(Wo, "getCurrentPullRequestPathname");
                var ia = u(27034),
                    aa = u(75509);
                async function ca() {
                    return (0, T.AC)(".js-notification-shelf .js-notification-action form", async function(e, t) {
                        if (e.hasAttribute("data-redirect-to-inbox-on-submit")) {
                            await zo(t);
                            const o = document.querySelector(".js-notifications-back-to-inbox");
                            o && o.click();
                            return
                        }(0, aa.a)(e, e), await zo(t)
                    })
                }
                s(ca, "remoteShelfActionForm");

                function la() {
                    const e = new URLSearchParams(window.location.search),
                        t = na(e);
                    if (t) {
                        const n = new URL(window.location.href, window.location.origin);
                        return n.search = t.toString(), n.toString()
                    }
                }
                s(la, "urlWithoutNotificationParameters");

                function ua(e) {
                    if (!(e instanceof ia.Z)) return;
                    const t = oa();
                    if (!t) return;
                    const n = e.getAttribute("data-base-src");
                    if (!n) return;
                    const o = new URL(n, window.location.origin),
                        r = new URLSearchParams(o.search);
                    for (const [i, a] of Object.entries(t)) typeof a == "string" && r.set(i, a);
                    o.search = r.toString(), e.setAttribute("src", o.toString())
                }
                s(ua, "loadShelfFromStoredParams");
                async function zo(e) {
                    try {
                        await e.text()
                    } catch {}
                }
                s(zo, "performRequest"), ca();

                function Ko() {
                    const e = la();
                    e && (0, R.lO)(null, "", e)
                }
                s(Ko, "removeNotificationParams"), Ko(), window.addEventListener("turbo:load", Ko), (0, d.N7)(".js-notification-shelf-include-fragment", ua), (0, l.on)("submit", ".js-mark-notification-form", async function(e) {
                    const t = e.currentTarget;
                    e.preventDefault();
                    try {
                        await fetch(t.action, {
                            method: t.method,
                            body: new FormData(t),
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })
                    } catch {}
                });
                async function da() {
                    await fe.C;
                    const e = document.querySelector(".js-mark-notification-form");
                    e instanceof HTMLFormElement && (0, f.Bt)(e)
                }
                s(da, "markNotificationAsRead"), da();

                function fa(e) {
                    return !!e.closest(".js-jump-to-field")
                }
                s(fa, "isJumpToAvailable");

                function wn(e, t) {
                    if (fa(e)) return;
                    const n = document.querySelector(".js-site-search-form");
                    document.querySelector(".js-site-search").classList.toggle("scoped-search", t);
                    let o, r;
                    t ? (o = n.getAttribute("data-scoped-search-url"), r = e.getAttribute("data-scoped-placeholder")) : (o = n.getAttribute("data-unscoped-search-url"), r = e.getAttribute("data-unscoped-placeholder")), n.setAttribute("action", o), e.setAttribute("placeholder", r)
                }
                s(wn, "toggleSearchScope"), (0, P.w4)("keyup", ".js-site-search-field", function(e) {
                    const t = e.target,
                        n = t.value.length === 0;
                    n && e.key === "Backspace" && t.classList.contains("is-clearable") && wn(t, !1), n && e.key === "Escape" && wn(t, !0), t.classList.toggle("is-clearable", n)
                }), (0, P.ZG)(".js-site-search-focus", function(e) {
                    const t = e.closest(".js-chromeless-input-container");
                    t.classList.add("focus");

                    function n() {
                        t.classList.remove("focus"), e.value.length === 0 && e.classList.contains("js-site-search-field") && wn(e, !0), e.removeEventListener("blur", n)
                    }
                    s(n, "blurHandler"), e.addEventListener("blur", n)
                }), (0, l.on)("submit", ".js-site-search-form", function(e) {
                    if (!(e.target instanceof Element)) return;
                    const t = e.target.querySelector(".js-site-search-type-field");
                    t.value = new URLSearchParams(window.location.search).get("type") || ""
                });
                var ma = u(54430);
                (0, d.N7)("textarea.js-size-to-fit", {
                    constructor: HTMLTextAreaElement,
                    subscribe: ma.Z
                });
                var Vl = u(53488);
                const pa = 1e3,
                    Vo = new WeakMap,
                    Xo = document.querySelector("#snippet-clipboard-copy-button");
                async function ha(e, t) {
                    const n = e.getAttribute("data-snippet-clipboard-copy-content");
                    if (n === null || (e.removeAttribute("data-snippet-clipboard-copy-content"), !(Xo instanceof HTMLTemplateElement))) return;
                    const r = Xo.content.cloneNode(!0).children[0];
                    if (!(r instanceof HTMLElement)) return;
                    const i = r.children[0];
                    if (!(i instanceof HTMLElement)) return;
                    i.setAttribute("value", n), document.addEventListener("selectionchange", () => {
                        const c = document.getSelection();
                        if (c && e.contains(c.anchorNode)) {
                            const m = c == null ? void 0 : c.toString();
                            i.style.display = m.trim() === "" ? "inherit" : "none"
                        }
                    }, {
                        signal: t
                    });
                    const a = e.querySelector("pre");
                    if (a !== null) {
                        let c;
                        a.addEventListener("scroll", () => {
                            c && clearTimeout(c), i.style.display = "none", c = setTimeout(() => {
                                i.style.display = "inherit"
                            }, pa)
                        }, {
                            signal: t
                        })
                    }
                    e.appendChild(r)
                }
                s(ha, "insertSnippetClipboardCopyButton"), (0, d.N7)("[data-snippet-clipboard-copy-content]", {
                    constructor: HTMLElement,
                    add(e) {
                        if (e.parentElement && e.parentElement.classList.contains("js-no-snippet-clipboard-copy")) return;
                        const t = new AbortController;
                        Vo.set(e, t), ha(e, t.signal)
                    }
                }), (0, d.N7)(".snippet-clipboard-content clipboard-copy", {
                    constructor: HTMLElement,
                    remove(e) {
                        const t = Vo.get(e);
                        t && t.abort()
                    }
                });

                function Go(e, t, n) {
                    Zo(e, t), n && e.classList.toggle("on");
                    const o = Array.from(e.querySelectorAll(".js-social-updatable"), Ae.x0);
                    return Promise.all(o)
                }
                s(Go, "handleSocialResponse"), (0, T.AC)(".js-social-form", async function(e, t) {
                    var n, o;
                    let r;
                    const i = e.closest(".js-social-container"),
                        a = e.classList.contains("js-deferred-toggler-target");
                    try {
                        r = await t.json(), i && await Go(i, r.json.count, a)
                    } catch (c) {
                        if (((n = c.response) == null ? void 0 : n.status) === 409 && c.response.json.confirmationDialog) {
                            const m = c.response.json.confirmationDialog,
                                p = document.querySelector(m.templateSelector),
                                S = (o = e.querySelector(".js-confirm-csrf-token")) == null ? void 0 : o.value;
                            if (p instanceof HTMLTemplateElement && S) {
                                const q = new rt.R(p, {
                                        confirmUrl: e.action,
                                        confirmCsrfToken: S,
                                        ...m.inputs || {}
                                    }),
                                    O = await (0, we.W)({
                                        content: q
                                    });
                                O.addEventListener("social-confirmation-form:success", async B => {
                                    B instanceof CustomEvent && i && await Go(i, B.detail.count, a)
                                }), O.addEventListener("social-confirmation-form:error", () => {
                                    (0, w.v)()
                                })
                            }
                        } else i && !a && i.classList.toggle("on"), (0, w.v)()
                    }
                }), (0, T.AC)(".js-social-confirmation-form", async function(e, t) {
                    try {
                        const n = await t.json();
                        (0, l.f)(e, "social-confirmation-form:success", n.json)
                    } catch {
                        (0, l.f)(e, "social-confirmation-form:error")
                    }
                });

                function Zo(e, t) {
                    for (const n of e.querySelectorAll(".js-social-count")) {
                        n.textContent = t;
                        const o = n.getAttribute("data-singular-suffix"),
                            r = n.getAttribute("data-plural-suffix"),
                            i = t === "1" ? o : r;
                        i && n.setAttribute("aria-label", `${t} ${i}`)
                    }
                }
                s(Zo, "updateSocialCounts");
                var xe = u(21461);
                class Jo extends xe.a2 {
                    constructor(t, n, o, r) {
                        super(t, () => this.getUrlFromRefreshUrl(), o, r);
                        this.refreshUrl = n
                    }
                    getUrlFromRefreshUrl() {
                        return ga(this.refreshUrl)
                    }
                }
                s(Jo, "AliveSession");
                async function ga(e) {
                    const t = await ba(e);
                    return t && t.url && t.token ? ya(t.url, t.token) : null
                }
                s(ga, "fetchRefreshUrl");
                async function ba(e) {
                    const t = await fetch(e, {
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    if (t.ok) return t.json();
                    if (t.status === 404) return null;
                    throw new Error("fetch error")
                }
                s(ba, "fetchJSON");
                async function ya(e, t) {
                    const n = await fetch(e, {
                        method: "POST",
                        mode: "same-origin",
                        headers: {
                            "Scoped-CSRF-Token": t
                        }
                    });
                    if (n.ok) return n.text();
                    throw new Error("fetch error")
                }
                s(ya, "post");
                const yt = [],
                    va = 3e4,
                    wa = 0;
                let vt = document.hidden,
                    wt;

                function Ea(e) {
                    return e(vt), yt.push(e), new x.w0(() => {
                        const t = yt.indexOf(e);
                        t !== -1 && yt.splice(t, 1)
                    })
                }
                s(Ea, "addIdleStateListener"), document.addEventListener("visibilitychange", () => {
                    const e = document.hidden;
                    wt !== void 0 && clearTimeout(wt), wt = setTimeout(() => {
                        if (e !== vt) {
                            vt = e, wt = void 0;
                            for (const n of yt) n(vt)
                        }
                    }, e ? va : wa)
                });
                var La = u(60785);

                function Sa() {
                    return "SharedWorker" in window && (0, La.Z)("localStorage").getItem("bypassSharedWorker") !== "true"
                }
                s(Sa, "isSharedWorkerSupported");

                function ja() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket-src]")) == null ? void 0 : e.href) != null ? t : null
                }
                s(ja, "workerSrc");

                function Ta() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.href) != null ? t : null
                }
                s(Ta, "socketUrl");

                function Aa() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.getAttribute("data-refresh-url")) != null ? t : null
                }
                s(Aa, "socketRefreshUrl");

                function Ca() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.getAttribute("data-session-id")) != null ? t : null
                }
                s(Ca, "sessionIdentifier");

                function ka(e) {
                    return Yo(e).map(t => ({
                        subscriber: e,
                        topic: t
                    }))
                }
                s(ka, "subscriptions");

                function Yo(e) {
                    return (e.getAttribute("data-channel") || "").trim().split(/\s+/).map(xe.Zf.parse).filter(xa)
                }
                s(Yo, "channels");

                function xa(e) {
                    return e != null
                }
                s(xa, "isPresent");

                function Qo(e, {
                    channel: t,
                    type: n,
                    data: o
                }) {
                    for (const r of e) r.dispatchEvent(new CustomEvent(`socket:${n}`, {
                        bubbles: !1,
                        cancelable: !1,
                        detail: {
                            name: t,
                            data: o
                        }
                    }))
                }
                s(Qo, "notify");
                class er {
                    constructor(t, n, o, r, i) {
                        this.subscriptions = new xe.vk, this.presenceMetadata = new xe.ah, this.notifyPresenceDebouncedByChannel = new Map, this.notify = i, this.worker = new SharedWorker(t, `github-socket-worker-v2-${r}`), this.worker.port.onmessage = ({
                            data: a
                        }) => this.receive(a), this.worker.port.postMessage({
                            connect: {
                                url: n,
                                refreshUrl: o
                            }
                        })
                    }
                    subscribe(t) {
                        const n = this.subscriptions.add(...t);
                        n.length && this.worker.port.postMessage({
                            subscribe: n
                        });
                        const o = new Set(n.map(i => i.name)),
                            r = t.reduce((i, a) => {
                                const c = a.topic.name;
                                return (0, xe.A)(c) && !o.has(c) && i.add(c), i
                            }, new Set);
                        r.size && this.worker.port.postMessage({
                            requestPresence: Array.from(r)
                        })
                    }
                    unsubscribeAll(...t) {
                        const n = this.subscriptions.drain(...t);
                        n.length && this.worker.port.postMessage({
                            unsubscribe: n
                        });
                        const o = this.presenceMetadata.removeSubscribers(t);
                        this.sendPresenceMetadataUpdate(o)
                    }
                    updatePresenceMetadata(t) {
                        const n = new Set;
                        for (const o of t) this.presenceMetadata.setMetadata(o), n.add(o.channelName);
                        this.sendPresenceMetadataUpdate(n)
                    }
                    sendPresenceMetadataUpdate(t) {
                        if (!t.size) return;
                        const n = [];
                        for (const o of t) n.push({
                            channelName: o,
                            metadata: this.presenceMetadata.getChannelMetadata(o)
                        });
                        this.worker.port.postMessage({
                            updatePresenceMetadata: n
                        })
                    }
                    online() {
                        this.worker.port.postMessage({
                            online: !0
                        })
                    }
                    offline() {
                        this.worker.port.postMessage({
                            online: !1
                        })
                    }
                    hangup() {
                        this.worker.port.postMessage({
                            hangup: !0
                        })
                    }
                    receive(t) {
                        const {
                            channel: n
                        } = t;
                        if (t.type === "presence") {
                            let o = this.notifyPresenceDebouncedByChannel.get(n);
                            o || (o = (0, U.D)((r, i) => {
                                this.notify(r, i), this.notifyPresenceDebouncedByChannel.delete(n)
                            }, 100), this.notifyPresenceDebouncedByChannel.set(n, o)), o(this.subscriptions.subscribers(n), t);
                            return
                        }
                        this.notify(this.subscriptions.subscribers(n), t)
                    }
                }
                s(er, "AliveSessionProxy");

                function Ma() {
                    const e = ja();
                    if (!e) return;
                    const t = Ta();
                    if (!t) return;
                    const n = Aa();
                    if (!n) return;
                    const o = Ca();
                    if (!o) return;
                    const i = s(() => {
                            if (Sa()) try {
                                return new er(e, t, n, o, Qo)
                            } catch {}
                            return new Jo(t, n, !1, Qo)
                        }, "createSession")(),
                        a = (0, $.g)(p => i.subscribe(p.flat())),
                        c = (0, $.g)(p => i.unsubscribeAll(...p)),
                        m = (0, $.g)(p => i.updatePresenceMetadata(p));
                    (0, d.N7)(".js-socket-channel[data-channel]", {
                        subscribe: p => {
                            const S = ka(p),
                                q = S.map(B => B.topic.name).filter(B => (0, xe.A)(B));
                            let O = {
                                unsubscribe() {}
                            };
                            if (q.length) {
                                let B, K;
                                const oe = s(() => {
                                    const J = [];
                                    B && J.push(B), K !== void 0 && J.push({
                                        [xe.ZE]: K ? 1 : 0
                                    });
                                    for (const ne of q) m({
                                        subscriber: p,
                                        channelName: ne,
                                        metadata: J
                                    })
                                }, "queueMetadataOrIdleChange");
                                O = (0, x.qC)((0, x.RB)(p, "socket:set-presence-metadata", J => {
                                    const {
                                        detail: ne
                                    } = J;
                                    B = ne, oe()
                                }), Ea(J => {
                                    !(0, pe.c)("PRESENCE_IDLE") || (K = J, oe())
                                }))
                            }
                            return a(S), O
                        },
                        remove: p => c(p)
                    }), window.addEventListener("online", () => i.online()), window.addEventListener("offline", () => i.offline()), window.addEventListener("pagehide", () => {
                        "hangup" in i && i.hangup()
                    })
                }
                s(Ma, "connect"), (async () => (await fe.x, Ma()))();
                const tr = new Map;

                function qa(e, t) {
                    const n = [];
                    for (const o of e) {
                        const r = tr.get(o.name);
                        r && r.arrived > t && n.push(r)
                    }
                    return n
                }
                s(qa, "stale");

                function Ra(e, t) {
                    for (const n of e.querySelectorAll(".js-socket-channel[data-channel]"))
                        for (const o of qa(Yo(n), t)) n.dispatchEvent(new CustomEvent("socket:message", {
                            bubbles: !1,
                            cancelable: !1,
                            detail: {
                                name: o.name,
                                data: o.data,
                                cached: !0
                            }
                        }))
                }
                s(Ra, "dispatch");

                function Pa(e) {
                    const {
                        name: t,
                        data: n,
                        cached: o
                    } = e.detail;
                    if (o) return;
                    const r = {
                        name: t,
                        data: { ...n
                        },
                        arrived: Date.now()
                    };
                    r.data.wait = 0, tr.set(t, r)
                }
                s(Pa, "store"), document.addEventListener("socket:message", Pa, {
                    capture: !0
                }), document.addEventListener("pjax:popstate", function(e) {
                    const t = e.target,
                        n = e.detail.cachedAt;
                    n && setTimeout(() => Ra(t, n))
                }), (0, d.N7)("form.js-auto-replay-enforced-sso-request", {
                    constructor: HTMLFormElement,
                    initialize(e) {
                        (0, f.Bt)(e)
                    }
                });
                var Xl = u(59371);

                function nr(e, t, n) {
                    const o = e.getBoundingClientRect().height,
                        r = t.getBoundingClientRect(),
                        i = n.getBoundingClientRect();
                    let a = i.top;
                    a + r.height + 10 >= o && (a = Math.max(o - r.height - 10, 0));
                    let c = i.right;
                    n.closest(".js-build-status-to-the-left") != null && (c = Math.max(i.left - r.width - 10, 0)), t.style.top = `${a}px`, t.style.left = `${c}px`, t.style.right = "auto"
                }
                s(nr, "updateStatusPosition"), (0, l.on)("toggle", ".js-build-status .js-dropdown-details", function(e) {
                    const t = e.currentTarget,
                        n = t.querySelector(".js-status-dropdown-menu");
                    if (!n) return;

                    function o() {
                        t.hasAttribute("open") || i()
                    }
                    s(o, "closeOnToggle");

                    function r(a) {
                        n.contains(a.target) || i()
                    }
                    s(r, "closeOnScroll");

                    function i() {
                        t.removeAttribute("open"), n.classList.add("d-none"), t.appendChild(n), t.removeEventListener("toggle", o), window.removeEventListener("scroll", r)
                    }
                    s(i, "closeStatusPopover"), t.addEventListener("toggle", o), n.classList.contains("js-close-menu-on-scroll") && window.addEventListener("scroll", r, {
                        capture: !0
                    }), n.classList.remove("d-none"), n.querySelector(".js-details-container").classList.add("open"), n.classList.contains("js-append-menu-to-body") && (document.body.appendChild(n), nr(document.body, n, t))
                }, {
                    capture: !0
                });
                async function or(e) {
                    const t = e.querySelector(".js-dropdown-details"),
                        n = e.querySelector(".js-status-dropdown-menu") || e.closest(".js-status-dropdown-menu");
                    if (!(n instanceof HTMLElement)) return;
                    const o = n.querySelector(".js-status-loader");
                    if (!o) return;
                    const r = n.querySelector(".js-status-loading"),
                        i = n.querySelector(".js-status-error"),
                        a = o.getAttribute("data-contents-url");
                    r.classList.remove("d-none"), i.classList.add("d-none");
                    let c;
                    try {
                        await (0, Ho.Z)(), c = await (0, ce.a)(document, a)
                    } catch {
                        r.classList.add("d-none"), i.classList.remove("d-none")
                    }
                    c && (o.replaceWith(c), n.querySelector(".js-details-container").classList.add("open"), t && n.classList.contains("js-append-menu-to-body") && nr(document.body, n, t))
                }
                s(or, "loadStatus"), (0, l.on)("click", ".js-status-retry", ({
                    currentTarget: e
                }) => {
                    or(e)
                });

                function rr(e) {
                    const t = e.currentTarget;
                    or(t)
                }
                s(rr, "onMouseEnter"), (0, d.N7)(".js-build-status", {
                    add(e) {
                        e.addEventListener("mouseenter", rr, {
                            once: !0
                        })
                    },
                    remove(e) {
                        e.removeEventListener("mouseenter", rr)
                    }
                });
                var Gl = u(54235),
                    Ia = u(24519);
                (0, l.on)("click", "button[data-sudo-required], summary[data-sudo-required]", sr), (0, d.N7)("form[data-sudo-required]", {
                    constructor: HTMLFormElement,
                    subscribe: e => (0, x.RB)(e, "submit", sr)
                });
                async function sr(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLElement)) return;
                    e.stopPropagation(), e.preventDefault(), await (0, Ia.Z)() && (t.removeAttribute("data-sudo-required"), t instanceof HTMLFormElement ? (0, f.Bt)(t) : t.click())
                }
                s(sr, "checkSudo");
                var Oe = u(34821),
                    Et = u(71900);
                const ir = {
                    "actor:": "ul.js-user-suggestions",
                    "user:": "ul.js-user-suggestions",
                    "operation:": "ul.js-operation-suggestions",
                    "org:": "ul.js-org-suggestions",
                    "action:": "ul.js-action-suggestions",
                    "repo:": "ul.js-repo-suggestions",
                    "country:": "ul.js-country-suggestions"
                };
                (0, d.N7)("text-expander[data-audit-url]", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "text-expander-change", Na), (0, x.RB)(e, "text-expander-value", Da))
                });

                function Da(e) {
                    const t = e.detail;
                    if (!ar(t.key)) return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `${t.key}${n}`
                }
                s(Da, "onvalue");

                function Na(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (!ar(t)) return;
                    const i = e.target.getAttribute("data-audit-url");
                    n(Ba(i, t, o))
                }
                s(Na, "onchange");

                function Oa(e, t) {
                    const n = t.toLowerCase(),
                        o = s(r => {
                            const i = r.textContent.toLowerCase().trim(),
                                a = (0, Oe.EW)(i, n);
                            return a > 0 ? {
                                score: a,
                                text: i
                            } : null
                        }, "key");
                    return n ? (0, Et.W)(e, o, Oe.qu) : e
                }
                s(Oa, "search");
                const Ha = (0, Ce.Z)(e => [...e.children], {
                    hash: e => e.className
                });
                async function Ba(e, t, n) {
                    const r = (await Ua(e)).querySelector($a(t));
                    if (!r) return {
                        matched: !1
                    };
                    const i = Oa(Ha(r), n).slice(0, 5),
                        a = r.cloneNode(!1);
                    a.innerHTML = "";
                    for (const c of i) a.append(c);
                    return {
                        fragment: a,
                        matched: i.length > 0
                    }
                }
                s(Ba, "auditMenu");

                function ar(e) {
                    return Object.getOwnPropertyNames(ir).includes(e)
                }
                s(ar, "isActivationKey");

                function $a(e) {
                    const t = ir[e];
                    if (!t) throw new Error(`Unknown audit log expander key: ${e}`);
                    return t
                }
                s($a, "audit_log_suggester_selector");
                async function Fa(e) {
                    const t = await (0, ce.a)(document, e),
                        n = document.createElement("div");
                    return n.append(t), n
                }
                s(Fa, "fetchMenu");
                const Ua = (0, Ce.Z)(Fa);

                function _a(e) {
                    if (e.hasAttribute("data-use-colon-emoji")) return e.getAttribute("data-value");
                    const t = e.firstElementChild;
                    return t && t.tagName === "G-EMOJI" && !t.firstElementChild ? t.textContent : e.getAttribute("data-value")
                }
                s(_a, "getValue");

                function Wa(e, t) {
                    const n = ` ${t.toLowerCase().replace(/_/g," ")}`,
                        o = s(r => {
                            const i = r.getAttribute("data-emoji-name"),
                                a = Ka(za(r), n);
                            return a > 0 ? {
                                score: a,
                                text: i
                            } : null
                        }, "key");
                    return (0, Et.W)(e, o, Oe.qu)
                }
                s(Wa, "emoji_suggester_search");

                function za(e) {
                    return ` ${e.getAttribute("data-text").trim().toLowerCase().replace(/_/g," ")}`
                }
                s(za, "emojiText");

                function Ka(e, t) {
                    const n = e.indexOf(t);
                    return n > -1 ? 1e3 - n : 0
                }
                s(Ka, "emojiScore"), (0, d.N7)("text-expander[data-emoji-url]", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "text-expander-change", Xa), (0, x.RB)(e, "text-expander-value", Va))
                });

                function Va(e) {
                    const t = e.detail;
                    t.key === ":" && (t.value = _a(t.item))
                }
                s(Va, "emoji_suggester_onvalue");

                function Xa(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== ":") return;
                    const i = e.target.getAttribute("data-emoji-url");
                    n(Ga(i, o))
                }
                s(Xa, "emoji_suggester_onchange");
                async function Ga(e, t) {
                    const [n, o] = await Ja(e), r = Wa(o, t).slice(0, 5);
                    n.innerHTML = "";
                    for (const i of r) n.append(i);
                    return {
                        fragment: n,
                        matched: r.length > 0
                    }
                }
                s(Ga, "emojiMenu");
                async function Za(e) {
                    const n = (await (0, ce.a)(document, e)).firstElementChild;
                    return [n, [...n.children]]
                }
                s(Za, "fetchEmoji");
                const Ja = (0, Ce.Z)(Za);
                var Me = u(38772);

                function Ya(e) {
                    return `${e.number} ${e.title.trim().toLowerCase()}`
                }
                s(Ya, "asText");

                function Qa(e, t) {
                    if (!t) return e;
                    const n = new RegExp(`\\b${ec(t)}`),
                        o = /^\d+$/.test(t) ? i => tc(i, n) : i => (0, Oe.EW)(i, t),
                        r = s(i => {
                            const a = Ya(i),
                                c = o(a);
                            return c > 0 ? {
                                score: c,
                                text: a
                            } : null
                        }, "key");
                    return (0, Et.W)(e, r, Oe.qu)
                }
                s(Qa, "issue_suggester_search");

                function ec(e) {
                    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
                }
                s(ec, "escapeRegExp");

                function tc(e, t) {
                    const n = e.search(t);
                    return n > -1 ? 1e3 - n : 0
                }
                s(tc, "issueNumberScore");

                function nc(e, t, n) {
                    const o = s(i => Me.dy `
    <ul role="listbox" class="suggester-container suggester suggestions list-style-none position-absolute">
      ${i.map(r)}
    </ul>
  `, "itemsTemplate"),
                        r = s(i => {
                            const a = i.type in n ? (0, L.r)(document, n[i.type]) : "";
                            return Me.dy `
      <li class="markdown-title" role="option" id="suggester-issue-${i.id}" data-value="${i.number}">
        <span class="d-inline-block mr-1">${a}</span>
        <small>#${i.number}</small> ${(0,Me.Au)(i.title)}
      </li>
    `
                        }, "itemTemplate");
                    (0, Me.sY)(o(e), t)
                }
                s(nc, "renderResults"), (0, d.N7)("text-expander[data-issue-url]", {
                    subscribe: e => {
                        const t = [(0, x.RB)(e, "text-expander-change", rc), (0, x.RB)(e, "text-expander-value", oc), (0, x.RB)(e, "keydown", ic), (0, x.RB)(e, "click", sc)];
                        return (0, x.qC)(...t)
                    }
                });

                function oc(e) {
                    const t = e.detail;
                    if (t.key !== "#") return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `#${n}`
                }
                s(oc, "issue_suggester_onvalue");

                function rc(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== "#") return;
                    if (o === "#") {
                        En(e.target);
                        return
                    }
                    const i = e.target.getAttribute("data-issue-url");
                    n(ac(i, o))
                }
                s(rc, "issue_suggester_onchange");

                function En(e) {
                    if (!e) return;
                    const t = e.closest("text-expander");
                    t && t.dismiss()
                }
                s(En, "hideSuggestions");

                function sc(e) {
                    En(e.target)
                }
                s(sc, "issue_suggester_onclick");

                function ic(e) {
                    const t = ["ArrowRight", "ArrowLeft"],
                        {
                            key: n
                        } = e;
                    t.indexOf(n) < 0 || En(e.target)
                }
                s(ic, "issue_suggester_onkeydown");
                async function ac(e, t) {
                    const n = await cc(e),
                        o = document.createElement("div"),
                        r = Qa(n.suggestions, t).slice(0, 5);
                    return nc(r, o, n.icons), {
                        fragment: o.firstElementChild,
                        matched: r.length > 0
                    }
                }
                s(ac, "issueMenu");
                const cc = (0, Ce.Z)(async function(e) {
                    const t = await self.fetch(e, {
                        headers: {
                            "X-Requested-With": "XMLHttpRequest",
                            Accept: "application/json"
                        }
                    });
                    if (!t.ok) {
                        const n = new Error,
                            o = t.statusText ? ` ${t.statusText}` : "";
                        throw n.message = `HTTP ${t.status}${o}`, n
                    }
                    return t.json()
                });

                function lc(e) {
                    return e.description ? `${e.name} ${e.description}`.trim().toLowerCase() : `${e.login} ${e.name}`.trim().toLowerCase()
                }
                s(lc, "mention_suggester_asText");

                function uc(e, t) {
                    if (!t) return e;
                    const n = fc(t),
                        o = s(r => {
                            const i = lc(r),
                                a = n(i, r.participant);
                            return a > 0 ? {
                                score: a,
                                text: i
                            } : null
                        }, "key");
                    return (0, Et.W)(e, o, Oe.qu)
                }
                s(uc, "mention_suggester_search");

                function dc(e, t) {
                    const n = s(r => Me.dy `
    <ul role="listbox" class="suggester-container suggester suggestions list-style-none position-absolute">
      ${r.map(o)}
    </ul>
  `, "itemsTemplate"),
                        o = s(r => {
                            const i = r.type === "user" ? r.login : r.name,
                                a = r.type === "user" ? r.name : r.description;
                            return Me.dy `
      <li role="option" id="suggester-${r.id}-${r.type}-${i}" data-value="${i}">
        <span>${i}</span>
        <small>${a}</small>
      </li>
    `
                        }, "itemTemplate");
                    (0, Me.sY)(n(e), t)
                }
                s(dc, "mention_suggester_renderResults");

                function fc(e) {
                    if (!e) return () => 2;
                    const t = e.toLowerCase().split("");
                    return (n, o) => {
                        if (!n) return 0;
                        const r = mc(n, t);
                        if (!r) return 0;
                        const a = e.length / r[1] / (r[0] / 2 + 1);
                        return o ? a + 1 : a
                    }
                }
                s(fc, "fuzzyScorer");

                function mc(e, t) {
                    let n, o, r, i;
                    const a = pc(e, t[0]);
                    if (a.length === 0) return null;
                    if (t.length === 1) return [a[0], 1, []];
                    for (i = null, o = 0, r = a.length; o < r; o++) {
                        const c = a[o];
                        if (!(n = hc(e, t, c + 1))) continue;
                        const m = n[n.length - 1] - c;
                        (!i || m < i[1]) && (i = [c, m, n])
                    }
                    return i
                }
                s(mc, "shortestMatch");

                function pc(e, t) {
                    let n = 0;
                    const o = [];
                    for (;
                        (n = e.indexOf(t, n)) > -1;) o.push(n++);
                    return o
                }
                s(pc, "allIndexesOf");

                function hc(e, t, n) {
                    let o = n;
                    const r = [];
                    for (let i = 1; i < t.length; i += 1) {
                        if (o = e.indexOf(t[i], o), o === -1) return;
                        r.push(o++)
                    }
                    return r
                }
                s(hc, "indexesOfChars"), (0, d.N7)("text-expander[data-mention-url]", {
                    subscribe: e => (0, x.qC)((0, x.RB)(e, "text-expander-change", bc), (0, x.RB)(e, "text-expander-value", gc))
                });

                function gc(e) {
                    const t = e.detail;
                    if (t.key !== "@") return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `@${n}`
                }
                s(gc, "mention_suggester_onvalue");

                function bc(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== "@" || (o == null ? void 0 : o.split(" ").length) > 1) return;
                    const i = e.target.getAttribute("data-mention-url");
                    n(yc(i, o))
                }
                s(bc, "mention_suggester_onchange");
                async function yc(e, t) {
                    const n = await vc(e),
                        o = document.createElement("div"),
                        r = uc(n, t).slice(0, 5);
                    return dc(r, o), {
                        fragment: o.firstElementChild,
                        matched: r.length > 0
                    }
                }
                s(yc, "mentionMenu");
                const vc = (0, Ce.Z)(async function(e) {
                    const t = await self.fetch(e, {
                        headers: {
                            "X-Requested-With": "XMLHttpRequest",
                            Accept: "application/json"
                        }
                    });
                    if (!t.ok) {
                        const n = new Error,
                            o = t.statusText ? ` ${t.statusText}` : "";
                        throw n.message = `HTTP ${t.status}${o}`, n
                    }
                    return t.json()
                });

                function wc(e, t) {
                    const n = e.closest(".js-survey-question-form"),
                        o = n.querySelector("input.js-survey-other-text"),
                        r = t && !n.classList.contains("is-other-selected");
                    n.classList.toggle("is-other-selected", r), o.hidden = !t, r ? (o.required = !0, o.focus()) : o.required = !1, (0, l.f)(o, "change")
                }
                s(wc, "handleOther"), (0, l.on)("change", "input.js-survey-radio", function({
                    currentTarget: e
                }) {
                    wc(e, e.classList.contains("js-survey-radio-other"))
                }), (0, l.on)("change", "input.js-survey-checkbox-enable-submit", function({
                    currentTarget: e
                }) {
                    var t;
                    const n = e.checked,
                        o = (t = e.closest("form")) == null ? void 0 : t.querySelector("button[type=submit]");
                    o.disabled = !n
                }), (0, l.on)("change", "input.js-survey-contact-checkbox", function(e) {
                    const t = e.currentTarget,
                        o = t.closest(".js-survey-question-form").querySelector(".js-survey-contact-checkbox-hidden");
                    t.checked ? o.setAttribute("disabled", "true") : o.removeAttribute("disabled")
                }), (0, l.on)("details-menu-selected", ".js-sync-select-menu-text", function(e) {
                    const t = document.querySelector(".js-sync-select-menu-button"),
                        n = e.detail.relatedTarget.querySelector("span[data-menu-button-text]").textContent;
                    t.textContent = n, t.focus()
                }, {
                    capture: !0
                }), (0, l.on)("click", 'tab-container [role="tab"]', function(e) {
                    const {
                        currentTarget: t
                    } = e, o = t.closest("tab-container").querySelector(".js-filterable-field, [data-filter-placeholder-input]");
                    if (o instanceof HTMLInputElement) {
                        const r = t.getAttribute("data-filter-placeholder");
                        r && o.setAttribute("placeholder", r), o.focus()
                    }
                }), (0, l.on)("tab-container-changed", "tab-container", function(e) {
                    const t = e.detail.relatedTarget,
                        n = t.getAttribute("data-fragment-url"),
                        o = t.querySelector("include-fragment");
                    n && o && !o.hasAttribute("src") && (o.src = n)
                });
                var Zl = u(64048),
                    cr = u(96776);
                document.addEventListener("keydown", e => {
                    if (e.key !== "Escape" || e.target !== document.body) return;
                    const t = document.querySelector(".js-targetable-element:target");
                    !t || (0, cr.uQ)(t, () => {
                        window.location.hash = "", (0, R.lO)(window.history.state, "", window.location.pathname + window.location.search)
                    })
                }), document.addEventListener("click", e => {
                    const t = document.querySelector(".js-targetable-element:target");
                    !t || e.target instanceof HTMLAnchorElement || e.target instanceof HTMLElement && (t.contains(e.target) || (0, cr.uQ)(t, () => {
                        window.location.hash = "", (0, R.lO)(window.history.state, "", window.location.pathname + window.location.search)
                    }))
                });
                var Jl = u(36099);
                async function Ec(e) {
                    const t = e.currentTarget;
                    if (Sc(t)) {
                        t.classList.remove("tooltipped");
                        return
                    }
                    const n = t.getAttribute("data-url");
                    if (!n) return;
                    const o = await fetch(n, {
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    if (!o.ok) return;
                    const r = await o.json(),
                        i = t.getAttribute("data-id"),
                        a = document.querySelectorAll(`.js-team-mention[data-id='${i}']`);
                    for (const c of a) c.removeAttribute("data-url");
                    try {
                        r.total === 0 ? r.members.push("This team has no members") : r.total > r.members.length && r.members.push(`${r.total-r.members.length} more`), lr(a, Lc(r.members))
                    } catch (c) {
                        const m = c.response ? c.response.status : 500,
                            p = t.getAttribute(m === 404 ? "data-permission-text" : "data-error-text");
                        lr(a, p)
                    }
                }
                s(Ec, "members");

                function lr(e, t) {
                    for (const n of e) n instanceof HTMLElement && (n.setAttribute("aria-label", t), n.classList.add("tooltipped", "tooltipped-s", "tooltipped-multiline"))
                }
                s(lr, "tip");

                function Lc(e) {
                    if ("ListFormat" in Intl) return new Intl.ListFormat().format(e);
                    if (e.length === 0) return "";
                    if (e.length === 1) return e[0];
                    if (e.length === 2) return e.join(" and "); {
                        const t = e[e.length - 1];
                        return e.slice(0, -1).concat(`and ${t}`).join(", ")
                    }
                }
                s(Lc, "sentence");

                function Sc(e) {
                    return !!e.getAttribute("data-hovercard-url") && !!e.closest("[data-team-hovercards-enabled]")
                }
                s(Sc, "teamHovercardEnabled"), (0, d.N7)(".js-team-mention", function(e) {
                    e.addEventListener("mouseenter", Ec)
                });

                function jc() {
                    const e = document.querySelector(".js-timeline-marker");
                    return e != null ? e.getAttribute("data-last-modified") : null
                }
                s(jc, "getTimelineLastModified");

                function ur(e) {
                    if (Ac(e) || Tc(e)) return;
                    const t = jc();
                    t && e.headers.set("X-Timeline-Last-Modified", t)
                }
                s(ur, "addTimelineLastModifiedHeader");

                function Tc(e) {
                    return e.headers.get("X-PJAX") === "true"
                }
                s(Tc, "isPjax");

                function Ac(e) {
                    let t;
                    try {
                        t = new URL(e.url)
                    } catch {
                        return !0
                    }
                    return t.host !== window.location.host
                }
                s(Ac, "isCrossDomain"), (0, T.AC)(".js-needs-timeline-marker-header", function(e, t, n) {
                    ur(n)
                }), (0, l.on)("deprecatedAjaxSend", "[data-remote]", function(e) {
                    const {
                        request: t
                    } = e.detail;
                    ur(t)
                });
                const dr = 5e3,
                    Cc = ".js-comment-body img",
                    kc = ".js-comment-body video";
                (0, Kt.Z)(function() {
                    Lt()
                }), (0, d.N7)(".js-timeline-progressive-focus-container", function(e) {
                    const t = St();
                    if (!t || document.querySelector(".js-pull-discussion-timeline")) return;
                    const o = document.getElementById(t);
                    o && e.contains(o) && Ln(o)
                });

                function Lt(e = !0) {
                    const t = St();
                    if (!t) return;
                    const n = document.getElementById(t);
                    if (n) Ln(n);
                    else {
                        if (xc(t)) return;
                        const o = document.querySelector("#js-timeline-progressive-loader");
                        o && e && pr(t, o)
                    }
                }
                s(Lt, "focusOrLoadElement");

                function xc(e) {
                    return Mc(e) || fr(e, ".js-thread-hidden-comment-ids") || fr(e, ".js-review-hidden-comment-ids")
                }
                s(xc, "loadComments");

                function Mc(e) {
                    const t = mr(e, ".js-comment-container");
                    return t ? ((0, Vt.$)(t), !0) : !1
                }
                s(Mc, "loadResolvedComments");

                function fr(e, t) {
                    const n = mr(e, t);
                    return n ? (n.addEventListener("page:loaded", function() {
                        Lt()
                    }), n.querySelector("button[type=submit]").click(), !0) : !1
                }
                s(fr, "loadHiddenComments");

                function mr(e, t) {
                    var n;
                    const o = document.querySelectorAll(t);
                    for (const r of o) {
                        const i = r.getAttribute("data-hidden-comment-ids");
                        if (i) {
                            const a = i.split(","),
                                c = (n = e.match(/\d+/g)) == null ? void 0 : n[0];
                            if (c && a.includes(c)) return r
                        }
                    }
                    return null
                }
                s(mr, "findCommentContainer"), (0, d.N7)(".js-inline-comments-container", function(e) {
                    const t = St();
                    if (!t) return;
                    const n = document.getElementById(t);
                    n && e.contains(n) && Ln(n)
                }), (0, d.N7)("#js-discussions-timeline-anchor-loader", {
                    constructor: HTMLElement,
                    add: e => {
                        if (document.querySelector("#js-timeline-progressive-loader")) return;
                        const n = St();
                        if (!n) return;
                        document.getElementById(n) || pr(n, e)
                    }
                });
                async function qc() {
                    const e = document.querySelectorAll(kc),
                        t = Array.from(e).map(n => new Promise(o => {
                            if (n.readyState >= n.HAVE_METADATA) o(n);
                            else {
                                const r = setTimeout(() => o(n), dr),
                                    i = s(() => {
                                        clearTimeout(r), o(n)
                                    }, "done");
                                n.addEventListener("loadeddata", () => {
                                    n.readyState >= n.HAVE_METADATA && i()
                                }), n.addEventListener("error", () => i())
                            }
                        }));
                    return Promise.all(t)
                }
                s(qc, "videosReady");
                async function Rc() {
                    const e = document.querySelectorAll(Cc),
                        t = Array.from(e).map(n => {
                            new Promise(o => {
                                if (n.complete) o(n);
                                else {
                                    const r = setTimeout(() => o(n), dr),
                                        i = s(() => {
                                            clearTimeout(r), o(n)
                                        }, "done");
                                    n.addEventListener("load", () => i()), n.addEventListener("error", () => i())
                                }
                            })
                        });
                    return Promise.all(t)
                }
                s(Rc, "imagesReady");
                async function Pc() {
                    return Promise.all([qc(), Rc()])
                }
                s(Pc, "mediaLoaded");
                async function Ln(e) {
                    await Pc(), Ic(e);
                    const t = e.querySelector(`[href='#${e.id}']`);
                    if (t) {
                        const n = t.getAttribute("data-turbo");
                        t.setAttribute("data-turbo", "false"), t.click(), n === null ? t.removeAttribute("data-turbo") : t.setAttribute("data-turbo", n)
                    }
                }
                s(Ln, "focusElement");
                async function pr(e, t) {
                    if (!t) return;
                    const n = t.getAttribute("data-timeline-item-src");
                    if (!n) return;
                    const o = new URL(n, window.location.origin),
                        r = new URLSearchParams(o.search.slice(1));
                    r.append("anchor", e), o.search = r.toString();
                    let i;
                    try {
                        i = await (0, ce.a)(document, o.toString())
                    } catch {
                        return
                    }
                    const a = i.querySelector(".js-timeline-item");
                    if (!a) return;
                    const c = a.getAttribute("data-gid");
                    if (!c) return;
                    const m = document.querySelector(`.js-timeline-item[data-gid='${c}']`);
                    if (m) m.replaceWith(a), Lt(!1);
                    else {
                        const p = document.getElementById("js-progressive-timeline-item-container");
                        p && p.replaceWith(i), Lt(!1)
                    }
                }
                s(pr, "loadElement");

                function Ic(e) {
                    const t = e.closest("details, .js-details-container");
                    !t || (t.nodeName === "DETAILS" ? t.setAttribute("open", "open") : (0, zt.jo)(t) || (0, zt.Qp)(t))
                }
                s(Ic, "expandDetailsIfPresent");

                function St() {
                    return window.location.hash.slice(1)
                }
                s(St, "urlAnchor"), (0, d.N7)(".js-discussion", Dc);

                function Dc() {
                    let e = new WeakSet;
                    t(), document.addEventListener("pjax:end", t), document.addEventListener("turbo:load", t), (0, d.N7)(".js-timeline-item", n => {
                        n instanceof HTMLElement && (e.has(n) || (0, h.N)(n))
                    });

                    function t() {
                        e = new WeakSet(document.querySelectorAll(".js-timeline-item"))
                    }
                    s(t, "setExistingTimelineItems")
                }
                s(Dc, "announceTimelineEvents"), (0, d.N7)("html[data-a11y-animated-images] .js-discussion img[data-animated-image]", e => {
                    if (!(e instanceof HTMLImageElement) || e.closest("a") && !(e.parentElement instanceof HTMLAnchorElement)) return;
                    let t = e.parentElement,
                        n = null;
                    if (t instanceof HTMLAnchorElement) {
                        if (t.childElementCount > 1) return;
                        n = t, n.setAttribute("data-target", "animated-image.originalLink"), t = n.parentElement
                    }
                    e.removeAttribute("data-animated-image"), e.setAttribute("data-target", "animated-image.originalImage");
                    const o = n ? n.cloneNode(!0) : e.cloneNode(!0),
                        r = document.createElement("animated-image");
                    r.appendChild(o), t == null || t.replaceChild(r, n || e)
                });
                var Ve = u(82131);

                function Xe(e) {
                    const {
                        name: t,
                        value: n
                    } = e, o = {
                        name: window.location.href
                    };
                    switch (t) {
                        case "CLS":
                            o.cls = n;
                            break;
                        case "FCP":
                            o.fcp = n;
                            break;
                        case "FID":
                            o.fid = n;
                            break;
                        case "LCP":
                            o.lcp = n;
                            break;
                        case "TTFB":
                            o.ttfb = n;
                            break
                    }(0, me.b)({
                        webVitalTimings: [o]
                    }), Nc(t, n)
                }
                s(Xe, "sendVitals");

                function Nc(e, t) {
                    const n = document.querySelector("#staff-bar-web-vitals"),
                        o = n == null ? void 0 : n.querySelector(`[data-metric=${e.toLowerCase()}]`);
                    !o || (o.textContent = t.toPrecision(6))
                }
                s(Nc, "updateStaffBar");

                function Oc() {
                    return !!(window.performance && window.performance.timing && window.performance.getEntriesByType)
                }
                s(Oc, "isTimingSuppported");
                async function Hc() {
                    if (!Oc()) return;
                    await fe.C, await new Promise(n => setTimeout(n));
                    const e = window.performance.getEntriesByType("resource");
                    e.length && (0, me.b)({
                        resourceTimings: e
                    });
                    const t = window.performance.getEntriesByType("navigation");
                    t.length && (0, me.b)({
                        navigationTimings: t
                    })
                }
                s(Hc, "sendTimingResults"), Hc(), (0, Ve.kz)(Xe), (0, Ve.Y)(Xe), (0, Ve.Tx)(Xe), (0, Ve.Tb)(Xe), (0, Ve.CA)(Xe), (0, l.on)("click", ".js-toggler-container .js-toggler-target", function(e) {
                    if (e.button !== 0) return;
                    const t = e.currentTarget.closest(".js-toggler-container");
                    t && t.classList.toggle("on")
                }), (0, T.AC)(".js-toggler-container", async (e, t) => {
                    e.classList.remove("success", "error"), e.classList.add("loading");
                    try {
                        await t.text(), e.classList.add("success")
                    } catch {
                        e.classList.add("error")
                    } finally {
                        e.classList.remove("loading")
                    }
                }), async function() {
                    var e;
                    if ("serviceWorker" in navigator) {
                        await fe.x;
                        const t = (e = document.querySelector('link[rel="service-worker-src"]')) == null ? void 0 : e.href;
                        t ? navigator.serviceWorker.register(t, {
                            scope: "/"
                        }) : await Bc()
                    }
                }();
                async function Bc() {
                    let e = [];
                    try {
                        e = await navigator.serviceWorker.getRegistrations()
                    } catch (t) {
                        if (t.name === "SecurityError") return
                    }
                    for (const t of e) t.unregister()
                }
                s(Bc, "unregisterAllServiceWorkers");
                var he = u(79785);
                if ((0, pe.c)("TURBO")) {
                    (async () => {
                        const {
                            PageRenderer: t,
                            session: n,
                            navigator: o
                        } = await u.e(6184).then(u.bind(u, 36184)), r = n.adapter;
                        document.addEventListener("turbo:before-fetch-request", p => {
                            const S = p.target;
                            if ((S == null ? void 0 : S.tagName) === "TURBO-FRAME" && (r.progressBar.setValue(0), r.progressBar.show()), (S == null ? void 0 : S.tagName) === "HTML") {
                                const q = p;
                                q.detail.fetchOptions.headers["Turbo-Visit"] = "true"
                            }
                        }), document.addEventListener("turbo:frame-render", p => {
                            const S = p.target;
                            (S == null ? void 0 : S.tagName) === "TURBO-FRAME" && (r.progressBar.setValue(100), r.progressBar.hide())
                        });
                        const i = Object.getOwnPropertyDescriptor(t.prototype, "trackedElementsAreIdentical").get;
                        Object.defineProperty(t.prototype, "trackedElementsAreIdentical", {
                            get() {
                                const p = i.call(this);
                                return p || a(this.currentHeadSnapshot, this.newHeadSnapshot), p
                            }
                        });

                        function a(p, S) {
                            const q = Object.fromEntries(c(p));
                            for (const [O, B] of c(S))
                                if (q[O] !== B) {
                                    (0, he.Ak)(`${O.replace(/^x-/,"")} changed`);
                                    break
                                }
                        }
                        s(a, "setReasonForTurboFail");

                        function* c(p) {
                            for (const S of Object.values(p.detailsByOuterHTML))
                                if (S.tracked)
                                    for (const q of S.elements) q instanceof HTMLMetaElement && q.getAttribute("http-equiv") && (yield [q.getAttribute("http-equiv") || "", q.getAttribute("content") || ""])
                        }
                        s(c, "getSnapshotSignatures");

                        function m(p) {
                            const S = history[p];
                            history[p] = function(q, O, B) {
                                var K;

                                function oe(J, ne, W) {
                                    S.call(this, { ...q,
                                        ...J
                                    }, ne, W)
                                }
                                s(oe, "oldHistoryWithMergedState"), o.history.update(oe, new URL(B || location.href, location.href), (K = q == null ? void 0 : q.turbo) == null ? void 0 : K.restorationIdentifier)
                            }
                        }
                        s(m, "patchHistoryApi"), m("replaceState"), m("pushState")
                    })();
                    const e = s((t, n) => {
                        const o = new URL(t, window.location.origin),
                            r = new URL(n, window.location.origin);
                        return Boolean(r.hash) && o.hash !== r.hash && o.host === r.host && o.pathname === r.pathname && o.search === r.search
                    }, "isHashNavigation");
                    document.addEventListener("turbo:click", function(t) {
                        if (!(t.target instanceof HTMLElement)) return;
                        const n = t.target.closest("[data-turbo-frame]");
                        n instanceof HTMLElement && t.target.setAttribute("data-turbo-frame", n.getAttribute("data-turbo-frame") || ""), t instanceof CustomEvent && e(location.href, t.detail.url) && t.preventDefault()
                    }), document.addEventListener("turbo:before-render", t => {
                        if (!(t instanceof CustomEvent)) return;
                        const n = t.detail.newBody.ownerDocument.documentElement,
                            o = document.documentElement;
                        for (const r of o.attributes) !n.hasAttribute(r.nodeName) && r.nodeName !== "aria-busy" && o.removeAttribute(r.nodeName);
                        for (const r of n.attributes) o.getAttribute(r.nodeName) !== r.nodeValue && o.setAttribute(r.nodeName, r.nodeValue)
                    }), document.addEventListener("turbo:visit", he.LD), document.addEventListener("turbo:render", he.FP), document.addEventListener("beforeunload", he.FP), document.addEventListener("turbo:load", t => {
                        Object.keys(t.detail.timing).length === 0 ? (0, he.OE)() || (0, he.Po)() ? (0, he.Ys)() : (0, he.F6)() : (0, he.Xk)()
                    })
                }

                function $c() {
                    if ("Intl" in window) try {
                        return new window.Intl.DateTimeFormat().resolvedOptions().timeZone
                    } catch {}
                }
                s($c, "timezone"), window.requestIdleCallback(() => {
                    const e = $c();
                    e && (0, _e.d8)("tz", encodeURIComponent(e))
                });
                var hr = u(70112),
                    Fc = Object.defineProperty,
                    Uc = Object.getOwnPropertyDescriptor,
                    Q = s((e, t, n, o) => {
                        for (var r = o > 1 ? void 0 : o ? Uc(t, n) : t, i = e.length - 1, a; i >= 0; i--)(a = e[i]) && (r = (o ? a(t, n, r) : a(r)) || r);
                        return o && r && Fc(t, n, r), r
                    }, "webauthn_get_decorateClass"),
                    _c = (e => (e.Initializing = "initializing", e.Unsupported = "unsupported", e.Ready = "ready", e.Waiting = "waiting", e.Error = "error", e.Submitting = "submitting", e))(_c || {});
                let le = s(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.state = "initializing", this.json = "", this.autofocusWhenReady = !1, this.autoPrompt = !1, this.hasErrored = !1
                    }
                    connectedCallback() {
                        this.originalButtonText = this.button.textContent, this.setState((0, hr.Zh)() ? "ready" : "unsupported"), this.autoPrompt && this.prompt(void 0, !0)
                    }
                    setState(e) {
                        this.button.textContent = this.hasErrored ? this.button.getAttribute("data-retry-message") : this.originalButtonText, this.button.disabled = !1, this.button.hidden = !1;
                        for (const t of this.messages) t.hidden = !0;
                        switch (e) {
                            case "initializing":
                                this.button.disabled = !0;
                                break;
                            case "unsupported":
                                this.button.disabled = !0, this.unsupportedMessage.hidden = !1;
                                break;
                            case "ready":
                                this.autofocusWhenReady && this.button.focus();
                                break;
                            case "waiting":
                                this.waitingMessage.hidden = !1, this.button.hidden = !0;
                                break;
                            case "error":
                                this.errorMessage.hidden = !1;
                                break;
                            case "submitting":
                                this.button.textContent = "Verifying\u2026", this.button.disabled = !0;
                                break;
                            default:
                                throw new Error("invalid state")
                        }
                        this.state = e
                    }
                    async prompt(e, t) {
                        e == null || e.preventDefault(), this.dispatchEvent(new CustomEvent("webauthn-get-prompt"));
                        try {
                            t || this.setState("waiting");
                            const n = JSON.parse(this.json),
                                o = await (0, hr.U2)(n);
                            this.setState("submitting");
                            const r = this.closest(".js-webauthn-form"),
                                i = r.querySelector(".js-webauthn-response");
                            i.value = JSON.stringify(o), (0, f.Bt)(r)
                        } catch (n) {
                            if (!t) throw this.hasErrored = !0, this.setState("error"), n
                        }
                    }
                }, "WebauthnGetElement");
                Q([A.fA], le.prototype, "button", 2), Q([A.GO], le.prototype, "messages", 2), Q([A.fA], le.prototype, "unsupportedMessage", 2), Q([A.fA], le.prototype, "waitingMessage", 2), Q([A.fA], le.prototype, "errorMessage", 2), Q([A.Lj], le.prototype, "json", 2), Q([A.Lj], le.prototype, "autofocusWhenReady", 2), Q([A.Lj], le.prototype, "autoPrompt", 2), le = Q([A.Ih], le);
                var Wc = (e => (e.Initializing = "initializing", e.ShowingForm = "showing-form", e.ShowingRevealer = "showing-revealer", e))(Wc || {});
                let He = s(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.state = "showing-form"
                    }
                    connectedCallback() {
                        this.setState(this.state)
                    }
                    setState(e) {
                        switch (this.revealer.hidden = !0, this.form.hidden = !1, e) {
                            case "initializing":
                                break;
                            case "showing-form":
                                this.dispatchEvent(new CustomEvent("sudo-password-showing-form"));
                                break;
                            case "showing-revealer":
                                this.revealer.hidden = !1, this.form.hidden = !0;
                                break;
                            default:
                                throw new Error("invalid state")
                        }
                        this.state = e
                    }
                    reveal() {
                        this.setState("showing-form")
                    }
                }, "SudoPasswordElement");
                Q([A.Lj], He.prototype, "state", 2), Q([A.fA], He.prototype, "revealer", 2), Q([A.fA], He.prototype, "form", 2), Q([A.fA], He.prototype, "passwordField", 2), He = Q([A.Ih], He);
                let jt = s(class extends HTMLElement {
                    connectedCallback() {
                        var e;
                        (e = this.webauthnGet) == null || e.addEventListener("webauthn-get-prompt", () => {
                            this.sudoPassword.setState("showing-revealer")
                        }), this.sudoPassword.addEventListener("sudo-password-showing-form", () => {
                            var t;
                            (t = this.webauthnGet) == null || t.setState("ready"), this.sudoPassword.passwordField.focus()
                        })
                    }
                }, "SudoAuthElement");
                Q([A.fA], jt.prototype, "webauthnGet", 2), Q([A.fA], jt.prototype, "sudoPassword", 2), jt = Q([A.Ih], jt);
                let Sn = 0;

                function zc() {
                    if (!document.hasFocus()) return;
                    const e = document.querySelector(".js-timeline-marker-form");
                    e && e instanceof HTMLFormElement && (0, f.Bt)(e)
                }
                s(zc, "markThreadAsRead");
                const Tt = "IntersectionObserver" in window ? new IntersectionObserver(function(e) {
                    for (const t of e) t.isIntersecting && gr(t.target)
                }, {
                    root: null,
                    rootMargin: "0px",
                    threshold: 1
                }) : null;
                (0, d.N7)(".js-unread-item", {
                    constructor: HTMLElement,
                    add(e) {
                        Sn++, Tt && Tt.observe(e)
                    },
                    remove(e) {
                        Sn--, Tt && Tt.unobserve(e), Sn === 0 && zc()
                    }
                });

                function gr(e) {
                    e.classList.remove("js-unread-item", "unread-item")
                }
                s(gr, "clearUnread"), (0, d.N7)(".js-discussion[data-channel-target]", {
                    subscribe: e => (0, x.RB)(e, "socket:message", function(t) {
                        const n = t.target,
                            o = t.detail.data;
                        if (n.getAttribute("data-channel-target") === o.gid)
                            for (const r of document.querySelectorAll(".js-unread-item")) gr(r)
                    })
                });
                let At = 0;
                const br = /^\(\d+\)\s+/;

                function yr() {
                    const e = At ? `(${At}) ` : "";
                    document.title.match(br) ? document.title = document.title.replace(br, e) : document.title = `${e}${document.title}`
                }
                s(yr, "updateTitle"), (0, d.N7)(".js-unread-item", {
                    add() {
                        At++, yr()
                    },
                    remove() {
                        At--, yr()
                    }
                }), (0, d.N7)(".js-socket-channel.js-updatable-content", {
                    subscribe: e => (0, x.RB)(e, "socket:message", function(t) {
                        const {
                            gid: n,
                            wait: o
                        } = t.detail.data, r = t.target, i = n ? Kc(r, n) : r;
                        i && setTimeout(Ae.x0, o || 0, i)
                    })
                });

                function Kc(e, t) {
                    if (e.getAttribute("data-gid") === t) return e;
                    for (const n of e.querySelectorAll("[data-url][data-gid]"))
                        if (n.getAttribute("data-gid") === t) return n;
                    return null
                }
                s(Kc, "findByGid");
                async function Vc() {
                    if (!(!history.state || !history.state.staleRecords)) {
                        await fe.x;
                        for (const e in history.state.staleRecords)
                            for (const t of document.querySelectorAll(`.js-updatable-content [data-url='${e}'], .js-updatable-content[data-url='${e}']`)) {
                                const n = history.state.staleRecords[e];
                                t instanceof HTMLElement && (0, Ae.Of)(t, n, !0)
                            }(0, R.lO)(null, "", location.href)
                    }
                }
                s(Vc, "reapplyPreviouslyUpdatedContent"), window.addEventListener("pagehide", Ae.z8);
                try {
                    Vc()
                } catch {}(0, l.on)("upload:setup", ".js-upload-avatar-image", function(e) {
                    const {
                        form: t
                    } = e.detail, n = e.currentTarget.getAttribute("data-alambic-organization"), o = e.currentTarget.getAttribute("data-alambic-owner-type"), r = e.currentTarget.getAttribute("data-alambic-owner-id");
                    n && t.append("organization_id", n), o && t.append("owner_type", o), r && t.append("owner_id", r)
                }), (0, l.on)("upload:complete", ".js-upload-avatar-image", function(e) {
                    const {
                        attachment: t
                    } = e.detail, n = `/settings/avatars/${t.id}`;
                    (0, we.W)({
                        content: (0, ce.a)(document, n),
                        detailsClass: "upload-avatar-details"
                    })
                }), (0, l.on)("dialog:remove", ".upload-avatar-details", async function(e) {
                    const o = `/settings/avatars/${e.currentTarget.querySelector("#avatar-crop-form").getAttribute("data-alambic-avatar-id")}?op=destroy`,
                        r = e.currentTarget.querySelector(".js-avatar-post-csrf").getAttribute("value"),
                        i = new Request(o, {
                            method: "POST",
                            headers: {
                                "Scoped-CSRF-Token": r,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                    await self.fetch(i)
                });
                var vr = u(14037);

                function Ct() {
                    if (document.querySelector(":target")) return;
                    const e = (0, vr.$z)(location.hash).toLowerCase(),
                        t = (0, vr.Q)(document, `user-content-${e}`);
                    t && (0, Yt.zT)(t)
                }
                s(Ct, "hashchange"), window.addEventListener("hashchange", Ct), document.addEventListener("pjax:success", Ct), async function() {
                    await fe.x, Ct()
                }(), (0, l.on)("click", "a[href]", function(e) {
                    const {
                        currentTarget: t
                    } = e;
                    t instanceof HTMLAnchorElement && t.href === location.href && location.hash.length > 1 && setTimeout(function() {
                        e.defaultPrevented || Ct()
                    })
                });
                var Yl = u(30463);
                async function Xc(e) {
                    const t = e.currentTarget,
                        {
                            init: n
                        } = await u.e(5691).then(u.bind(u, 35691));
                    n(t)
                }
                s(Xc, "user_status_loader_load"), (0, d.N7)(".js-user-status-container", {
                    subscribe: e => (0, x.RB)(e, "click", Xc, {
                        once: !0
                    })
                });
                var kt = u(78694);

                function Gc(e, t) {
                    const n = e.querySelector(".js-user-list-base");
                    n && (n.textContent = t || n.getAttribute("data-generic-message"), n.hidden = !1)
                }
                s(Gc, "setFlashError");

                function wr(e, t) {
                    const o = (t || e).querySelectorAll(".js-user-list-error");
                    for (const a of o) a.hidden = !0;
                    const r = t ? [t] : e.querySelectorAll(".errored.js-user-list-input-container");
                    for (const a of r) a.classList.remove("errored");
                    const i = e.querySelector(".js-user-list-base");
                    i && (i.hidden = !0)
                }
                s(wr, "resetValidation"), (0, T.AC)(".js-user-list-form", async function(e, t) {
                    var n;
                    wr(e);
                    const o = e.querySelector("[data-submitting-message]"),
                        r = o == null ? void 0 : o.textContent;
                    o && (o.textContent = o.getAttribute("data-submitting-message"), o.disabled = !0);
                    for (const i of e.querySelectorAll(".js-user-list-input")) i.disabled = !0;
                    try {
                        const i = await t.html();
                        (0, l.f)(e, "user-list-form:success", i.html)
                    } catch (i) {
                        if (((n = i.response) == null ? void 0 : n.status) === 422) e.replaceWith(i.response.html);
                        else {
                            Gc(e), o && (r && (o.textContent = r), o.disabled = !1);
                            for (const a of e.querySelectorAll(".js-user-list-input")) a.disabled = !1
                        }
                    }
                }), (0, l.on)("user-list-form:success", ".js-follow-list", e => {
                    const t = e.detail,
                        n = t instanceof DocumentFragment ? t.querySelector(".js-target-url") : null;
                    (n == null ? void 0 : n.textContent) ? location.href = n.textContent: location.reload()
                });

                function Er(e) {
                    if (!(e.currentTarget instanceof HTMLElement)) return;
                    const t = e.currentTarget.closest(".js-user-list-form"),
                        n = e.currentTarget.closest(".js-user-list-input-container");
                    t && n && wr(t, n)
                }
                s(Er, "clearErrorsFromInput"), (0, P.q6)(".js-user-list-form input", Er), (0, P.q6)(".js-user-list-form textarea", Er), (0, l.on)("auto-check-error", ".js-user-list-form input", function(e) {
                    const t = e.currentTarget.closest(".js-user-list-input-container"),
                        n = t == null ? void 0 : t.querySelector(".js-user-list-error");
                    n && (n.hidden = !1)
                });

                function Zc(e) {
                    var t;
                    const n = new Map;
                    for (const o of e) {
                        const r = (t = o.querySelector(".js-user-lists-create-trigger")) == null ? void 0 : t.getAttribute("data-repository-id");
                        if (r) {
                            const i = n.get(r);
                            i ? i.push(o) : n.set(r, [o])
                        }
                    }
                    return n
                }
                s(Zc, "groupRootsByRepositoryId");
                async function Jc(e, t, n) {
                    const o = new FormData;
                    o.set("authenticity_token", t);
                    for (const a of n) o.append("repository_ids[]", a);
                    const r = await fetch(e, {
                            method: "POST",
                            body: o,
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        }),
                        i = new Map;
                    if (r.ok) {
                        const a = await r.json();
                        for (const c in a) i.set(c, (0, L.r)(document, a[c]))
                    }
                    return i
                }
                s(Jc, "requestMenuBatchRender");

                function Yc(e, t) {
                    for (const [n, o] of e.entries()) {
                        const r = t.get(n) || [];
                        for (const i of r) i.replaceWith(r.length === 1 ? o : o.cloneNode(!0))
                    }
                }
                s(Yc, "replaceUserListMenuRoots");
                async function Lr() {
                    var e;
                    const t = document.querySelectorAll(".js-user-list-menu-content-root");
                    if (t.length === 0) return;
                    const n = t[0].getAttribute("data-batch-update-url");
                    if (!n) return;
                    const o = (e = t[0].querySelector(".js-user-list-batch-update-csrf")) == null ? void 0 : e.value;
                    if (!o) return;
                    const r = Zc(t),
                        i = r.keys(),
                        a = await Jc(n, o, i);
                    a.size > 0 && Yc(a, r)
                }
                s(Lr, "updateAllUserListMenus");

                function Qc(e) {
                    const t = new Promise((n, o) => {
                        e.addEventListener("user-list-menu-form:success", () => n()), e.addEventListener("user-list-menu-form:error", r => o(r))
                    });
                    return (0, f.Bt)(e), t
                }
                s(Qc, "requestUserListMenuFormSubmit");

                function el(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLDetailsElement) || t.hasAttribute("open")) return;
                    const n = t.querySelector(".js-user-list-menu-form");
                    n && (0, kt.T)(n) && (0, f.Bt)(n);
                    const o = t.querySelector(".js-user-list-create-trigger-text");
                    o && (o.textContent = "")
                }
                s(el, "submitUserListFormOnToggle"), (0, l.on)("toggle", ".js-user-list-menu", el, {
                    capture: !0
                }), (0, P.q6)(".js-user-lists-menu-filter", e => {
                    const t = e.currentTarget,
                        n = t.value.trim(),
                        o = t.closest(".js-user-list-menu-content-root"),
                        r = o == null ? void 0 : o.querySelector(".js-user-list-create-trigger-text");
                    !r || (r.textContent = n ? `"${n}"` : "")
                }), (0, T.AC)(".js-user-list-menu-form", async function(e, t) {
                    let n;
                    try {
                        n = await t.json()
                    } catch (r) {
                        (0, w.v)(), (0, l.f)(e, "user-list-menu-form:error", r);
                        return
                    }
                    if (n.json.didStar) {
                        const r = e.closest(".js-toggler-container");
                        r && r.classList.add("on");
                        const i = n.json.starCount;
                        if (i) {
                            const a = e.closest(".js-social-container");
                            a && Zo(a, i)
                        }
                    }
                    const o = e.closest(".js-user-list-menu-content-root[data-update-after-submit]");
                    if (o)
                        for (const r of e.querySelectorAll(".js-user-list-menu-item")) r.checked = r.defaultChecked;
                    n.json.didCreate ? await Lr() : o && await (0, Ae.x0)(o), (0, l.f)(e, "user-list-menu-form:success")
                }), (0, l.on)("click", ".js-user-list-delete-confirmation-trigger", e => {
                    const {
                        currentTarget: t
                    } = e, n = t.getAttribute("data-template-id");
                    if (!n) return;
                    const o = document.getElementById(n);
                    if (!o || !(o instanceof HTMLTemplateElement)) return;
                    const r = t.closest(".js-edit-user-list-dialog");
                    r && (r.open = !1);
                    const i = o.content.cloneNode(!0),
                        a = o.getAttribute("data-labelledby");
                    (0, we.W)({
                        content: i,
                        labelledBy: a
                    })
                }), (0, l.on)("click", ".js-user-lists-create-trigger", async function(e) {
                    const {
                        currentTarget: t
                    } = e, n = document.querySelector(".js-user-list-create-dialog-template"), o = e.currentTarget.getAttribute("data-repository-id"), r = t.closest(".js-user-list-menu-content-root"), i = r == null ? void 0 : r.querySelector(".js-user-lists-menu-filter"), a = i == null ? void 0 : i.value.trim();
                    if (!n || !(n instanceof HTMLTemplateElement) || !o) {
                        t instanceof HTMLButtonElement && (t.disabled = !0);
                        return
                    }
                    const c = n.getAttribute("data-label");
                    if (r && (0, kt.T)(r)) {
                        const S = r.querySelector(".js-user-list-menu-form");
                        S && await Qc(S)
                    }
                    const m = new rt.R(n, {
                            repositoryId: o,
                            placeholderName: a
                        }),
                        p = await (0, we.W)({
                            content: m,
                            label: c
                        });
                    p.addEventListener("user-list-form:success", async () => {
                        await Lr();
                        const S = p.closest("details");
                        S && (S.open = !1)
                    })
                }), (0, d.N7)("[data-warn-unsaved-changes]", {
                    add(e) {
                        e.addEventListener("input", xt), e.addEventListener("change", xt), e.addEventListener("submit", Ge);
                        const t = e.closest("details-dialog");
                        t && (t.closest("details").addEventListener("toggle", Sr), t.addEventListener("details-dialog-close", jr))
                    },
                    remove(e) {
                        e.removeEventListener("input", xt), e.removeEventListener("change", xt), e.removeEventListener("submit", Ge);
                        const t = e.closest("details-dialog");
                        t && (t.closest("details").removeEventListener("toggle", Sr), t.removeEventListener("details-dialog-close", jr), Ge())
                    }
                });

                function xt(e) {
                    const t = e.currentTarget;
                    (0, kt.T)(t) ? tl(t): Ge()
                }
                s(xt, "prepareUnsavedChangesWarning");

                function tl(e) {
                    const t = e.getAttribute("data-warn-unsaved-changes") || "Changes you made may not be saved.";
                    window.onbeforeunload = function(n) {
                        return n.returnValue = t, t
                    }
                }
                s(tl, "enableSaveChangesReminder");

                function Ge() {
                    window.onbeforeunload = null
                }
                s(Ge, "disableSaveChangesReminder");

                function Sr({
                    currentTarget: e
                }) {
                    e.hasAttribute("open") || Ge()
                }
                s(Sr, "disableSaveChangesReminderOnClosedDialogs");

                function jr(e) {
                    const t = e.currentTarget;
                    if (!t.closest("details[open]")) return;
                    let o = !0;
                    const r = t.querySelectorAll("form[data-warn-unsaved-changes]");
                    for (const i of r)
                        if ((0, kt.T)(i)) {
                            const a = i.getAttribute("data-warn-unsaved-changes");
                            o = confirm(a);
                            break
                        }
                    o || e.preventDefault()
                }
                s(jr, "promptOnDialogClosing"), (0, d.N7)(".will-transition-once", {
                    constructor: HTMLElement,
                    subscribe: e => (0, x.RB)(e, "transitionend", nl)
                });

                function nl(e) {
                    e.target.classList.remove("will-transition-once")
                }
                s(nl, "onTransitionEnd");
                async function ol(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-url");
                    if (!n || rl(t)) return;
                    const o = t.getAttribute("data-id") || "",
                        r = t.textContent,
                        i = document.querySelectorAll(`.js-issue-link[data-id='${o}']`);
                    for (const a of i) a.removeAttribute("data-url");
                    try {
                        const a = `${n}/title`,
                            c = await fetch(a, {
                                headers: {
                                    "X-Requested-With": "XMLHttpRequest",
                                    Accept: "application/json"
                                }
                            });
                        if (!c.ok) {
                            const p = new Error,
                                S = c.statusText ? ` ${c.statusText}` : "";
                            throw p.message = `HTTP ${c.status}${S}`, p
                        }
                        const m = await c.json();
                        Tr(i, `${r}, ${m.title}`)
                    } catch (a) {
                        const c = (a.response != null ? a.response.status : void 0) || 500,
                            m = (() => {
                                switch (c) {
                                    case 404:
                                        return t.getAttribute("data-permission-text");
                                    default:
                                        return t.getAttribute("data-error-text")
                                }
                            })();
                        Tr(i, m || "")
                    }
                }
                s(ol, "issueLabel");

                function Tr(e, t) {
                    for (const n of e) n instanceof HTMLElement && (n.classList.add("tooltipped", "tooltipped-ne"), n.setAttribute("aria-label", t))
                }
                s(Tr, "setLabel");

                function rl(e) {
                    switch (e.getAttribute("data-hovercard-type")) {
                        case "issue":
                        case "pull_request":
                            return !!e.closest("[data-issue-and-pr-hovercards-enabled]");
                        case "discussion":
                            return !!e.closest("[data-discussion-hovercards-enabled]");
                        default:
                            return !1
                    }
                }
                s(rl, "isHovercardEnabled"), (0, d.N7)(".js-issue-link", {
                    subscribe: e => (0, x.RB)(e, "mouseenter", ol)
                });
                var sl = u(12085),
                    qe = u.n(sl);

                function jn() {
                    return [Math.floor(Math.random() * (255 - 0) + 0), Math.floor(Math.random() * (255 - 0) + 0), Math.floor(Math.random() * (255 - 0) + 0)]
                }
                s(jn, "randomRGBColor");

                function Ze(e, t) {
                    const n = qe().rgb.hsl(t);
                    e.style.setProperty("--label-r", t[0].toString()), e.style.setProperty("--label-g", t[1].toString()), e.style.setProperty("--label-b", t[2].toString()), e.style.setProperty("--label-h", n[0].toString()), e.style.setProperty("--label-s", n[1].toString()), e.style.setProperty("--label-l", n[2].toString())
                }
                s(Ze, "setColorSwatch");

                function Tn(e, t) {
                    e.blur();
                    const n = e.closest("form"),
                        o = n.querySelector(".js-new-label-color-input");
                    (0, f.Se)(o, `#${qe().rgb.hex(t)}`);
                    const r = n.querySelector(".js-new-label-color");
                    Ze(r, t)
                }
                s(Tn, "setInputColorFromButton");

                function il(e, t) {
                    e.closest(".js-label-error-container").classList.add("errored"), e.textContent = t, e.hidden = !1
                }
                s(il, "addErrorToField");

                function al(e) {
                    e.closest(".js-label-error-container").classList.remove("errored"), e.hidden = !0
                }
                s(al, "removeErrorFromField");

                function Be(e, t, n) {
                    const o = t.querySelector(e);
                    !o || (n ? il(o, n[0]) : al(o))
                }
                s(Be, "showOrHideLabelError");

                function An(e, t) {
                    Be(".js-label-name-error", e, t.name), Be(".js-label-description-error", e, t.description), Be(".js-label-color-error", e, t.color)
                }
                s(An, "showLabelErrors");

                function Re(e) {
                    Be(".js-label-name-error", e, null), Be(".js-label-description-error", e, null), Be(".js-label-color-error", e, null)
                }
                s(Re, "hideLabelErrors");

                function cl(e, t, n, o, r) {
                    const i = new URL(`${e}${encodeURIComponent(t)}`, window.location.origin),
                        a = new URLSearchParams(i.search.slice(1));
                    return a.append("color", n), o && a.append("description", o), r && a.append("id", r), i.search = a.toString(), i.toString()
                }
                s(cl, "labelPreviewUrl");

                function ll(e) {
                    let t = null;
                    const n = e.querySelector(".js-new-label-description-input");
                    return n instanceof HTMLInputElement && n.value.trim().length > 0 && (t = n.value.trim()), t
                }
                s(ll, "labelDescriptionFrom");

                function ul(e) {
                    const t = e.querySelector(".js-new-label-color-input");
                    return t.checkValidity() ? t.value.trim().replace(/^#/, "") : "ededed"
                }
                s(ul, "labelColorFrom");

                function dl(e, t) {
                    let o = e.querySelector(".js-new-label-name-input").value.trim();
                    return o.length < 1 && (o = t.getAttribute("data-default-name")), o
                }
                s(dl, "labelNameFrom");
                async function $e(e) {
                    const t = e.closest(".js-label-preview-container");
                    if (!t) return;
                    const n = e.closest(".js-label-form"),
                        o = n.querySelector(".js-new-label-error"),
                        r = n.getAttribute("data-label-id"),
                        i = t.querySelector(".js-label-preview"),
                        a = dl(n, i);
                    if (!n.checkValidity() && a !== "Label preview") return;
                    const c = ul(n),
                        m = ll(n),
                        p = i.getAttribute("data-url-template"),
                        S = cl(p, a, c, m, r);
                    if (t.hasAttribute("data-last-preview-url")) {
                        const O = t.getAttribute("data-last-preview-url");
                        if (S === O) return
                    }
                    let q;
                    try {
                        q = await (0, ce.a)(document, S)
                    } catch (O) {
                        const B = await O.response.json();
                        An(n, B), o && (o.textContent = B.message, o.hidden = !1);
                        return
                    }
                    o && (o.textContent = "", o.hidden = !0), Re(n), i.innerHTML = "", i.appendChild(q), t.setAttribute("data-last-preview-url", S)
                }
                s($e, "updateLabelPreview");

                function fl(e) {
                    $e(e.target)
                }
                s(fl, "onLabelFormInputChange");

                function Ar(e, t) {
                    e.closest(".js-details-container").classList.toggle("is-empty", t)
                }
                s(Ar, "toggleBlankSlate");

                function Cr(e) {
                    const t = document.querySelector(".js-labels-count"),
                        o = Number(t.textContent) + e;
                    t.textContent = o.toString();
                    const r = document.querySelector(".js-labels-label");
                    return r.textContent = r.getAttribute(o === 1 ? "data-singular-string" : "data-plural-string"), o
                }
                s(Cr, "updateCount"), (0, P.q6)(".js-label-filter-field", function(e) {
                    const t = e.target,
                        o = t.closest("details-menu").querySelector(".js-new-label-name");
                    if (!o) return;
                    const r = t.value.trim();
                    o.textContent = r
                }), (0, l.on)("filterable:change", ".js-filterable-issue-labels", function(e) {
                    const t = e.currentTarget.closest("details-menu"),
                        n = t.querySelector(".js-add-label-button");
                    if (!n) return;
                    const r = e.detail.inputField.value.trim().toLowerCase();
                    let i = !1;
                    for (const a of t.querySelectorAll("input[data-label-name]"))
                        if ((a.getAttribute("data-label-name") || "").toLowerCase() === r) {
                            i = !0;
                            break
                        }
                    n.hidden = r.length === 0 || i
                }), (0, P.ZG)(".js-new-label-color-input", function(e) {
                    const n = e.closest("form").querySelector(".js-new-label-swatches");
                    n.hidden = !1, e.addEventListener("blur", function() {
                        n.hidden = !0
                    }, {
                        once: !0
                    })
                }), (0, P.q6)(".js-new-label-color-input", function(e) {
                    const t = e.target;
                    let n = t.value.trim();
                    if (!(n.length < 1))
                        if (n.indexOf("#") !== 0 && (n = `#${n}`, t.value = n), t.checkValidity()) {
                            t.classList.remove("color-fg-danger");
                            const r = t.closest("form").querySelector(".js-new-label-color");
                            Ze(r, qe().hex.rgb(n))
                        } else t.classList.add("color-fg-danger")
                }), (0, P.w4)("keyup", ".js-new-label-color-input", function(e) {
                    const t = e.target;
                    let n = t.value.trim();
                    if (n.indexOf("#") !== 0 && (n = `#${n}`, t.value = n), t.checkValidity()) {
                        const i = t.closest("form").querySelector(".js-new-label-color");
                        Ze(i, qe().hex.rgb(n))
                    }(0, l.f)(t, "change", !1);
                    const o = t.closest("form");
                    Re(o)
                }), (0, P.w4)("keyup", ".js-new-label-description-input", function(e) {
                    const n = e.target.form;
                    Re(n)
                }), (0, P.w4)("keyup", ".js-new-label-color-input", function(e) {
                    const n = e.target.form;
                    Re(n)
                }), (0, l.on)("click", ".js-new-label-color", async function(e) {
                    const t = e.currentTarget,
                        n = jn();
                    Tn(t, n), $e(t)
                }), (0, l.on)("mousedown", ".js-new-label-color-swatch", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-color");
                    Tn(t, qe().hex.rgb(n)), $e(t);
                    const o = t.closest(".js-new-label-swatches");
                    o.hidden = !0
                }), (0, l.on)("toggle", ".js-new-label-modal", function(e) {
                    e.target.hasAttribute("open") && kr(e.target)
                }, {
                    capture: !0
                });
                async function kr(e) {
                    const t = e.querySelector(".js-new-label-name-input");
                    if (!t) return;
                    const n = e.querySelector(".js-new-label-color-input"),
                        o = jn(),
                        r = `#${qe().rgb.hex(o)}`;
                    n.value = r;
                    const i = e.querySelector(".js-new-label-color");
                    Ze(i, o);
                    const c = document.querySelector(".js-new-label-name").textContent;
                    (0, f.Se)(t, c), (0, Nt.OD)(t), $e(i)
                }
                s(kr, "initLabelModal"), (0, T.AC)(".js-new-label-modal-form", async function(e, t) {
                    const n = e.querySelector(".js-new-label-error");
                    let o;
                    try {
                        o = await t.html()
                    } catch (m) {
                        const p = m.response.json;
                        n.textContent = p.message, n.hidden = !1
                    }
                    if (!o) return;
                    n.hidden = !0, document.querySelector(".js-new-label-modal").removeAttribute("open");
                    const r = document.querySelector(".js-issue-labels-menu-content"),
                        i = r.querySelector(".js-filterable-issue-labels"),
                        a = o.html.querySelector("input");
                    i.prepend(o.html), a && a.dispatchEvent(new Event("change", {
                        bubbles: !0
                    }));
                    const c = r.querySelector(".js-label-filter-field");
                    c.value = c.defaultValue, c.focus()
                }), (0, l.on)("click", ".js-edit-label-cancel", function(e) {
                    const t = e.target.closest("form");
                    Re(t), t.reset();
                    const n = t.querySelector(".js-new-label-color-input"),
                        o = n.value,
                        r = t.querySelector(".js-new-label-color");
                    Ze(r, qe().hex.rgb(o)), (0, Nt.Qc)(t), $e(n);
                    const i = e.currentTarget.closest(".js-labels-list-item");
                    if (i) {
                        i.querySelector(".js-update-label").classList.add("d-none");
                        const c = i.querySelector(".js-label-preview");
                        c && (c.classList.add("d-none"), i.querySelector(".js-label-link").classList.remove("d-none"));
                        const m = i.querySelectorAll(".js-hide-on-label-edit");
                        for (const p of m) p.hidden = !p.hidden
                    }
                }), (0, T.AC)(".js-update-label", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch (r) {
                        const i = r.response.json;
                        An(e, i);
                        return
                    }
                    Re(e), e.closest(".js-labels-list-item").replaceWith(n.html)
                }), (0, T.AC)(".js-create-label", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch (a) {
                        const c = a.response.json;
                        An(e, c);
                        return
                    }
                    e.reset(), Re(e), document.querySelector(".js-label-list").prepend(n.html), Cr(1), Ar(e, !1);
                    const o = e.querySelector(".js-new-label-color"),
                        r = jn();
                    Tn(o, r), $e(e.querySelector(".js-new-label-name-input")), (0, Nt.Qc)(e);
                    const i = e.closest(".js-details-container");
                    i instanceof HTMLElement && (0, zt.Qp)(i)
                }), (0, l.on)("click", ".js-details-target-new-label", function() {
                    document.querySelector(".js-create-label").querySelector(".js-new-label-name-input").focus()
                }), (0, l.on)("click", ".js-edit-label", function(e) {
                    const t = e.currentTarget.closest(".js-labels-list-item"),
                        n = t.querySelector(".js-update-label");
                    n.classList.remove("d-none"), n.querySelector(".js-new-label-name-input").focus();
                    const r = t.querySelector(".js-label-preview");
                    r && (r.classList.remove("d-none"), t.querySelector(".js-label-link").classList.add("d-none"));
                    const i = t.querySelectorAll(".js-hide-on-label-edit");
                    for (const a of i) a.hidden = !a.hidden
                }), (0, T.AC)(".js-delete-label", async function(e, t) {
                    const n = e.closest(".js-labels-list-item");
                    n.querySelector(".js-label-delete-spinner").hidden = !1, await t.text();
                    const o = Cr(-1);
                    Ar(e, o === 0), n.remove()
                });
                const Mt = (0, U.D)(fl, 500);
                (0, l.on)("suggester:complete", ".js-new-label-name-input", Mt), (0, P.q6)(".js-new-label-name-input", Mt), (0, P.q6)(".js-new-label-description-input", Mt), (0, P.q6)(".js-new-label-color-input", Mt), (0, P.w4)("keypress", ".js-new-label-name-input", function(e) {
                    const t = e.target,
                        n = parseInt(t.getAttribute("data-maxlength"));
                    (0, be.rq)(t.value) >= n && e.preventDefault()
                }), (0, l.on)("click", ".js-issues-label-select-menu-item", function(e) {
                    !e.altKey && !e.shiftKey || (e.preventDefault(), e.stopPropagation(), e.altKey && (window.location.href = e.currentTarget.getAttribute("data-excluded-url")), e.shiftKey && (window.location.href = e.currentTarget.getAttribute("data-included-url")))
                }), (0, P.w4)("keydown", ".js-issues-label-select-menu-item", function(e) {
                    if (e.key !== "Enter" || !e.altKey && !e.shiftKey) return;
                    const t = e.currentTarget;
                    e.preventDefault(), e.stopPropagation(), t instanceof HTMLAnchorElement && (e.altKey && (window.location.href = t.getAttribute("data-excluded-url")), e.shiftKey && (window.location.href = t.getAttribute("data-included-url")))
                }), (0, l.on)("click", ".js-open-label-creation-modal", async function(e) {
                    e.stopImmediatePropagation();
                    const t = await (0, we.W)({
                        content: document.querySelector(".js-label-creation-template").content.cloneNode(!0),
                        detailsClass: "js-new-label-modal"
                    });
                    kr(t)
                }, {
                    capture: !0
                }), (0, l.on)("change", ".js-thread-notification-setting", Cn), (0, l.on)("change", ".js-custom-thread-notification-option", Cn), (0, l.on)("reset", ".js-custom-thread-settings-form", Cn);

                function Cn() {
                    const e = document.querySelector(".js-reveal-custom-thread-settings").checked,
                        t = !document.querySelector(".js-custom-thread-notification-option:checked"),
                        n = document.querySelector(".js-custom-thread-settings"),
                        o = document.querySelector("[data-custom-option-required-text]"),
                        r = e && t ? o.getAttribute("data-custom-option-required-text") : "";
                    o.setCustomValidity(r), n.hidden = !e
                }
                s(Cn, "toggleEventSettings");
                var ml = Object.defineProperty,
                    pl = Object.getOwnPropertyDescriptor,
                    xr = s((e, t, n, o) => {
                        for (var r = o > 1 ? void 0 : o ? pl(t, n) : t, i = e.length - 1, a; i >= 0; i--)(a = e[i]) && (r = (o ? a(t, n, r) : a(r)) || r);
                        return o && r && ml(t, n, r), r
                    }, "sidebar_widget_decorateClass");
                let kn = s(class extends HTMLElement {
                    get activeClass() {
                        return this.getAttribute("active-class") || "collapsible-sidebar-widget-active"
                    }
                    get loadingClass() {
                        return this.getAttribute("loading-class") || "collapsible-sidebar-widget-loading"
                    }
                    get url() {
                        return this.getAttribute("url") || ""
                    }
                    get isOpen() {
                        return this.hasAttribute("open")
                    }
                    set isOpen(e) {
                        e ? this.setAttribute("open", "") : this.removeAttribute("open")
                    }
                    onKeyDown(e) {
                        if (e.code === "Enter" || e.code === "Space") return e.preventDefault(), this.load()
                    }
                    onMouseDown(e) {
                        return e.preventDefault(), this.load()
                    }
                    load() {
                        return this.pendingRequest ? this.pendingRequest.abort() : this.collapsible.hasAttribute("loaded") ? this.isOpen ? this.setClose() : this.setOpen() : (this.setLoading(), this.updateCollapsible())
                    }
                    setLoading() {
                        this.classList.add(this.loadingClass), this.classList.remove(this.activeClass)
                    }
                    setOpen() {
                        this.classList.add(this.activeClass), this.classList.remove(this.loadingClass), this.isOpen = !0
                    }
                    setClose() {
                        this.classList.remove(this.activeClass), this.classList.remove(this.loadingClass), this.isOpen = !1
                    }
                    handleAbort() {
                        this.pendingRequest = null, this.setClose()
                    }
                    async updateCollapsible() {
                        var e;
                        try {
                            this.pendingRequest = new AbortController, this.pendingRequest.signal.addEventListener("abort", () => this.handleAbort());
                            const t = await fetch(this.url, {
                                signal: (e = this.pendingRequest) == null ? void 0 : e.signal,
                                headers: {
                                    Accept: "text/html",
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            });
                            if (this.pendingRequest = null, !t.ok) return this.setClose();
                            const n = await t.text();
                            this.collapsible.innerHTML = n, this.collapsible.setAttribute("loaded", ""), this.setOpen()
                        } catch {
                            return this.pendingRequest = null, this.setClose()
                        }
                    }
                }, "CollapsibleSidebarWidgetElement");
                xr([A.fA], kn.prototype, "collapsible", 2), kn = xr([A.Ih], kn);
                var hl = Object.defineProperty,
                    gl = Object.getOwnPropertyDescriptor,
                    ge = s((e, t, n, o) => {
                        for (var r = o > 1 ? void 0 : o ? gl(t, n) : t, i = e.length - 1, a; i >= 0; i--)(a = e[i]) && (r = (o ? a(t, n, r) : a(r)) || r);
                        return o && r && hl(t, n, r), r
                    }, "sidebar_memex_input_decorateClass");
                let ue = s(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.url = "", this.csrf = "", this.instrument = "", this.column = 1
                    }
                    get isDisabled() {
                        var e;
                        return (e = this.read) == null ? void 0 : e.hasAttribute("disabled")
                    }
                    set hasErrored(e) {
                        e ? this.setAttribute("errored", "") : this.removeAttribute("errored")
                    }
                    set disabled(e) {
                        e ? this.setAttribute("disabled", "") : this.removeAttribute("disabled")
                    }
                    get hasExpanded() {
                        return this.read.getAttribute("aria-expanded") === "true"
                    }
                    connectedCallback() {
                        var e, t;
                        this.disabled = (t = (e = this.read) == null ? void 0 : e.disabled) != null ? t : !0, this.querySelector("details") !== null && this.classList.toggle("no-pointer")
                    }
                    handleDetailsSelect(e) {
                        var t;
                        const n = e,
                            o = e.target,
                            r = (t = n.detail) == null ? void 0 : t.relatedTarget,
                            i = o.closest("details"),
                            a = i == null ? void 0 : i.querySelector("[data-menu-button]");
                        if (r.getAttribute("aria-checked") === "true") {
                            r.setAttribute("aria-checked", "false"), e.preventDefault();
                            for (const c of this.inputs)
                                if (r.contains(c)) {
                                    this.updateCell(c.name, ""), (a == null ? void 0 : a.innerHTML) && (a.innerHTML = c.placeholder);
                                    break
                                }
                            i == null || i.removeAttribute("open")
                        }
                    }
                    handleDetailsSelected(e) {
                        var t;
                        const o = (t = e.detail) == null ? void 0 : t.relatedTarget;
                        for (const r of this.inputs)
                            if (o.contains(r)) {
                                this.updateCell(r.name, r.value);
                                break
                            }
                    }
                    mouseDownFocus(e) {
                        !this.isDisabled || this.onFocus(e)
                    }
                    keyDownFocus(e) {
                        (e.code === "Enter" || e.code === "Space") && this.read !== document.activeElement && this.onFocus(e)
                    }
                    onChange(e) {
                        var t, n;
                        e.target.getAttribute("type") !== "date" && this.updateCell((t = this.read) == null ? void 0 : t.name, (n = this.read) == null ? void 0 : n.value)
                    }
                    onFocus(e) {
                        e.preventDefault(), this.disabled = !1, this.read.disabled = !1, this.read.focus()
                    }
                    onBlur(e) {
                        var t, n;
                        if (this.hasExpanded) {
                            e.preventDefault();
                            return
                        }
                        e.target.getAttribute("type") === "date" && this.updateCell((t = this.read) == null ? void 0 : t.name, (n = this.read) == null ? void 0 : n.value), this.read.disabled = !0, this.disabled = !0
                    }
                    onKeyDown(e) {
                        if (e.code === "Enter" || e.code === "Tab") {
                            if (e.preventDefault(), e.stopPropagation(), this.hasExpanded) return;
                            this.read.blur()
                        }
                    }
                    async updateCell(e = "", t = "") {
                        const n = new FormData;
                        n.set(e, t), n.set("ui", this.instrument);
                        for (const r of this.parameters) n.set(r.name, r.value);
                        const o = Intl.DateTimeFormat("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                            timeZone: "UTC"
                        });
                        try {
                            if (this.write) {
                                const S = this.read.value,
                                    q = this.read.type === "date" && S ? o.format(Date.parse(S)) : S;
                                this.write.textContent = S ? q : this.read.placeholder
                            }
                            const r = await fetch(this.url, {
                                method: "PUT",
                                body: n,
                                headers: {
                                    Accept: "application/json",
                                    "X-Requested-With": "XMLHttpRequest",
                                    "Scoped-CSRF-Token": `${this.csrf}`
                                }
                            });
                            if (!r.ok) throw new Error("connection error");
                            if (!this.write) return;
                            const c = (await r.json()).memexProjectItem.memexProjectColumnValues.find(S => S.memexProjectColumnId === Number(this.column)).value,
                                m = this.read.type === "date" ? Date.parse(c.value) : c.html,
                                p = this.read.type === "date" && m ? o.format(m) : m;
                            this.write.innerHTML = t ? p : this.read.placeholder
                        } catch {
                            this.hasErrored = !0
                        }
                    }
                }, "SidebarMemexInputElement");
                ge([A.Lj], ue.prototype, "url", 2), ge([A.Lj], ue.prototype, "csrf", 2), ge([A.Lj], ue.prototype, "instrument", 2), ge([A.Lj], ue.prototype, "column", 2), ge([A.GO], ue.prototype, "inputs", 2), ge([A.fA], ue.prototype, "read", 2), ge([A.fA], ue.prototype, "write", 2), ge([A.GO], ue.prototype, "parameters", 2), ue = ge([A.Ih], ue);

                function Je(e, t = !1) {
                    (t || !El(e)) && (e instanceof HTMLFormElement ? (0, f.Bt)(e) : Rt(e))
                }
                s(Je, "submitForm");

                function Mr(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-issue-sidebar-form") || t.querySelector(".js-issue-sidebar-form");
                    Je(n)
                }
                s(Mr, "submitOnMenuClose"), (0, l.on)("details-menu-selected", ".js-discussion-sidebar-menu", function(e) {
                    const t = e.detail.relatedTarget,
                        n = e.currentTarget,
                        o = t.closest(".js-issue-sidebar-form"),
                        r = n.hasAttribute("data-multiple");
                    if (t.hasAttribute("data-clear-assignees")) {
                        const i = n.querySelectorAll('input[name="issue[user_assignee_ids][]"]:checked');
                        for (const a of i) a.disabled = !1, a.checked = !1;
                        Je(o)
                    } else r ? n.closest("details").addEventListener("toggle", Mr, {
                        once: !0
                    }) : Je(o)
                }, {
                    capture: !0
                });

                function bl(e, t) {
                    e.replaceWith((0, L.r)(document, t))
                }
                s(bl, "updateSidebar");

                function qr(e) {
                    const t = document.querySelector(`[data-menu-trigger="${e}"]`);
                    t == null || t.focus()
                }
                s(qr, "returnFocusToTrigger"), (0, T.AC)(".js-issue-sidebar-form", async function(e, t) {
                    var n;
                    const o = await t.html(),
                        r = e.closest(".js-discussion-sidebar-item"),
                        i = (n = r == null ? void 0 : r.querySelector(".select-menu")) == null ? void 0 : n.getAttribute("id");
                    r.replaceWith(o.html), i && qr(i)
                }), (0, l.on)("click", "div.js-issue-sidebar-form .js-suggested-reviewer", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-issue-sidebar-form");
                    Rt(n, "post", {
                        name: t.name,
                        value: t.value
                    }), e.preventDefault()
                }), (0, l.on)("click", "div.js-issue-sidebar-form .js-issue-assign-self", function(e) {
                    var t;
                    const n = e.currentTarget,
                        o = n.closest(".js-issue-sidebar-form");
                    Rt(o, "post", {
                        name: n.name,
                        value: n.value
                    }), n.remove(), (t = document.querySelector("form#new_issue .is-submit-button-value")) == null || t.remove(), e.preventDefault()
                }), (0, l.on)("click", ".js-issue-unassign-self", function(e) {
                    const t = e.currentTarget.closest(".js-issue-sidebar-form");
                    Rt(t, "delete"), e.preventDefault()
                }), (0, T.AC)(".js-pages-preview-toggle-form", async function(e, t) {
                    const n = await t.json();
                    e.querySelector("button.btn").textContent = n.json.new_button_value
                });

                function yl(e, t) {
                    const n = e.getAttribute("data-cache-name");
                    return `${t}:sidebar:${n}`
                }
                s(yl, "getCacheKey");

                function vl(e, t, n) {
                    const o = e.getAttribute("data-cache-name");
                    if (!o) return;
                    const r = [];
                    for (const [a, c] of t.entries()) a.indexOf(o) !== -1 && r.push([a, c]);
                    const i = r.filter(a => a[1] !== "");
                    i.length > 0 ? sessionStorage.setItem(n, JSON.stringify(i)) : sessionStorage.removeItem(n)
                }
                s(vl, "cacheValues");
                const qt = new Set;

                function Rr() {
                    qt.clear()
                }
                s(Rr, "clearHasFired");
                async function wl(e, t) {
                    const n = e.getAttribute("data-cache-name"),
                        o = sessionStorage.getItem(t);
                    if (!n || !o || qt.has(n)) return;
                    qt.add(n);
                    const r = JSON.parse(o),
                        i = [];
                    for (const [a, c] of r) {
                        if (Object.prototype.toString.call(c) !== "[object String]") continue;
                        const m = document.createElement("input");
                        m.type = "hidden", m.value = c, m.name = a, e.appendChild(m), i.push(m)
                    }
                    try {
                        await Ir(e);
                        for (const a of i) a.remove()
                    } catch {
                        qt.delete(n)
                    }
                }
                s(wl, "restoreCachedValues");
                let Pr = !1;

                function xn(e, t) {
                    if (Pr) return;
                    const n = Mn(e);
                    vl(e, n, t), Rr()
                }
                s(xn, "cacheValuesOnHide"), (0, d.N7)("[data-cacher]", {
                    add(e) {
                        const t = yl(e, (0, je.e)());
                        wl(e, t), window.addEventListener("pagehide", () => xn(e, t)), window.addEventListener("pjax:beforeReplace", () => xn(e, t)), window.addEventListener("turbo:before-visit", () => xn(e, t)), window.addEventListener("submit", n => {
                            n.defaultPrevented || (Pr = !0, setTimeout(() => {
                                for (const o of Object.keys(sessionStorage)) o.indexOf(t) !== -1 && (sessionStorage.removeItem(o), Rr())
                            }, 0))
                        }, {
                            capture: !0
                        })
                    }
                });
                async function Rt(e, t = "post", n) {
                    var o;
                    await Ir(e, t, n);
                    const r = e.closest(".js-discussion-sidebar-item"),
                        i = (o = r == null ? void 0 : r.querySelector(".select-menu")) == null ? void 0 : o.getAttribute("id");
                    i && qr(i)
                }
                s(Rt, "previewSubmit");
                async function Ir(e, t = "post", n) {
                    const o = Mn(e);
                    n && o.append(n.name, n.value);
                    const r = e.getAttribute("data-url");
                    if (!r) return;
                    const i = e.querySelector(".js-data-url-csrf"),
                        a = await fetch(r, {
                            method: t,
                            body: t === "delete" ? "" : o,
                            mode: "same-origin",
                            headers: {
                                "Scoped-CSRF-Token": i.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                    if (!a.ok) return;
                    const c = await a.text();
                    bl(e.closest(".js-discussion-sidebar-item"), c)
                }
                s(Ir, "requestPreview");

                function El(e) {
                    const t = e.getAttribute("data-reviewers-team-size-check-url");
                    if (!t) return !1;
                    const n = [...document.querySelectorAll(".js-reviewer-team")].map(c => c.getAttribute("data-id")),
                        o = e instanceof HTMLFormElement ? new FormData(e) : Mn(e),
                        i = new URLSearchParams(o).getAll("reviewer_team_ids[]").filter(c => !n.includes(c));
                    if (i.length === 0) return !1;
                    const a = new URLSearchParams(i.map(c => ["reviewer_team_ids[]", c]));
                    return Ll(e, `${t}?${a}`), !0
                }
                s(El, "reviewerTeamsCheckRequired");
                async function Ll(e, t) {
                    const n = await fetch(t);
                    if (!n.ok) return;
                    const o = await n.text();
                    if (o.match(/[^\w-]js-large-team[^\w-]/)) Sl(e, o);
                    else {
                        Je(e, !0);
                        return
                    }
                }
                s(Ll, "triggerTeamReviewerCheck");

                function Sl(e, t) {
                    const n = e.querySelector(".js-large-teams-check-warning-container");
                    for (; n.firstChild;) n.removeChild(n.firstChild);
                    n.appendChild((0, L.r)(document, t));
                    const o = n.querySelector("details");

                    function r(i) {
                        if (i.target instanceof Element) {
                            if (o.open = !1, !i.target.classList.contains("js-large-teams-confirm-button")) {
                                const a = e.querySelectorAll("input[name='reviewer_team_ids[]']");
                                for (const c of a) n.querySelector(`.js-large-team[data-id='${c.value}']`) && (c.checked = !1)
                            }
                            Je(e, !0), i.preventDefault()
                        }
                    }
                    s(r, "dialogAction"), n.querySelector(".js-large-teams-confirm-button").addEventListener("click", r, {
                        once: !0
                    }), n.querySelector(".js-large-teams-cancel-button").addEventListener("click", r, {
                        once: !0
                    }), o.addEventListener("details-dialog-close", r, {
                        once: !0
                    }), o.open = !0
                }
                s(Sl, "showTeamReviewerConfirmationDialog"), (0, l.on)("click", "div.js-project-column-menu-container .js-project-column-menu-item button", async function(e) {
                    const t = e.currentTarget;
                    jl(t);
                    const n = t.getAttribute("data-url"),
                        o = t.parentElement.querySelector(".js-data-url-csrf"),
                        r = t.getAttribute("data-card-id"),
                        i = new FormData;
                    if (i.append("card_id", r), i.append("use_automation_prioritization", "true"), e.preventDefault(), !(await fetch(n, {
                            method: "PUT",
                            mode: "same-origin",
                            body: i,
                            headers: {
                                "Scoped-CSRF-Token": o.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).ok) return;
                    const c = document.activeElement,
                        m = t.closest(".js-project-column-menu-dropdown");
                    if (c && m.contains(c)) try {
                        c.blur()
                    } catch {}
                });

                function jl(e) {
                    const n = e.closest(".js-project-column-menu-dropdown").querySelector(".js-project-column-menu-summary"),
                        o = e.getAttribute("data-column-name");
                    n.textContent = o
                }
                s(jl, "updateProjectColumnMenuSummary"), (0, l.on)("click", ".js-prompt-dismiss", function(e) {
                    e.currentTarget.closest(".js-prompt").remove()
                });

                function Mn(e) {
                    const t = e.closest("form");
                    if (!t) return new FormData;
                    const o = new FormData(t).entries(),
                        r = new FormData;
                    for (const [i, a] of o) t.contains(Tl(t, i, a.toString())) && r.append(i, a);
                    return r
                }
                s(Mn, "scopedFormData");

                function Tl(e, t, n) {
                    for (const o of e.elements)
                        if ((o instanceof HTMLInputElement || o instanceof HTMLTextAreaElement || o instanceof HTMLButtonElement) && o.name === t && o.value === n) return o;
                    return null
                }
                s(Tl, "findParam"), (0, l.on)("click", ".js-convert-to-draft", function(e) {
                    const t = e.currentTarget.getAttribute("data-url"),
                        n = e.currentTarget.parentElement.querySelector(".js-data-url-csrf");
                    fetch(t, {
                        method: "POST",
                        mode: "same-origin",
                        headers: {
                            "Scoped-CSRF-Token": n.value,
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }), (0, l.on)("click", "div.js-restore-item", async function(e) {
                    const t = e.currentTarget.getAttribute("data-url"),
                        n = e.currentTarget.getAttribute("data-column"),
                        o = e.currentTarget.querySelector(".js-data-url-csrf"),
                        r = new FormData;
                    if (r.set("memexProjectItemIds[]", n), !(await fetch(t, {
                            method: "PUT",
                            mode: "same-origin",
                            body: r,
                            headers: {
                                "Scoped-CSRF-Token": o.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).ok) throw new Error("connection error");
                    Mr(e)
                })
            },
            2235: (N, C, u) => {
                "use strict";
                u.d(C, {
                    S: () => k
                });

                function w(E) {
                    const h = document.querySelectorAll(E);
                    if (h.length > 0) return h[h.length - 1]
                }
                s(w, "queryLast");

                function l() {
                    const E = w("meta[name=analytics-location]");
                    return E ? E.content : window.location.pathname
                }
                s(l, "pagePathname");

                function T() {
                    const E = w("meta[name=analytics-location-query-strip]");
                    let h = "";
                    E || (h = window.location.search);
                    const d = w("meta[name=analytics-location-params]");
                    d && (h += (h ? "&" : "?") + d.content);
                    for (const y of document.querySelectorAll("meta[name=analytics-param-rename]")) {
                        const j = y.content.split(":", 2);
                        h = h.replace(new RegExp(`(^|[?&])${j[0]}($|=)`, "g"), `$1${j[1]}$2`)
                    }
                    return h
                }
                s(T, "pageQuery");

                function k() {
                    return `${window.location.protocol}//${window.location.host}${l()+T()}`
                }
                s(k, "requestUri")
            },
            49908: () => {
                let N, C = !1;

                function u() {
                    N = document.activeElement, document.body && document.body.classList.toggle("intent-mouse", C)
                }
                s(u, "setClass"), document.addEventListener("mousedown", function() {
                    C = !0, N === document.activeElement && u()
                }, {
                    capture: !0
                }), document.addEventListener("keydown", function() {
                    C = !1
                }, {
                    capture: !0
                }), document.addEventListener("focusin", u, {
                    capture: !0
                })
            },
            81266: (N, C, u) => {
                "use strict";
                u.d(C, {
                    OD: () => h,
                    Qc: () => d,
                    nz: () => E
                });
                var w = u(77434),
                    l = u(84570);

                function T(y, j, v) {
                    const b = v.closest(".js-characters-remaining-container");
                    if (!b) return;
                    const g = b.querySelector(".js-characters-remaining"),
                        f = String(g.getAttribute("data-suffix")),
                        L = (0, w.rq)(y),
                        R = j - L;
                    R <= 20 ? (g.textContent = `${R} ${f}`, g.classList.toggle("color-fg-danger", R <= 5), g.hidden = !1) : g.hidden = !0
                }
                s(T, "showRemainingCharacterCount");

                function k(y) {
                    return y.hasAttribute("data-maxlength") ? parseInt(y.getAttribute("data-maxlength") || "") : y.maxLength
                }
                s(k, "getFieldLimit");

                function E(y) {
                    const j = k(y),
                        v = (0, w.rq)(y.value);
                    return j - v < 0
                }
                s(E, "hasExceededCharacterLimit");

                function h(y) {
                    const j = k(y);
                    T(y.value, j, y)
                }
                s(h, "updateInputRemainingCharacters");

                function d(y) {
                    const j = y.querySelectorAll(".js-characters-remaining-container");
                    for (const v of j) {
                        const b = v.querySelector(".js-characters-remaining-field");
                        h(b)
                    }
                }
                s(d, "resetCharactersRemainingCounts"), (0, l.ZG)(".js-characters-remaining-field", function(y) {
                    function j() {
                        (y instanceof HTMLInputElement || y instanceof HTMLTextAreaElement) && h(y)
                    }
                    s(j, "onInput"), j(), y.addEventListener("input", j), y.addEventListener("blur", () => {
                        y.removeEventListener("input", j)
                    }, {
                        once: !0
                    })
                })
            },
            24473: () => {
                document.addEventListener("click", function(N) {
                    if (!(N.target instanceof Element)) return;
                    const C = "a[data-confirm], input[type=submit][data-confirm], input[type=checkbox][data-confirm], button[data-confirm]",
                        u = N.target.closest(C);
                    if (!u) return;
                    const w = u.getAttribute("data-confirm");
                    !w || u instanceof HTMLInputElement && u.hasAttribute("data-confirm-checked") && !u.checked || confirm(w) || (N.stopImmediatePropagation(), N.preventDefault())
                }, !0)
            },
            17364: (N, C, u) => {
                "use strict";
                u.d(C, {
                    $: () => y,
                    G: () => d
                });
                var w = u(86404),
                    l = u(64463),
                    T = u(59753);
                (0, l.N7)("include-fragment, poll-include-fragment", {
                    subscribe: v => (0, w.qC)((0, w.RB)(v, "error", h), (0, w.RB)(v, "loadstart", E))
                }), (0, T.on)("click", "include-fragment button[data-retry-button]", ({
                    currentTarget: v
                }) => {
                    const b = v.closest("include-fragment"),
                        g = b.src;
                    b.src = "", b.src = g
                });

                function k(v, b) {
                    const g = v.currentTarget;
                    if (g instanceof Element) {
                        for (const f of g.querySelectorAll("[data-show-on-error]")) f instanceof HTMLElement && (f.hidden = !b);
                        for (const f of g.querySelectorAll("[data-hide-on-error]")) f instanceof HTMLElement && (f.hidden = b)
                    }
                }
                s(k, "toggleElements");

                function E(v) {
                    k(v, !1)
                }
                s(E, "onLoad");

                function h(v) {
                    k(v, !0)
                }
                s(h, "onError");

                function d({
                    currentTarget: v
                }) {
                    v instanceof Element && y(v)
                }
                s(d, "loadDeferredContentByEvent");

                function y(v) {
                    const b = v.closest("details");
                    b && j(b)
                }
                s(y, "loadDeferredContent");

                function j(v) {
                    const b = v.getAttribute("data-deferred-details-content-url");
                    if (b) {
                        v.removeAttribute("data-deferred-details-content-url");
                        const g = v.querySelector("include-fragment, poll-include-fragment");
                        g && (g.src = b)
                    }
                }
                s(j, "setIncludeFragmentSrc")
            },
            13728: () => {
                document.addEventListener("pjax:click", function(N) {
                    if (window.onbeforeunload) return N.preventDefault()
                })
            },
            23651: (N, C, u) => {
                "use strict";
                u.d(C, {
                    k: () => E
                });
                var w = u(86404),
                    l = u(34782),
                    T = u(64463),
                    k = u(86276);
                (0, T.N7)(".js-responsive-underlinenav", {
                    constructor: HTMLElement,
                    subscribe: y => (E(y), (0, w.RB)(window, "resize", () => d(y)))
                });
                async function E(y) {
                    await l.C, d(y)
                }
                s(E, "asyncCalculateVisibility");

                function h(y, j) {
                    y.style.visibility = j ? "hidden" : "";
                    const v = y.getAttribute("data-tab-item");
                    if (v) {
                        const b = document.querySelector(`[data-menu-item=${v}]`);
                        b instanceof HTMLElement && (b.hidden = !j)
                    }
                }
                s(h, "toggleItem");

                function d(y) {
                    const j = y.querySelectorAll(".js-responsive-underlinenav-item"),
                        v = y.querySelector(".js-responsive-underlinenav-overflow"),
                        b = (0, k.oE)(v, y);
                    if (!b) return;
                    let g = !1;
                    for (const f of j) {
                        const L = (0, k.oE)(f, y);
                        if (L) {
                            const R = L.left + f.offsetWidth >= b.left;
                            h(f, R), g = g || R
                        }
                    }
                    v.style.visibility = g ? "" : "hidden"
                }
                s(d, "calculateVisibility")
            },
            74675: () => {
                document.addEventListener("pjax:end", function() {
                    const N = document.querySelector('meta[name="selected-link"]'),
                        C = N && N.getAttribute("value");
                    if (!!C)
                        for (const u of document.querySelectorAll(".js-sidenav-container-pjax .js-selected-navigation-item")) {
                            const w = (u.getAttribute("data-selected-links") || "").split(" ").indexOf(C) >= 0;
                            w ? u.setAttribute("aria-current", "page") : u.removeAttribute("aria-current"), u.classList.toggle("selected", w)
                        }
                })
            },
            59371: () => {
                function N(w) {
                    const l = document.querySelector(".js-stale-session-flash"),
                        T = l.querySelector(".js-stale-session-flash-signed-in"),
                        k = l.querySelector(".js-stale-session-flash-signed-out");
                    l.hidden = !1, T.hidden = w === "false", k.hidden = w === "true", window.addEventListener("popstate", function(E) {
                        E.state && E.state.container != null && location.reload()
                    }), document.addEventListener("submit", function(E) {
                        E.preventDefault()
                    })
                }
                s(N, "sessionChanged");
                let C;
                if (typeof BroadcastChannel == "function") try {
                    C = new BroadcastChannel("stale-session"), C.onmessage = w => {
                        typeof w.data == "string" && N(w.data)
                    }
                } catch {}
                if (!C) {
                    let w = !1;
                    C = {
                        postMessage(l) {
                            w = !0;
                            try {
                                window.localStorage.setItem("logged-in", l)
                            } finally {
                                w = !1
                            }
                        }
                    }, window.addEventListener("storage", function(l) {
                        if (!w && l.storageArea === window.localStorage && l.key === "logged-in") try {
                            (l.newValue === "true" || l.newValue === "false") && N(l.newValue)
                        } finally {
                            window.localStorage.removeItem(l.key)
                        }
                    })
                }
                const u = document.querySelector(".js-stale-session-flash[data-signedin]");
                if (u) {
                    const w = u.getAttribute("data-signedin") || "";
                    C.postMessage(w)
                }
            },
            64048: (N, C, u) => {
                "use strict";
                var w = u(11793),
                    l = u(59753),
                    T = u(64463);
                class k {
                    constructor(h) {
                        this.container = h.container, this.selections = h.selections, this.inputWrap = h.inputWrap, this.input = h.input, this.tagTemplate = h.tagTemplate, this.form = this.input.form, this.autoComplete = h.autoComplete, this.multiTagInput = h.multiTagInput
                    }
                    setup() {
                        this.container.addEventListener("click", h => {
                            h.target.closest(".js-remove") ? this.removeTag(h) : this.onFocus()
                        }), this.input.addEventListener("focus", this.onFocus.bind(this)), this.input.addEventListener("blur", this.onBlur.bind(this)), this.input.addEventListener("keydown", this.onKeyDown.bind(this)), this.form.addEventListener("submit", this.onSubmit.bind(this)), this.autoComplete.addEventListener("auto-complete-change", () => {
                            this.selectTag(this.autoComplete.value)
                        })
                    }
                    onFocus() {
                        this.inputWrap.classList.add("focus"), this.input !== document.activeElement && this.input.focus()
                    }
                    onBlur() {
                        this.inputWrap.classList.remove("focus"), this.autoComplete.open || this.onSubmit()
                    }
                    onSubmit() {
                        this.input.value && (this.selectTag(this.input.value), this.autoComplete.open = !1)
                    }
                    onKeyDown(h) {
                        switch ((0, w.EL)(h)) {
                            case "Backspace":
                                this.onBackspace();
                                break;
                            case "Enter":
                            case "Tab":
                                this.taggifyValueWhenSuggesterHidden(h);
                                break;
                            case ",":
                            case " ":
                                this.taggifyValue(h);
                                break
                        }
                    }
                    taggifyValueWhenSuggesterHidden(h) {
                        !this.autoComplete.open && this.input.value && (h.preventDefault(), this.selectTag(this.input.value))
                    }
                    taggifyValue(h) {
                        this.input.value && (h.preventDefault(), this.selectTag(this.input.value), this.autoComplete.open = !1)
                    }
                    selectTag(h) {
                        const d = this.normalizeTag(h),
                            y = this.selectedTags();
                        let j = !1;
                        for (let v = 0; v < d.length; v++) {
                            const b = d[v];
                            y.indexOf(b) < 0 && (this.selections.appendChild(this.templateTag(b)), j = !0)
                        }
                        j && (this.input.value = "", (0, l.f)(this.form, "tags:changed"))
                    }
                    removeTag(h) {
                        const d = h.target;
                        h.preventDefault(), d.closest(".js-tag-input-tag").remove(), (0, l.f)(this.form, "tags:changed")
                    }
                    templateTag(h) {
                        const d = this.tagTemplate.cloneNode(!0);
                        return d.querySelector("input").value = h, d.querySelector(".js-placeholder-tag-name").replaceWith(h), d.classList.remove("d-none", "js-template"), d
                    }
                    normalizeTag(h) {
                        const d = h.toLowerCase().trim();
                        return d ? this.multiTagInput ? d.split(/[\s,']+/) : [d.replace(/[\s,']+/g, "-")] : []
                    }
                    onBackspace() {
                        if (!this.input.value) {
                            const h = this.selections.querySelector("li:last-child .js-remove");
                            h instanceof HTMLElement && h.click()
                        }
                    }
                    selectedTags() {
                        const h = this.selections.querySelectorAll("input");
                        return Array.from(h).map(d => d.value).filter(d => d.length > 0)
                    }
                }
                s(k, "TagInput"), (0, T.N7)(".js-tag-input-container", {
                    constructor: HTMLElement,
                    initialize(E) {
                        new k({
                            container: E,
                            inputWrap: E.querySelector(".js-tag-input-wrapper"),
                            input: E.querySelector('input[type="text"], input:not([type])'),
                            selections: E.querySelector(".js-tag-input-selected-tags"),
                            tagTemplate: E.querySelector(".js-template"),
                            autoComplete: E.querySelector("auto-complete"),
                            multiTagInput: !1
                        }).setup()
                    }
                }), (0, T.N7)(".js-multi-tag-input-container", {
                    constructor: HTMLElement,
                    initialize(E) {
                        new k({
                            container: E,
                            inputWrap: E.querySelector(".js-tag-input-wrapper"),
                            input: E.querySelector('input[type="text"], input:not([type])'),
                            selections: E.querySelector(".js-tag-input-selected-tags"),
                            tagTemplate: E.querySelector(".js-template"),
                            autoComplete: E.querySelector("auto-complete"),
                            multiTagInput: !0
                        }).setup()
                    }
                })
            },
            30463: () => {
                function N() {
                    const u = document.createElement("div");
                    return u.style.cssText = "-ms-user-select: element; user-select: contain;", u.style.getPropertyValue("-ms-user-select") === "element" || u.style.getPropertyValue("-ms-user-select") === "contain" || u.style.getPropertyValue("user-select") === "contain"
                }
                s(N, "supportsUserSelectContain");

                function C(u) {
                    if (!(u.target instanceof Element)) return;
                    const w = u.target.closest(".user-select-contain");
                    if (!w) return;
                    const l = window.getSelection();
                    if (!l || !l.rangeCount || !l.rangeCount || l.type !== "Range") return;
                    const T = l.getRangeAt(0).commonAncestorContainer;
                    w.contains(T) || l.selectAllChildren(w)
                }
                s(C, "handleUserSelectContain"), N() || document.addEventListener("click", C)
            },
            6216: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Dw: () => E,
                    G5: () => w,
                    M9: () => d,
                    n6: () => k
                });

                function w(g) {
                    const f = g.match(/#?(?:L)(\d+)((?:C)(\d+))?/g);
                    if (f)
                        if (f.length === 1) {
                            const L = h(f[0]);
                            return L ? Object.freeze({
                                start: L,
                                end: L
                            }) : void 0
                        } else if (f.length === 2) {
                        const L = h(f[0]),
                            R = h(f[1]);
                        return !L || !R ? void 0 : v(Object.freeze({
                            start: L,
                            end: R
                        }))
                    } else return;
                    else return
                }
                s(w, "parseBlobRange");

                function l(g) {
                    const {
                        start: f,
                        end: L
                    } = v(g);
                    return f.column != null && L.column != null ? `L${f.line}C${f.column}-L${L.line}C${L.column}` : f.line === L.line ? `L${f.line}` : `L${f.line}-L${L.line}`
                }
                s(l, "formatBlobRange");

                function T(g) {
                    const f = g.match(/(file-.+?-)L\d+?/i);
                    return f ? f[1] : ""
                }
                s(T, "parseAnchorPrefix");

                function k(g) {
                    const f = w(g),
                        L = T(g);
                    return {
                        blobRange: f,
                        anchorPrefix: L
                    }
                }
                s(k, "parseFileAnchor");

                function E({
                    anchorPrefix: g,
                    blobRange: f
                }) {
                    return f ? `#${g}${l(f)}` : "#"
                }
                s(E, "formatBlobRangeAnchor");

                function h(g) {
                    const f = g.match(/L(\d+)/),
                        L = g.match(/C(\d+)/);
                    return f ? Object.freeze({
                        line: parseInt(f[1]),
                        column: L ? parseInt(L[1]) : null
                    }) : null
                }
                s(h, "parseBlobOffset");

                function d(g, f) {
                    const [L, R] = y(g.start, !0, f), [I, $] = y(g.end, !1, f);
                    if (!L || !I) return;
                    let P = R,
                        U = $;
                    if (P === -1 && (P = 0), U === -1 && (U = I.childNodes.length), !L.ownerDocument) throw new Error("DOMRange needs to be inside document");
                    const x = L.ownerDocument.createRange();
                    return x.setStart(L, P), x.setEnd(I, U), x
                }
                s(d, "DOMRangeFromBlob");

                function y(g, f, L) {
                    const R = [null, 0],
                        I = L(g.line);
                    if (!I) return R;
                    if (g.column == null) return [I, -1];
                    let $ = g.column - 1;
                    const P = j(I);
                    for (let U = 0; U < P.length; U++) {
                        const x = P[U],
                            Y = $ - (x.textContent || "").length;
                        if (Y === 0) {
                            const D = P[U + 1];
                            return f && D ? [D, 0] : [x, $]
                        } else if (Y < 0) return [x, $];
                        $ = Y
                    }
                    return R
                }
                s(y, "findRangeOffset");

                function j(g) {
                    if (g.nodeType === Node.TEXT_NODE) return [g];
                    if (!g.childNodes || !g.childNodes.length) return [];
                    let f = [];
                    for (const L of g.childNodes) f = f.concat(j(L));
                    return f
                }
                s(j, "getAllTextNodes");

                function v(g) {
                    const f = [g.start, g.end];
                    return f.sort(b), f[0] === g.start && f[1] === g.end ? g : Object.freeze({
                        start: f[0],
                        end: f[1]
                    })
                }
                s(v, "ascendingBlobRange");

                function b(g, f) {
                    return g.line === f.line && g.column === f.column ? 0 : g.line === f.line && typeof g.column == "number" && typeof f.column == "number" ? g.column - f.column : g.line - f.line
                }
                s(b, "compareBlobOffsets")
            },
            34078: (N, C, u) => {
                "use strict";
                u.d(C, {
                    P: () => T,
                    g: () => k
                });
                var w = u(59753);
                const l = new WeakMap;

                function T(d) {
                    return l.get(d)
                }
                s(T, "getCodeEditor");
                async function k(d) {
                    return l.get(d) || E(await h(d, "codeEditor:ready"))
                }
                s(k, "getAsyncCodeEditor");

                function E(d) {
                    if (!(d instanceof CustomEvent)) throw new Error("assert: event is not a CustomEvent");
                    const y = d.detail.editor;
                    if (!d.target) throw new Error("assert: event.target is null");
                    return l.set(d.target, y), y
                }
                s(E, "onEditorFromEvent"), (0, w.on)("codeEditor:ready", ".js-code-editor", E);

                function h(d, y) {
                    return new Promise(j => {
                        d.addEventListener(y, j, {
                            once: !0
                        })
                    })
                }
                s(h, "nextEvent")
            },
            81503: (N, C, u) => {
                "use strict";
                u.d(C, {
                    $1: () => l,
                    d8: () => k,
                    ej: () => w,
                    kT: () => E
                });

                function w(h) {
                    return l(h)[0]
                }
                s(w, "getCookie");

                function l(h) {
                    const d = [];
                    for (const y of T()) {
                        const [j, v] = y.trim().split("=");
                        h === j && typeof v != "undefined" && d.push({
                            key: j,
                            value: v
                        })
                    }
                    return d
                }
                s(l, "getCookies");

                function T() {
                    try {
                        return document.cookie.split(";")
                    } catch {
                        return []
                    }
                }
                s(T, "readCookies");

                function k(h, d, y = null, j = !1, v = "lax") {
                    let b = document.domain;
                    if (b == null) throw new Error("Unable to get document domain");
                    b.endsWith(".github.com") && (b = "github.com");
                    const g = location.protocol === "https:" ? "; secure" : "",
                        f = y ? `; expires=${y}` : "";
                    j === !1 && (b = `.${b}`);
                    try {
                        document.cookie = `${h}=${d}; path=/; domain=${b}${f}${g}; samesite=${v}`
                    } catch {}
                }
                s(k, "setCookie");

                function E(h, d = !1) {
                    let y = document.domain;
                    if (y == null) throw new Error("Unable to get document domain");
                    y.endsWith(".github.com") && (y = "github.com");
                    const j = new Date().getTime(),
                        v = new Date(j - 1).toUTCString(),
                        b = location.protocol === "https:" ? "; secure" : "",
                        g = `; expires=${v}`;
                    d === !1 && (y = `.${y}`);
                    try {
                        document.cookie = `${h}=''; path=/; domain=${y}${g}${b}`
                    } catch {}
                }
                s(E, "deleteCookie")
            },
            26360: (N, C, u) => {
                "use strict";
                u.d(C, {
                    LN: () => v,
                    aJ: () => U,
                    cI: () => I,
                    eK: () => g,
                    mT: () => b
                });
                var w = u(79785),
                    l = u(43452),
                    T = u(82918),
                    k = u(50232),
                    E = u(28382),
                    h = u(2235);
                let d = !1,
                    y = 0;
                const j = Date.now();

                function v(D) {
                    D.error && f(R(L(D.error)))
                }
                s(v, "reportEvent");
                async function b(D) {
                    if (!!D.promise) try {
                        await D.promise
                    } catch (H) {
                        f(R(L(H)))
                    }
                }
                s(b, "reportPromiseRejectionEvent");

                function g(D, H = {}) {
                    D && D.name !== "AbortError" && f(R(L(D), H))
                }
                s(g, "reportError");
                async function f(D) {
                    var H, M;
                    if (!Y()) return;
                    const A = (M = (H = document.head) == null ? void 0 : H.querySelector('meta[name="browser-errors-url"]')) == null ? void 0 : M.content;
                    if (!!A) {
                        if (P(D.error.stacktrace)) {
                            d = !0;
                            return
                        }
                        y++;
                        try {
                            await fetch(A, {
                                method: "post",
                                body: JSON.stringify(D)
                            })
                        } catch {}
                    }
                }
                s(f, "report");

                function L(D) {
                    return {
                        type: D.name,
                        value: D.message,
                        stacktrace: I(D)
                    }
                }
                s(L, "formatError");

                function R(D, H = {}) {
                    return Object.assign({
                        error: D,
                        sanitizedUrl: (0, h.S)() || window.location.href,
                        readyState: document.readyState,
                        referrer: (0, w.wP)(),
                        timeSinceLoad: Math.round(Date.now() - j),
                        user: U() || void 0
                    }, H)
                }
                s(R, "errorContext");

                function I(D) {
                    return (0, E.Q)(D.stack || "").map(H => ({
                        filename: H.file || "",
                        function: String(H.methodName),
                        lineno: (H.lineNumber || 0).toString(),
                        colno: (H.column || 0).toString()
                    }))
                }
                s(I, "stacktrace");
                const $ = /(chrome|moz|safari)-extension:\/\//;

                function P(D) {
                    return D.some(H => $.test(H.filename) || $.test(H.function))
                }
                s(P, "isExtensionError");

                function U() {
                    var D, H;
                    const M = (H = (D = document.head) == null ? void 0 : D.querySelector('meta[name="user-login"]')) == null ? void 0 : H.content;
                    return M || `anonymous-${(0,T.b)()}`
                }
                s(U, "pageUser");
                let x = !1;
                window.addEventListener("pageshow", () => x = !1), window.addEventListener("pagehide", () => x = !0), document.addEventListener(w.QE.ERROR, D => {
                    f(R({
                        type: "SoftNavError",
                        value: D.detail,
                        stacktrace: I(new Error)
                    }))
                });

                function Y() {
                    return !x && !d && y < 10 && (0, k.Gb)() && !(0, l.Z)(document)
                }
                s(Y, "reportable"), typeof BroadcastChannel == "function" && new BroadcastChannel("shared-worker-error").addEventListener("message", H => {
                    g(H.data.error)
                })
            },
            91603: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Z: () => j
                });
                var w = u(47142);
                const l = s((v, b, g) => {
                        if (!(0, w.CD)(v, b)) return -1 / 0;
                        const f = (0, w.Gs)(v, b);
                        return f < g ? -1 / 0 : f
                    }, "getScore"),
                    T = s((v, b, g) => {
                        v.innerHTML = "";
                        let f = 0;
                        for (const L of (0, w.m7)(b, g)) {
                            g.slice(f, L) !== "" && v.appendChild(document.createTextNode(g.slice(f, L))), f = L + 1;
                            const I = document.createElement("mark");
                            I.textContent = g[L], v.appendChild(I)
                        }
                        v.appendChild(document.createTextNode(g.slice(f)))
                    }, "highlightElement"),
                    k = new WeakMap,
                    E = new WeakMap,
                    h = new WeakMap,
                    d = s(v => {
                        if (!h.has(v) && v instanceof HTMLElement) {
                            const b = (v.getAttribute("data-value") || v.textContent || "").trim();
                            return h.set(v, b), b
                        }
                        return h.get(v) || ""
                    }, "getTextCache");
                class y extends HTMLElement {
                    connectedCallback() {
                        const b = this.querySelector("ul");
                        if (!b) return;
                        const g = new Set(b.querySelectorAll("li")),
                            f = this.querySelector("input");
                        f instanceof HTMLInputElement && f.addEventListener("input", () => {
                            this.value = f.value
                        });
                        const L = new MutationObserver(I => {
                            let $ = !1;
                            for (const P of I)
                                if (P.type === "childList" && P.addedNodes.length) {
                                    for (const U of P.addedNodes)
                                        if (U instanceof HTMLLIElement && !g.has(U)) {
                                            const x = d(U);
                                            $ = $ || (0, w.CD)(this.value, x), g.add(U)
                                        }
                                }
                            $ && this.sort()
                        });
                        L.observe(b, {
                            childList: !0
                        });
                        const R = {
                            handler: L,
                            items: g,
                            lazyItems: new Map,
                            timer: null
                        };
                        E.set(this, R)
                    }
                    disconnectedCallback() {
                        const b = E.get(this);
                        b && (b.handler.disconnect(), E.delete(this))
                    }
                    addLazyItems(b, g) {
                        const f = E.get(this);
                        if (!f) return;
                        const {
                            lazyItems: L
                        } = f, {
                            value: R
                        } = this;
                        let I = !1;
                        for (const $ of b) L.set($, g), I = I || Boolean(R) && (0, w.CD)(R, $);
                        I && this.sort()
                    }
                    sort() {
                        const b = k.get(this);
                        b && (b.aborted = !0);
                        const g = {
                            aborted: !1
                        };
                        k.set(this, g);
                        const {
                            minScore: f,
                            markSelector: L,
                            maxMatches: R,
                            value: I
                        } = this, $ = E.get(this);
                        if (!$ || !this.dispatchEvent(new CustomEvent("fuzzy-list-will-sort", {
                                cancelable: !0,
                                detail: I
                            }))) return;
                        const {
                            items: P,
                            lazyItems: U
                        } = $, x = this.hasAttribute("mark-selector"), Y = this.querySelector("ul");
                        if (!Y) return;
                        const D = [];
                        if (I) {
                            for (const H of P) {
                                const M = d(H),
                                    A = l(I, M, f);
                                A !== -1 / 0 && D.push({
                                    item: H,
                                    score: A
                                })
                            }
                            for (const [H, M] of U) {
                                const A = l(I, H, f);
                                A !== -1 / 0 && D.push({
                                    text: H,
                                    render: M,
                                    score: A
                                })
                            }
                            D.sort((H, M) => M.score - H.score).splice(R)
                        } else {
                            let H = D.length;
                            for (const M of P) {
                                if (H >= R) break;
                                D.push({
                                    item: M,
                                    score: 1
                                }), H += 1
                            }
                            for (const [M, A] of U) {
                                if (H >= R) break;
                                D.push({
                                    text: M,
                                    render: A,
                                    score: 1
                                }), H += 1
                            }
                        }
                        requestAnimationFrame(() => {
                            if (g.aborted) return;
                            const H = Y.querySelector('input[type="radio"]:checked');
                            Y.innerHTML = "";
                            let M = 0;
                            const A = s(() => {
                                if (g.aborted) return;
                                const F = Math.min(D.length, M + 100),
                                    _ = document.createDocumentFragment();
                                for (let G = M; G < F; G += 1) {
                                    const de = D[G];
                                    let ee = null;
                                    if ("render" in de && "text" in de) {
                                        const {
                                            render: re,
                                            text: te
                                        } = de;
                                        ee = re(te), P.add(ee), h.set(ee, te), U.delete(te)
                                    } else "item" in de && (ee = de.item);
                                    ee instanceof HTMLElement && (x && T(L && ee.querySelector(L) || ee, x ? I : "", d(ee)), _.appendChild(ee))
                                }
                                M = F;
                                let V = !1;
                                if (H instanceof HTMLInputElement)
                                    for (const G of _.querySelectorAll('input[type="radio"]:checked')) G instanceof HTMLInputElement && G.value !== H.value && (G.checked = !1, V = !0);
                                if (Y.appendChild(_), H && V && H.dispatchEvent(new Event("change", {
                                        bubbles: !0
                                    })), F < D.length) requestAnimationFrame(A);
                                else {
                                    Y.hidden = D.length === 0;
                                    const G = this.querySelector("[data-fuzzy-list-show-on-empty]");
                                    G && (G.hidden = D.length > 0), this.dispatchEvent(new CustomEvent("fuzzy-list-sorted", {
                                        detail: D.length
                                    }))
                                }
                            }, "nextBatch");
                            A()
                        })
                    }
                    get value() {
                        return this.getAttribute("value") || ""
                    }
                    set value(b) {
                        this.setAttribute("value", b)
                    }
                    get markSelector() {
                        return this.getAttribute("mark-selector") || ""
                    }
                    set markSelector(b) {
                        b ? this.setAttribute("mark-selector", b) : this.removeAttribute("mark-selector")
                    }
                    get minScore() {
                        return Number(this.getAttribute("min-score") || 0)
                    }
                    set minScore(b) {
                        Number.isNaN(b) || this.setAttribute("min-score", String(b))
                    }
                    get maxMatches() {
                        return Number(this.getAttribute("max-matches") || 1 / 0)
                    }
                    set maxMatches(b) {
                        Number.isNaN(b) || this.setAttribute("max-matches", String(b))
                    }
                    static get observedAttributes() {
                        return ["value", "mark-selector", "min-score", "max-matches"]
                    }
                    attributeChangedCallback(b, g, f) {
                        if (g === f) return;
                        const L = E.get(this);
                        !L || (L.timer && window.clearTimeout(L.timer), L.timer = window.setTimeout(() => this.sort(), 100))
                    }
                }
                s(y, "FuzzyListElement");
                const j = y;
                window.customElements.get("fuzzy-list") || (window.FuzzyListElement = y, window.customElements.define("fuzzy-list", y))
            },
            95186: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Y: () => d,
                    q: () => y
                });
                var w = u(88149),
                    l = u(86058);
                const T = "dimension_";
                let k;
                const E = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "scid"];
                try {
                    const j = (0, w.n)("octolytics");
                    delete j.baseContext, k = new l.R(j)
                } catch {}

                function h(j) {
                    const v = (0, w.n)("octolytics").baseContext || {};
                    if (v) {
                        delete v.app_id, delete v.event_url, delete v.host;
                        for (const f in v) f.startsWith(T) && (v[f.replace(T, "")] = v[f], delete v[f])
                    }
                    const b = document.querySelector("meta[name=visitor-payload]");
                    if (b) {
                        const f = JSON.parse(atob(b.content));
                        Object.assign(v, f)
                    }
                    const g = new URLSearchParams(window.location.search);
                    for (const [f, L] of g) E.includes(f.toLowerCase()) && (v[f] = L);
                    return Object.assign(v, j)
                }
                s(h, "extendBaseContext");

                function d(j) {
                    k == null || k.sendPageView(h(j))
                }
                s(d, "sendPageView");

                function y(j, v) {
                    var b, g;
                    const f = (g = (b = document.head) == null ? void 0 : b.querySelector('meta[name="current-catalog-service"]')) == null ? void 0 : g.content,
                        L = f ? {
                            service: f
                        } : {};
                    for (const [R, I] of Object.entries(v)) I != null && (L[R] = `${I}`);
                    k == null || k.sendEvent(j || "unknown", h(L))
                }
                s(y, "sendEvent")
            },
            81654: (N, C, u) => {
                "use strict";
                u.d(C, {
                    $S: () => l,
                    Fk: () => T,
                    sz: () => k
                });
                var w = u(83476);

                function l(E, h, d) {
                    const y = {
                            hydroEventPayload: E,
                            hydroEventHmac: h,
                            visitorPayload: "",
                            visitorHmac: "",
                            hydroClientContext: d
                        },
                        j = document.querySelector("meta[name=visitor-payload]");
                    j instanceof HTMLMetaElement && (y.visitorPayload = j.content);
                    const v = document.querySelector("meta[name=visitor-hmac]") || "";
                    v instanceof HTMLMetaElement && (y.visitorHmac = v.content), (0, w.b)(y, !0)
                }
                s(l, "sendData");

                function T(E) {
                    const h = E.getAttribute("data-hydro-view") || "",
                        d = E.getAttribute("data-hydro-view-hmac") || "",
                        y = E.getAttribute("data-hydro-client-context") || "";
                    l(h, d, y)
                }
                s(T, "trackView");

                function k(E) {
                    const h = E.getAttribute("data-hydro-click-payload") || "",
                        d = E.getAttribute("data-hydro-click-hmac") || "",
                        y = E.getAttribute("data-hydro-client-context") || "";
                    l(h, d, y)
                }
                s(k, "sendHydroEvent")
            },
            75552: (N, C, u) => {
                "use strict";
                u.d(C, {
                    vt: () => $,
                    WF: () => I,
                    DV: () => R,
                    jW: () => Y,
                    Nc: () => b,
                    $t: () => T
                });
                const w = {
                    frequency: .6,
                    recency: .4
                };

                function l(M, A) {
                    return M.sort((F, _) => A(F) - A(_))
                }
                s(l, "sortBy");

                function T(M) {
                    const A = E(M),
                        F = h(M);
                    return function(_) {
                        return k(A.get(_) || 0, F.get(_) || 0)
                    }
                }
                s(T, "scorer");

                function k(M, A) {
                    return M * w.frequency + A * w.recency
                }
                s(k, "score");

                function E(M) {
                    const A = [...Object.values(M)].reduce((F, _) => F + _.visitCount, 0);
                    return new Map(Object.keys(M).map(F => [F, M[F].visitCount / A]))
                }
                s(E, "frequencyMap");

                function h(M) {
                    const A = l([...Object.keys(M)], _ => M[_].lastVisitedAt),
                        F = A.length;
                    return new Map(A.map((_, V) => [_, (V + 1) / F]))
                }
                s(h, "recencyMap");
                const d = /^\/orgs\/([a-z0-9-]+)\/teams\/([\w-]+)/,
                    y = [/^\/([^/]+)\/([^/]+)\/?$/, /^\/([^/]+)\/([^/]+)\/blob/, /^\/([^/]+)\/([^/]+)\/tree/, /^\/([^/]+)\/([^/]+)\/issues/, /^\/([^/]+)\/([^/]+)\/pulls?/, /^\/([^/]+)\/([^/]+)\/pulse/],
                    j = [
                        ["organization", /^\/orgs\/([a-z0-9-]+)\/projects\/([0-9-]+)/],
                        ["repository", /^\/([^/]+)\/([^/]+)\/projects\/([0-9-]+)/]
                    ],
                    v = 100;

                function b(M) {
                    const A = M.match(d);
                    if (A) {
                        f(R(A[1], A[2]));
                        return
                    }
                    let F;
                    for (let V = 0, G = j.length; V < G; V++) {
                        const [de, ee] = j[V];
                        if (F = M.match(ee), F) {
                            let re = null,
                                te = null;
                            switch (de) {
                                case "organization":
                                    re = F[1], te = F[2];
                                    break;
                                case "repository":
                                    re = `${F[1]}/${F[2]}`, te = F[3];
                                    break;
                                default:
                            }
                            re && te && f($(re, te));
                            return
                        }
                    }
                    let _;
                    for (let V = 0, G = y.length; V < G; V++)
                        if (_ = M.match(y[V]), _) {
                            f(I(_[1], _[2]));
                            return
                        }
                }
                s(b, "logPageView");

                function g(M) {
                    const A = Object.keys(M);
                    if (A.length <= v) return M;
                    const F = T(M),
                        _ = A.sort((V, G) => F(G) - F(V)).slice(0, v / 2);
                    return Object.fromEntries(_.map(V => [V, M[V]]))
                }
                s(g, "limitedPageViews");

                function f(M) {
                    const A = Y(),
                        F = L(),
                        _ = A[M] || {
                            lastVisitedAt: F,
                            visitCount: 0
                        };
                    _.visitCount += 1, _.lastVisitedAt = F, A[M] = _, x(g(A))
                }
                s(f, "logPageViewByKey");

                function L() {
                    return Math.floor(Date.now() / 1e3)
                }
                s(L, "currentEpochTimeInSeconds");

                function R(M, A) {
                    return `team:${M}/${A}`
                }
                s(R, "buildTeamKey");

                function I(M, A) {
                    return `repository:${M}/${A}`
                }
                s(I, "buildRepositoryKey");

                function $(M, A) {
                    return `project:${M}/${A}`
                }
                s($, "buildProjectKey");
                const P = /^(team|repository|project):[^/]+\/[^/]+(\/([^/]+))?$/,
                    U = "jump_to:page_views";

                function x(M) {
                    D(U, JSON.stringify(M))
                }
                s(x, "setPageViewsMap");

                function Y() {
                    const M = H(U);
                    if (!M) return {};
                    let A;
                    try {
                        A = JSON.parse(M)
                    } catch {
                        return x({}), {}
                    }
                    const F = {};
                    for (const _ in A) _.match(P) && (F[_] = A[_]);
                    return F
                }
                s(Y, "getPageViewsMap");

                function D(M, A) {
                    try {
                        window.localStorage.setItem(M, A)
                    } catch {}
                }
                s(D, "setItem");

                function H(M) {
                    try {
                        return window.localStorage.getItem(M)
                    } catch {
                        return null
                    }
                }
                s(H, "getItem")
            },
            75509: (N, C, u) => {
                "use strict";
                u.d(C, {
                    a: () => w
                });

                function w(E, h) {
                    const d = E.closest("[data-notification-id]");
                    h.hasAttribute("data-status") && l(d, h.getAttribute("data-status")), h.hasAttribute("data-subscription-status") && T(d, h.getAttribute("data-subscription-status")), h.hasAttribute("data-starred-status") && k(d, h.getAttribute("data-starred-status"))
                }
                s(w, "updateNotificationStates");

                function l(E, h) {
                    E.classList.toggle("notification-archived", h === "archived"), E.classList.toggle("notification-unread", h === "unread"), E.classList.toggle("notification-read", h === "read")
                }
                s(l, "toggleNotificationStatus");

                function T(E, h) {
                    E.classList.toggle("notification-unsubscribed", h === "unsubscribed")
                }
                s(T, "toggleNotificationSubscriptionStatus");

                function k(E, h) {
                    E.classList.toggle("notification-starred", h === "starred")
                }
                s(k, "toggleNotificationStarredStatus")
            },
            11178: (N, C, u) => {
                "use strict";
                u.d(C, {
                    v: () => w
                });

                function w(l, T) {
                    T.appendChild(l.extractContents()), l.insertNode(T)
                }
                s(w, "surroundContents")
            },
            47437: (N, C, u) => {
                "use strict";
                u.d(C, {
                    e: () => w
                });

                function w(l) {
                    const T = l || window.location,
                        k = document.head && document.head.querySelector("meta[name=session-resume-id]");
                    return k instanceof HTMLMetaElement && k.content || T.pathname
                }
                s(w, "getPageID")
            },
            46836: (N, C, u) => {
                "use strict";
                u.d(C, {
                    LS: () => T,
                    cl: () => k,
                    rV: () => l
                });
                var w = u(60785);
                const {
                    getItem: l,
                    setItem: T,
                    removeItem: k
                } = (0, w.Z)("sessionStorage")
            },
            79785: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Ak: () => f,
                    F6: () => P,
                    FP: () => b,
                    LD: () => v,
                    OE: () => j,
                    Po: () => y,
                    QE: () => T,
                    Xk: () => I,
                    Ys: () => $,
                    wP: () => U
                });
                var w = u(46836),
                    l = u(2235);
                const T = Object.freeze({
                        INITIAL: "soft-nav:initial",
                        SUCCESS: "soft-nav:success",
                        ERROR: "soft-nav:error"
                    }),
                    k = "soft-navigation-fail",
                    E = "soft-navigation-referrer",
                    h = "soft-navigation-marker",
                    d = "reload";

                function y() {
                    return (0, w.rV)(h) === "1"
                }
                s(y, "inSoftNavigation");

                function j() {
                    return Boolean(L())
                }
                s(j, "hasSoftNavFailure");

                function v() {
                    (0, w.LS)(h, "1"), (0, w.LS)(E, (0, l.S)() || window.location.href)
                }
                s(v, "startSoftNav");

                function b() {
                    (0, w.LS)(h, "0")
                }
                s(b, "endSoftNav");

                function g() {
                    (0, w.LS)(h, "0"), (0, w.cl)(E), (0, w.cl)(k)
                }
                s(g, "clearSoftNav");

                function f(x) {
                    (0, w.LS)(k, x || d)
                }
                s(f, "setSoftNavFailReason");

                function L() {
                    return (0, w.rV)(k)
                }
                s(L, "getSoftNavFailReason");
                let R = 0;

                function I() {
                    R += 1, document.dispatchEvent(new CustomEvent(T.SUCCESS, {
                        detail: R
                    }))
                }
                s(I, "softNavSucceeded");

                function $() {
                    document.dispatchEvent(new CustomEvent(T.ERROR, {
                        detail: L() || d
                    })), R = 0, g()
                }
                s($, "softNavFailed");

                function P() {
                    document.dispatchEvent(new CustomEvent(T.INITIAL)), R = 0, g()
                }
                s(P, "softNavInitial");

                function U() {
                    return (0, w.rV)(E) || document.referrer
                }
                s(U, "getSoftNavReferrer")
            },
            37713: (N, C, u) => {
                "use strict";
                u.d(C, {
                    kc: () => k,
                    lA: () => E,
                    zT: () => T
                });
                var w = u(14037),
                    l = u(54235);

                function T(h) {
                    if (h.hasAttribute("data-ignore-sticky-scroll")) return;
                    const d = h.ownerDocument;
                    setTimeout(() => {
                        d && d.defaultView && (h.scrollIntoView(), d.defaultView.scrollBy(0, -E(d)))
                    }, 0)
                }
                s(T, "scrollIntoView");

                function k(h) {
                    const d = (0, w.Kt)(h);
                    d && T(d)
                }
                s(k, "scrollToFragmentTarget");

                function E(h) {
                    (0, l.H)();
                    const d = h.querySelectorAll(".js-sticky-offset-scroll"),
                        y = h.querySelectorAll(".js-position-sticky"),
                        j = Math.max(0, ...Array.from(d).map(g => {
                            const {
                                top: f,
                                height: L
                            } = g.getBoundingClientRect();
                            return f === 0 ? L : 0
                        })) + Math.max(0, ...Array.from(y).map(g => {
                            const {
                                top: f,
                                height: L
                            } = g.getBoundingClientRect(), R = parseInt(getComputedStyle(g).top);
                            if (!g.parentElement) return 0;
                            const I = g.parentElement.getBoundingClientRect().top;
                            return f === R && I < 0 ? L : 0
                        })),
                        v = h.querySelectorAll(".js-position-sticky-stacked"),
                        b = Array.from(v).reduce((g, f) => {
                            const {
                                height: L,
                                top: R
                            } = f.getBoundingClientRect(), I = R < 0, $ = f.classList.contains("is-stuck");
                            return g + (!I && $ ? L : 0)
                        }, 0);
                    return j + b
                }
                s(E, "computeFixedYOffset")
            },
            24519: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Z: () => v
                });
                var w = u(51374),
                    l = u(52660),
                    T = u(65935),
                    k = u(85806);
                let E = !1;

                function h(b) {
                    const g = new URL(b, window.location.origin),
                        f = new URLSearchParams(g.search.slice(1));
                    return f.set("webauthn-support", (0, k.T)()), g.search = f.toString(), g.toString()
                }
                s(h, "urlWithParams");
                async function d() {
                    const b = document.querySelector("link[rel=sudo-modal]"),
                        g = document.querySelector(".js-sudo-prompt");
                    if (g instanceof HTMLTemplateElement) return g;
                    if (b) {
                        const f = await (0, l.a)(document, h(b.href));
                        return document.body.appendChild(f), document.querySelector(".js-sudo-prompt")
                    } else throw new Error("couldn't load sudo prompt")
                }
                s(d, "loadPromptTemplate");
                let y = !1;
                async function j() {
                    if (E) return !1;
                    E = !0, y = !1;
                    const g = (await d()).content.cloneNode(!0),
                        f = await (0, w.W)({
                            content: g
                        });
                    return await new Promise(L => {
                        f.addEventListener("dialog:remove", function() {
                            E = !1, L()
                        }, {
                            once: !0
                        })
                    }), y
                }
                s(j, "sudoPrompt"), (0, T.AC)(".js-sudo-form", async function(b, g) {
                    try {
                        await g.text()
                    } catch (f) {
                        if (!f.response) throw f;
                        let L;
                        switch (f.response.status) {
                            case 401:
                                L = "Incorrect password.";
                                break;
                            case 429:
                                L = "Too many password attempts. Please wait and try again later.";
                                break;
                            default:
                                L = "Failed to receive a response. Please try again later."
                        }
                        b.querySelector(".js-sudo-error").textContent = L, b.querySelector(".js-sudo-error").hidden = !1, b.querySelector(".js-sudo-password").value = "";
                        return
                    }
                    y = !0, b.closest("details").removeAttribute("open")
                });
                async function v() {
                    const b = await fetch("/sessions/in_sudo", {
                        headers: {
                            accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    return b.ok && await b.text() === "true" ? !0 : j()
                }
                s(v, "triggerSudoPrompt")
            },
            77434: (N, C, u) => {
                "use strict";
                u.d(C, {
                    Om: () => k,
                    lp: () => l,
                    rq: () => w,
                    t4: () => T,
                    yb: () => h
                });

                function w(d) {
                    const y = "\u200D",
                        j = d.split(y);
                    let v = 0;
                    for (const b of j) v += Array.from(b.split(/[\ufe00-\ufe0f]/).join("")).length;
                    return v / j.length
                }
                s(w, "getUtf8StringLength");

                function l(d, y, j) {
                    let v = d.value.substring(0, d.selectionEnd || 0),
                        b = d.value.substring(d.selectionEnd || 0);
                    return v = v.replace(y, j), b = b.replace(y, j), E(d, v + b, v.length), j
                }
                s(l, "replaceText");

                function T(d, y, j) {
                    if (d.selectionStart === null || d.selectionEnd === null) return l(d, y, j);
                    const v = d.value.substring(0, d.selectionStart),
                        b = d.value.substring(d.selectionEnd);
                    return E(d, v + j + b, v.length), j
                }
                s(T, "replaceSelection");

                function k(d, y, j = {}) {
                    const v = d.selectionEnd || 0,
                        b = d.value.substring(0, v),
                        g = d.value.substring(v),
                        f = d.value === "" || b.match(/\n$/) ? "" : `
`,
                        L = j.appendNewline ? `
` : "",
                        R = f + y + L;
                    d.value = b + R + g;
                    const I = v + R.length;
                    return d.selectionStart = I, d.selectionEnd = I, d.dispatchEvent(new CustomEvent("change", {
                        bubbles: !0,
                        cancelable: !1
                    })), d.focus(), R
                }
                s(k, "insertText");

                function E(d, y, j) {
                    d.value = y, d.selectionStart = j, d.selectionEnd = j, d.dispatchEvent(new CustomEvent("change", {
                        bubbles: !0,
                        cancelable: !1
                    }))
                }
                s(E, "setTextareaValueAndCursor");

                function h(d, y) {
                    const j = [...d],
                        v = new TextEncoder,
                        b = new Uint8Array(4);
                    for (let g = 0; g < j.length; g++) {
                        const f = j[g],
                            {
                                written: L,
                                read: R
                            } = v.encodeInto(f, b);
                        if (!L || !R) return -1;
                        const I = L - R;
                        if (I !== 0 && (g < y && (y -= I), g >= y)) break
                    }
                    return y
                }
                s(h, "GetCharIndexFromBytePosition")
            },
            85806: (N, C, u) => {
                "use strict";
                u.d(C, {
                    T: () => l,
                    k: () => T
                });
                var w = u(70112);

                function l() {
                    return (0, w.Zh)() ? "supported" : "unsupported"
                }
                s(l, "webauthnSupportLevel");
                async function T() {
                    var k;
                    return await ((k = window.PublicKeyCredential) == null ? void 0 : k.isUserVerifyingPlatformAuthenticatorAvailable()) ? "supported" : "unsupported"
                }
                s(T, "iuvpaaSupportLevel")
            }
        },
        N => {
            var C = s(w => N(N.s = w), "__webpack_exec__");
            N.O(0, [5724, 93, 5388, 8932, 7077, 8630, 6262, 3682, 3932, 3826, 5222], () => C(88237));
            var u = N.O()
        }
    ]);
})();

//# sourceMappingURL=behaviors-1389c89302c7.js.map