const dynamicElements = new Map<string, Array<() => void>>()

const timers = new WeakMap<Element, number>()
function scan(node: Element = document.body) {
  cancelAnimationFrame(timers.get(node) || 0)
  timers.set(
    node,
    requestAnimationFrame(() => {
      for (const tagName of dynamicElements.keys()) {
        if (customElements.get(tagName) || node.querySelector(tagName) || node.matches(tagName)) {
          for (const cb of dynamicElements.get(tagName) || []) cb()
          dynamicElements.delete(tagName)
          timers.delete(node)
        }
      }
    })
  )
}

let prepared = false
function prepare() {
  scan()
  if (prepared) return
  prepared = true
  const elementLoader = new MutationObserver(mutations => {
    if (!dynamicElements.size) return
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node instanceof Element) scan(node)
      }
    }
  })
  elementLoader.observe(document, {subtree: true, childList: true})
}

export function whenSeen(tagName: string, callback: () => void) {
  if (!dynamicElements.has(tagName)) dynamicElements.set(tagName, [])
  dynamicElements.get(tagName)!.push(() => requestAnimationFrame(callback))

  if (document.readyState === 'interactive' || document.readyState === 'complete') {
    prepare()
  } else {
    document.addEventListener('DOMContentLoaded', prepare, {once: true})
  }
}
