import {loaded} from '../document-ready'
import {sendPageView} from '../hydro-analytics'
import {isFeatureEnabled} from '../features'
;(async function () {
  // PJAX should be treated like pageloads
  document.addEventListener('pjax:complete', () =>
    sendPageView({
      pjax: 'true'
    })
  )

  if (isFeatureEnabled('TURBO')) {
    // Turbo should be treated like pageloads
    // this event triggers on first page load and all subsequent Turbo visits
    document.addEventListener('turbo:load', () =>
      sendPageView({
        turbo: 'true'
      })
    )
  } else {
    // Send a page view as soon as the page is loaded
    await loaded
    sendPageView()
  }
})()
