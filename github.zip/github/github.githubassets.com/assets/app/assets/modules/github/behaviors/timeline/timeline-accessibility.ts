import {announceFromElement} from '../../aria-live'
// eslint-disable-next-line no-restricted-imports
import {observe} from 'selector-observer'

observe('.js-discussion', announceTimelineEvents)

function announceTimelineEvents() {
  let existingTimelineItems: WeakSet<Element> = new WeakSet()
  setExistingTimelineItems()

  document.addEventListener('pjax:end', setExistingTimelineItems)
  document.addEventListener('turbo:load', setExistingTimelineItems)

  observe('.js-timeline-item', el => {
    if (!(el instanceof HTMLElement)) return
    if (existingTimelineItems.has(el)) return

    announceFromElement(el)
  })

  function setExistingTimelineItems() {
    existingTimelineItems = new WeakSet(document.querySelectorAll('.js-timeline-item'))
  }
}

observe('html[data-a11y-animated-images] .js-discussion img[data-animated-image]', el => {
  if (!(el instanceof HTMLImageElement)) return // Element is not an image
  // Element has a parent link but is not the direct child
  if (el.closest('a') && !(el.parentElement instanceof HTMLAnchorElement)) return

  // 1. Detect whether image is contained within link as only child
  // 2. Assign attributes to image and link for data-targets
  // 3. Wrap image or link in <animated-image> container

  let parent = el.parentElement
  let link = null
  if (parent instanceof HTMLAnchorElement) {
    if (parent.childElementCount > 1) return
    link = parent
    link.setAttribute('data-target', 'animated-image.originalLink')
    parent = link.parentElement
  }

  el.removeAttribute('data-animated-image')
  el.setAttribute('data-target', 'animated-image.originalImage')

  const clone = link ? link.cloneNode(true) : el.cloneNode(true)

  const container = document.createElement('animated-image')
  container.appendChild(clone)
  parent?.replaceChild(container, link ? link : el)
})
